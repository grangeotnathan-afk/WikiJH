# Security Specification & Payload TDD — Wiki JH

## 1. Data Invariants
1. **Owner-Only Profile & Balance Integrity (`/players/{playerId}`)**: Only the authenticated, email-verified user matching `playerId` may create or update their `/players/{playerId}` document. No PII (`email`, `phone`, `address`) is stored in `/players`. `coins`, `elo`, `wins`, `losses`, `packs` must stay within valid non-negative bounds.
2. **Escrow Market Integrity (`/listings/{listingId}`)**: A listing can only be created by `sellerId == request.auth.uid` with `status == 'active'` and `sellerClaimed == false`. Only another verified player can buy an active listing (`status: 'active' -> 'sold'`, `buyerId == request.auth.uid`). Only the seller can cancel an active listing or claim proceeds once `sold` (`sellerClaimed: false -> true`).
3. **Escrow Trade Integrity (`/trades/{tradeId}`)**: A trade can only be created by `fromId == request.auth.uid` targeting an existing `toId != fromId` with `status == 'pending'` and `fromClaimed == false`. Only `toId` may accept or decline a pending trade. Only `fromId` may cancel a pending trade or claim cards after resolution.
4. **Matchmaking & Battle Integrity (`/battleQueue/{playerId}`, `/battles/{battleId}`)**: Queue entries can only be created/deleted by their owner (`uid == request.auth.uid`), or marked `matched` when another player joins them into an atomic battle. In `/battles/{battleId}`, only `p1Id` can join/submit `p1Move`/claim `p1Claimed`, and only `p2Id` can join an `'open'` battle/submit `p2Move`/claim `p2Claimed`. Terminal states (`finished`, `cancelled`) block further gameplay mutations.
5. **Temporal & ID Hardening**: All document IDs match `^[a-zA-Z0-9_\\-]+$` (max 128 chars). `createdAt` equals `request.time` on creation and is immutable on update; `updatedAt` equals `request.time` on update.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Shadow Field Injection on Player**: `{ ...validPlayer, isAdmin: true }` -> `PERMISSION_DENIED` (`hasOnly` blocks `isAdmin`).
2. **Identity Spoofing on Player Create**: Creating `/players/otherUid` with `uid: request.auth.uid` -> `PERMISSION_DENIED` (`playerId == request.auth.uid` fails).
3. **Unverified Email Write**: Authenticated user with `email_verified: false` updating `/players/{uid}` -> `PERMISSION_DENIED`.
4. **Negative Coins / Negative ELO**: Updating `/players/{uid}` with `coins: -500` or `elo: -10` -> `PERMISSION_DENIED`.
5. **ID Poisoning**: Creating `/listings/../../bad$id` or 200-char ID -> `PERMISSION_DENIED` (`isValidId` fails).
6. **Self-Purchase on Market**: Seller updating their own listing to `status: 'sold'` with `buyerId: sellerId` -> `PERMISSION_DENIED`.
7. **Double-Claim Market Proceeds**: Seller updating a `sold` listing with `sellerClaimed: true` a second time or resetting `sellerClaimed: false` -> `PERMISSION_DENIED`.
8. **Orphan Trade Target**: Creating a trade targeting `toId: 'non_existent_uid'` -> `PERMISSION_DENIED` (`exists(/players/$(toId))` fails).
9. **Sender Accepting Own Trade**: `fromId` updating `/trades/{id}` from `pending` to `accepted` -> `PERMISSION_DENIED`.
10. **P1 Overwriting P2 Move in Battle**: `p1Id` updating `p2Move` in `/battles/{id}` -> `PERMISSION_DENIED` (`affectedKeys` restricts P1 to `p1Move` / resolution).
11. **Post-Finish Battle Tampering**: Updating `winnerId` or `p1Score` when `existing().status == 'finished'` -> `PERMISSION_DENIED` (terminal state lock).
12. **Client Timestamp Forgery**: Creating a listing with `createdAt: Timestamp(0)` instead of `serverTimestamp()` -> `PERMISSION_DENIED` (`createdAt == request.time` fails).
