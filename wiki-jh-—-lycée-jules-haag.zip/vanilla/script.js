import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, GoogleAuthProvider, onAuthStateChanged, signInWithPopup, signOut } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  collection, deleteDoc, doc, getDoc, getFirestore, onSnapshot,
  query, runTransaction, serverTimestamp, setDoc, updateDoc, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const firebaseConfig = {
  apiKey: "AIzaSyDnaYORXfGtjwcaf9tq9e8IBEksNqY1YE8",
  authDomain: "dazzling-mind-1v0ns.firebaseapp.com",
  projectId: "dazzling-mind-1v0ns",
  storageBucket: "dazzling-mind-1v0ns.firebasestorage.app",
  messagingSenderId: "989726825664",
  appId: "1:989726825664:web:dc2f7cbb66e3deb62be125"
};
const FIRESTORE_DB_ID = "ai-studio-4df8dac4-a8e8-4310-a617-786ddf969228";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app, FIRESTORE_DB_ID);
const provider = new GoogleAuthProvider();

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const MAX_PACKS = 10;
const EXTRA_PACK_COST = 120;
const DISCARD_COINS = 1;
const RARITY_ORDER = ['EX', 'L', 'UR', 'SR', 'R', 'PC', 'C'];
const SUPER_ADMIN_EMAILS = ['grangeotnathan@gmail.com', 'darkknight1111100000@gmail.com'];
const isSuperAdminEmail = (email) => Boolean(email && SUPER_ADMIN_EMAILS.includes(String(email).trim().toLowerCase()));

const CAMPUS_FILIERES = [
  { site: 'Labbé', track: 'Voie Générale (Site Labbé)', classes: ['2nde Générale & Techno', '1ère Générale', 'Terminale Générale'] },
  { site: 'Labbé', track: 'Voie Technologique STI2D (Site Labbé)', classes: ['1ère STI2D', 'Terminale STI2D'] },
  { site: 'Labbé', track: 'BTS & CPGE (Site Labbé)', classes: ['BTS CIEL / Informatique', 'BTS Microtechniques (CIM)', 'BTS Électrotechnique', 'BTS Opticien-Lunetier', 'BTS CPRP', 'CPGE TSI'] },
  { site: 'Marceau', track: 'CAP Professionnels (Site Marceau)', classes: ['CAP Horlogerie', 'CAP Bijouterie', 'CAP Électricien'] },
  { site: 'Marceau', track: 'Baccalauréats Pro & BMA (Site Marceau)', classes: ['2nde Pro PMIA', '2nde Pro TNE', '1ère Pro Microtechniques', 'Term. Pro Microtechniques', '1ère Pro MELEC', 'Term. Pro MELEC', '1ère Pro CIEL', 'Term. Pro CIEL', '1ère Pro TRPM', 'Term. Pro TRPM', '1ère Pro MSPC', 'Term. Pro MSPC', 'BMA Horlogerie / Bijou'] },
  { site: 'Labbé', track: 'Équipe Éducative & Autres', classes: ['Autre / Équipe JH'] }
];

const CARDS = [
  { id: 1, r: 'C', name: 'Site Labbé', sub: 'Commune', icon: '◆', img: '/assets/aistudio/labbe_d17a5889.jpg', campus: 'Labbé', w: 42, atk: 36, def: 42, spd: 32, rec: 8, price: 20 },
  { id: 2, r: 'PC', name: 'Site Marceau', sub: 'Peu commune', icon: '✦', img: '/assets/aistudio/marceau_9d47ae5e.jpg', campus: 'Marceau', w: 14.5, atk: 46, def: 44, spd: 44, rec: 18, price: 45 },
  { id: 3, r: 'R', name: 'Cour Intérieure Labbé', sub: 'Rare', icon: '❖', img: '/assets/aistudio/images_28d4c789.jpeg', campus: 'Labbé', w: 5.5, atk: 58, def: 64, spd: 48, rec: 35, price: 90 },
  { id: 4, r: 'SR', name: 'Atelier Pro Marceau', sub: 'Super rare', icon: '⚙', img: '/assets/aistudio/images-5_536a8b68.jpeg', campus: 'Marceau', w: 2.35, atk: 71, def: 66, spd: 62, rec: 75, price: 190 },
  { id: 5, r: 'UR', name: 'Lycée Jules Haag', sub: 'Ultra rare', icon: '✹', img: '/assets/aistudio/labbe_d17a5889.jpg', campus: 'Jules Haag', w: 0.55, atk: 84, def: 82, spd: 76, rec: 160, price: 420 },
  { id: 6, r: 'L', name: 'Jules Haag Légende', sub: 'Légendaire', icon: '♛', img: '/assets/aistudio/marceau_9d47ae5e.jpg', campus: 'Jules Haag', w: 0.14, atk: 94, def: 91, spd: 89, rec: 350, price: 950 },
  { id: 7, r: 'EX', name: 'JH Exotique', sub: 'Exotique', icon: '❂', img: '/assets/aistudio/images-2_948d2426.jpeg', campus: 'Jules Haag', w: 0.03, atk: 106, def: 100, spd: 102, rec: 800, price: 2500 },
  { id: 8, r: 'C', name: 'Cour de Marceau', sub: 'Commune', icon: '◈', img: '/assets/aistudio/images-4_d3acd662.jpeg', campus: 'Marceau', w: 18, atk: 38, def: 36, spd: 42, rec: 8, price: 22 },
  { id: 9, r: 'PC', name: 'Horloge de Labbé', sub: 'Peu commune', icon: '◷', img: '/assets/aistudio/images-3_79d7815b.jpeg', campus: 'Labbé', w: 9, atk: 43, def: 52, spd: 40, rec: 18, price: 48 },
  { id: 10, r: 'R', name: 'Verrière Marceau', sub: 'Rare', icon: '◇', img: '/assets/aistudio/marceau_9d47ae5e.jpg', campus: 'Marceau', w: 4.5, atk: 61, def: 54, spd: 66, rec: 35, price: 95 },
  { id: 11, r: 'SR', name: 'Escalier Art Déco', sub: 'Super rare', icon: '🌀', img: '/assets/aistudio/images-2_948d2426.jpeg', campus: 'Labbé', w: 1.85, atk: 74, def: 68, spd: 58, rec: 75, price: 210 },
  { id: 12, r: 'UR', name: 'Beffroi Art Déco', sub: 'Ultra rare', icon: '♜', img: '/assets/aistudio/images-3_79d7815b.jpeg', campus: 'Labbé', w: 0.48, atk: 86, def: 85, spd: 72, rec: 160, price: 440 },
  { id: 13, r: 'UR', name: 'Agora Stendhal-Marceau', sub: 'Ultra rare', icon: '✧', img: '/assets/aistudio/images-4_d3acd662.jpeg', campus: 'Marceau', w: 0.4, atk: 82, def: 80, spd: 86, rec: 160, price: 440 },
  { id: 14, r: 'L', name: 'Couronne Jules Haag', sub: 'Légendaire', icon: '✪', img: '/assets/aistudio/labbe_d17a5889.jpg', campus: 'Jules Haag', w: 0.1, atk: 92, def: 95, spd: 88, rec: 350, price: 980 },
  { id: 15, r: 'R', name: 'Amphithéâtre Labbé', sub: 'Rare', icon: '◈', img: '/assets/aistudio/images-1_7f26794d.jpeg', campus: 'Labbé', w: 4, atk: 56, def: 60, spd: 55, rec: 35, price: 95 }
];

const COSMETICS = [
  { id: 'av_horloge', type: 'avatar', name: 'Horloger', price: 0, sym: '◷' },
  { id: 'av_eclaireur', type: 'avatar', name: 'Éclaireur', price: 0, sym: '◆' },
  { id: 'ti_eleve', type: 'title', name: 'Élève de Jules Haag', price: 0 }
];

const ACHIEVEMENTS = [
  { id: 'ach_first_pack', title: 'Premier Booster', desc: 'Ouvrir 1 paquet', coins: 40, target: 1, val: (p) => p.opened },
  { id: 'ach_collector_7', title: 'Explorateur', desc: '7 cartes uniques', coins: 110, target: 7, val: (p) => Object.values(p.inv || {}).filter((n) => n > 0).length },
  { id: 'ach_collector_all', title: 'Wiki Master', desc: 'Toutes les 15 cartes', coins: 450, target: 15, val: (p) => Object.values(p.inv || {}).filter((n) => n > 0).length },
  { id: 'ach_first_win', title: 'Baptême Arène', desc: '1 victoire PvP', coins: 65, target: 1, val: (p) => p.wins },
  { id: 'ach_first_trade', title: 'Entraide', desc: '1 échange finalisé', coins: 75, target: 1, val: (p) => p.tradesCompleted },
  { id: 'ach_first_sale', title: 'Négociant', desc: '1 vente au Marché', coins: 80, target: 1, val: (p) => p.marketSales }
];

const byId = (id) => CARDS.find((c) => c.id === id);
const cosById = (id) => COSMETICS.find((c) => c.id === id);

let currentUser = null;
let profile = null;
let allPlayers = [];
let listings = [];
let myListings = [];
let myBidListings = [];
let receivedTrades = [];
let sentTrades = [];
let openBattles = [];
let activeBattle = null;
let waitingQueue = [];
let queueEntry = null;
let isPromotedAdmin = false;
let adminDocs = [];
let adminSelectedUid = '';
let adminDeleteArmed = false;
let activeTab = 'packs';
let arenaTab = 'pvp';
let marketTab = 'browse';
let tradeTab = 'received';
let selectedDeck = [];
let selectedCardForMove = null;
let selectedStance = 'assault';
let obSite = 'Labbé';
let obClasse = '';
const isAdminUser = () => Boolean(currentUser?.emailVerified && (isSuperAdminEmail(currentUser.email) || isPromotedAdmin));

const claimedListings = new Set();
const claimedWins = new Set();
const claimedRefunds = new Set();

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2600);
}

function formatLeft(ms) {
  if (ms <= 0) return 'Terminée';
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m ${String(sec).padStart(2, '0')}s`;
}

function cardHTML(c, { count = 0, locked = false, selected = false, showStats = false, interactive = true, hideIcon = true } = {}) {
  const tag = interactive ? 'button type="button"' : 'div';
  const endTag = interactive ? 'button' : 'div';
  return `<${tag} class="jh-card ${locked ? 'locked' : ''} ${selected ? 'sel' : ''}" data-r="${c.r}" data-card="${c.id}">
    <div class="art">
      ${locked ? '' : `<img src="${c.img}" alt="${c.name}" />`}
      ${locked || !hideIcon ? `<span class="icon">${locked ? '?' : c.icon}</span>` : ''}
      <span class="r-tag">${c.r}</span>
      ${count > 1 && !locked ? `<span class="qty">×${count}</span>` : ''}
    </div>
    <div class="info">
      <h4>${locked ? 'Carte inconnue' : c.name}</h4>
      <p>${locked ? 'Non découverte' : `${c.sub} · ${c.campus}`}</p>
      ${showStats && !locked ? `<div class="stats"><span>ATQ ${c.atk}</span><span>DEF ${c.def}</span><span>VIT ${c.spd}</span></div>` : ''}
    </div>
  </${endTag}>`;
}

function sanitizePlayer(p) {
  return {
    uid: p.uid,
    visibility: 'public',
    displayName: String(p.displayName || 'Élève JH').trim().slice(0, 32),
    site: p.site === 'Marceau' ? 'Marceau' : 'Labbé',
    classe: String(p.classe || '').slice(0, 32),
    avatarId: p.avatarId || 'av_horloge',
    frameId: p.frameId || 'fr_classic',
    bannerId: p.bannerId || 'bn_obsidian',
    titleId: p.titleId || 'ti_eleve',
    bio: String(p.bio || '').slice(0, 140),
    showcaseCardId: Number(p.showcaseCardId || 1),
    coins: Math.max(0, Math.floor(p.coins || 0)),
    packs: Math.max(0, Math.min(999, Math.floor(p.packs || 0))),
    lastPackAt: Number(p.lastPackAt || Date.now()),
    inv: p.inv || {},
    opened: Math.max(0, Math.floor(p.opened || 0)),
    elo: Math.max(0, Math.floor(p.elo || 1000)),
    wins: Math.max(0, Math.floor(p.wins || 0)),
    losses: Math.max(0, Math.floor(p.losses || 0)),
    streak: Math.max(0, Math.floor(p.streak || 0)),
    bestStreak: Math.max(0, Math.floor(p.bestStreak || 0)),
    tradesCompleted: Math.max(0, Math.floor(p.tradesCompleted || 0)),
    marketSales: Math.max(0, Math.floor(p.marketSales || 0)),
    unlockedCosmetics: p.unlockedCosmetics || ['av_horloge', 'av_eclaireur', 'fr_classic', 'bn_obsidian', 'ti_eleve'],
    claimedAchievements: p.claimedAchievements || [],
    lastDailyAt: Number(p.lastDailyAt || 0),
    createdAt: p.createdAt || serverTimestamp(),
    updatedAt: serverTimestamp()
  };
}

async function mutateProfile(fn) {
  const ref = doc(db, 'players', currentUser.uid);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) return;
    tx.update(ref, sanitizePlayer(fn(snap.data())));
  });
}

function openClassPicker(initialSite, currentVal, onPick) {
  let siteTab = initialSite || 'ALL';
  const ov = $('#classModal');
  const draw = () => {
    const groups = CAMPUS_FILIERES.filter((g) => siteTab === 'ALL' || g.site === siteTab);
    ov.innerHTML = `<div class="sheet-panel stack">
      <div class="row-between">
        <h2>Choisir sa filière et classe</h2>
        <button type="button" id="closeClassM" class="btn">✕</button>
      </div>
      <div class="tabs">
        <button type="button" class="tab-btn ${siteTab === 'ALL' ? 'on' : ''}" data-cs="ALL">Toutes</button>
        <button type="button" class="tab-btn ${siteTab === 'Labbé' ? 'on' : ''}" data-cs="Labbé">Site Labbé</button>
        <button type="button" class="tab-btn ${siteTab === 'Marceau' ? 'on' : ''}" data-cs="Marceau">Site Marceau</button>
      </div>
      ${groups.map((g) => `
        <div>
          <strong class="small muted">${g.track}</strong>
          <div class="class-grid">
            ${g.classes.map((c) => `<button type="button" class="class-opt ${currentVal === c ? 'sel' : ''}" data-cl="${c}" data-st="${g.site}">${c}</button>`).join('')}
          </div>
        </div>`).join('')}
    </div>`;
    ov.hidden = false;
    $('#closeClassM').onclick = () => { ov.hidden = true; };
    $$('#classModal [data-cs]').forEach((b) => { b.onclick = () => { siteTab = b.dataset.cs; draw(); }; });
    $$('#classModal [data-cl]').forEach((b) => {
      b.onclick = () => { onPick(b.dataset.cl, b.dataset.st); ov.hidden = true; };
    });
  };
  draw();
}

function drawCard() {
  const tot = CARDS.reduce((s, c) => s + c.w, 0);
  let x = Math.random() * tot;
  for (const c of CARDS) { x -= c.w; if (x <= 0) return c; }
  return CARDS[0];
}

function resolveRound(round, m1, m2, s1, s2) {
  const c1 = byId(m1.cardId) || CARDS[0];
  const c2 = byId(m2.cardId) || CARDS[0];
  const pow = (c, st, site) => {
    let base = st === 'assault' ? c.atk * 1.2 + c.spd * 0.25 : st === 'defense' ? c.def * 1.25 + c.atk * 0.2 : c.spd * 1.2 + c.atk * 0.25;
    if (c.campus === site || c.campus === 'Jules Haag') base *= 1.1;
    return Math.round(base);
  };
  let p1Power = pow(c1, m1.stance, s1);
  let p2Power = pow(c2, m2.stance, s2);
  let note = 'Égalité tactique';
  if ((m1.stance === 'assault' && m2.stance === 'counter') || (m1.stance === 'defense' && m2.stance === 'assault') || (m1.stance === 'counter' && m2.stance === 'defense')) {
    p1Power = Math.round(p1Power * 1.18); note = 'Avantage J1 (+18%)';
  } else if ((m2.stance === 'assault' && m1.stance === 'counter') || (m2.stance === 'defense' && m1.stance === 'assault') || (m2.stance === 'counter' && m1.stance === 'defense')) {
    p2Power = Math.round(p2Power * 1.18); note = 'Avantage J2 (+18%)';
  }
  const winner = p1Power > p2Power ? 'p1' : p2Power > p1Power ? 'p2' : 'draw';
  return { round, p1CardId: c1.id, p2CardId: c2.id, p1Stance: m1.stance, p2Stance: m2.stance, p1Power, p2Power, winner, note };
}

function applyTheme(t) {
  const theme = t === 'dark' ? 'dark' : 'light';
  document.documentElement.classList.toggle('dark', theme === 'dark');
  localStorage.setItem('wikijh_theme', theme);
}
applyTheme(localStorage.getItem('wikijh_theme') || 'light');

function getNotifications() {
  if (!profile) return [];
  const items = [];
  const pTrades = receivedTrades.filter((t) => t.status === 'pending').length;
  if (pTrades > 0) items.push({ title: `${pTrades} échange(s) en attente`, sub: 'Ouvrir Échanges', nav: 'trades' });
  const claimed = profile.claimedAchievements || [];
  const claimAch = ACHIEVEMENTS.filter((a) => !claimed.includes(a.id) && a.val(profile) >= a.target).length;
  if (claimAch > 0) items.push({ title: `${claimAch} succès à réclamer`, sub: 'Récupérez vos récompenses', nav: 'profile' });
  return items;
}

function renderTopbar() {
  if (!profile) return;
  $('#coinVal').textContent = profile.coins.toLocaleString('fr-FR');
  const isPlusActive = ['profile', 'arena', 'leaderboard', 'admin'].includes(activeTab);
  $$('[data-nav]').forEach((b) => b.classList.toggle('active', b.dataset.nav === activeTab));
  $$('[data-plus-toggle]').forEach((b) => b.classList.toggle('active', isPlusActive));
  const admBtn = $('#plusAdminBtn');
  if (admBtn) admBtn.hidden = !isAdminUser();
  $('#notifDot').hidden = getNotifications().length === 0;
}

function renderPacks() {
  $('#view-packs').innerHTML = `
    <div class="wm-pulls">
      <div>
        <h1 class="wm-title">Ouvrir un paquet</h1>
        <p class="wm-sub">Découvrez 5 nouvelles cartes Jules Haag</p>
        <button id="helpLinkBtn" type="button" class="wm-help">Comment ça marche ?</button>
      </div>
      <button id="openPackBtn" class="pack-btn" ${profile.packs < 1 ? 'disabled' : ''}>
        <img src="/assets/aistudio/labbe_d17a5889.jpg" alt="Labbé" />
        <div class="pack-mid">Wiki JH</div>
        <img src="/assets/aistudio/marceau_9d47ae5e.jpg" alt="Marceau" />
      </button>
      <div class="wm-counter-box">
        <div class="pack-num mono">${profile.packs} <span class="muted" style="font-size:15px">/ ${MAX_PACKS}</span></div>
        <div class="muted small">paquets disponibles</div>
        <div class="bar"><i style="width:${Math.min(100, profile.packs / MAX_PACKS * 100)}%"></i></div>
      </div>
      <button id="openPackCta" class="btn primary" style="width:100%;max-width:300px;padding:14px 20px" ${profile.packs < 1 ? 'disabled' : ''}>Ouvrir un paquet</button>
      <div class="wm-extras">
        <div class="panel row-between">
          <div><strong>Booster supplémentaire</strong><div class="muted small">5 cartes aléatoires</div></div>
          <button id="buyPackBtn" class="btn" ${profile.coins < EXTRA_PACK_COST ? 'disabled' : ''}>${EXTRA_PACK_COST} ●</button>
        </div>
      </div>
    </div>`;

  $('#helpLinkBtn').onclick = () => {
    const ov = $('#helpModal');
    ov.innerHTML = `<div class="sheet-panel stack">
      <div class="row-between"><h2>Comment ça marche ?</h2><button id="closeHelp" class="btn">✕</button></div>
      <p class="small muted"><strong>1. Boosters :</strong> 1 paquet gratuit toutes les 10 minutes (max 10). Chaque paquet contient 5 cartes.</p>
      <p class="small muted"><strong>2. Défausse :</strong> chaque carte défaussée depuis la Collection rapporte 1 ●.</p>
      <p class="small muted"><strong>3. Échanges &amp; Marché :</strong> accédez aux Échanges et aux Enchères directement depuis la barre du bas.</p>
      <p class="small muted"><strong>4. Bataille &amp; Succès :</strong> disponibles dans le menu <strong>Plus</strong>.</p>
    </div>`;
    ov.hidden = false;
    $('#closeHelp').onclick = () => { ov.hidden = true; };
  };

  const openFn = async () => {
    if (profile.packs < 1) return;
    const pulled = Array.from({ length: 5 }, drawCard).sort((a, b) => RARITY_ORDER.indexOf(b.r) - RARITY_ORDER.indexOf(a.r));
    await mutateProfile((p) => {
      const inv = { ...(p.inv || {}) };
      pulled.forEach((c) => { inv[String(c.id)] = (inv[String(c.id)] || 0) + 1; });
      return { ...p, packs: p.packs - 1, lastPackAt: p.packs >= MAX_PACKS ? Date.now() : p.lastPackAt, opened: (p.opened || 0) + 1, inv };
    });
    let idx = 0;
    const ov = $('#revealModal');
    const showStep = () => {
      const c = pulled[idx];
      ov.innerHTML = `<div class="reveal-stage">
        <span class="reveal-hint">Carte ${idx + 1} / ${pulled.length} · Touchez n’importe où</span>
        ${cardHTML(c, { showStats: true, interactive: false })}
      </div>`;
      ov.hidden = false;
    };
    ov.onclick = () => {
      if (idx + 1 < pulled.length) { idx++; showStep(); }
      else { ov.hidden = true; ov.onclick = null; }
    };
    showStep();
  };
  $('#openPackBtn').onclick = $('#openPackCta').onclick = openFn;
  $('#buyPackBtn').onclick = async () => {
    await mutateProfile((p) => ({ ...p, coins: p.coins - EXTRA_PACK_COST, packs: p.packs + 1 }));
    toast('+1 Booster acheté !');
  };
}

function renderCollection() {
  const inv = profile.inv || {};
  const owned = CARDS.filter((c) => (inv[String(c.id)] || 0) > 0);
  let extraCount = 0;
  CARDS.forEach((c) => { const q = inv[String(c.id)] || 0; if (q > 1) extraCount += q - 1; });

  $('#view-collection').innerHTML = `
    <div class="stack">
      <div class="row-between">
        <div>
          <h1>Collection (${owned.length} / ${CARDS.length})</h1>
          <p class="muted small">Cliquez sur une carte pour voir ses détails ou la défausser (+${DISCARD_COINS} ●)</p>
        </div>
        <button id="recycleBtn" class="btn" ${extraCount < 1 ? 'disabled' : ''}>Défausser ${extraCount} doublon(s) (+${extraCount * DISCARD_COINS} ●)</button>
      </div>
      <div class="grid-cards">
        ${owned.length === 0 ? '<div class="empty">Aucune carte trouvée pour l’instant. Ouvrez des paquets !</div>' : owned.map((c) => cardHTML(c, { count: inv[String(c.id)] || 0, showStats: true, hideIcon: true })).join('')}
      </div>
    </div>`;

  $('#recycleBtn').onclick = async () => {
    await mutateProfile((p) => {
      const next = { ...(p.inv || {}) };
      CARDS.forEach((c) => { if ((next[String(c.id)] || 0) > 1) next[String(c.id)] = 1; });
      return { ...p, inv: next, coins: p.coins + extraCount * DISCARD_COINS };
    });
    toast(`${extraCount} doublon(s) défaussés : +${extraCount * DISCARD_COINS} ● !`);
  };

  $$('#view-collection [data-card]').forEach((el) => {
    el.onclick = () => {
      const c = byId(Number(el.dataset.card));
      const qty = inv[String(c.id)] || 0;
      if (!c || qty < 1) return;
      const ov = $('#detailModal');
      ov.innerHTML = `<div class="sheet-panel stack">
        <h2>${c.name} <span class="muted small">(${c.sub})</span></h2>
        <div style="max-width:210px;margin:0 auto">${cardHTML(c, { count: qty, showStats: true, interactive: false, hideIcon: true })}</div>
        <div class="row-2">
          <button id="discardOneBtn" class="btn danger">Défausser (+${DISCARD_COINS} ●)</button>
          <button id="closeDetailBtn" class="btn primary">Fermer</button>
        </div>
      </div>`;
      ov.hidden = false;
      $('#closeDetailBtn').onclick = () => { ov.hidden = true; };
      $('#discardOneBtn').onclick = async () => {
        await mutateProfile((p) => {
          const cur = (p.inv || {})[String(c.id)] || 0;
          if (cur < 1) return p;
          const next = { ...(p.inv || {}), [String(c.id)]: cur - 1 };
          return { ...p, inv: next, coins: p.coins + DISCARD_COINS };
        });
        ov.hidden = true;
        toast(`${c.name} défaussée (+${DISCARD_COINS} ●)`);
      };
    };
  });
}

function renderArena() {
  const inv = profile.inv || {};
  const owned = CARDS.filter((c) => (inv[String(c.id)] || 0) > 0);
  selectedDeck = selectedDeck.filter((id) => (inv[String(id)] || 0) > 0);
  while (selectedDeck.length < 3 && owned.length >= 3) {
    const next = owned.find((c) => !selectedDeck.includes(c.id));
    if (!next) break;
    selectedDeck.push(next.id);
  }

  if (activeBattle && activeBattle.status === 'active') {
    const isP1 = activeBattle.p1Id === profile.uid;
    const myDeck = isP1 ? activeBattle.p1Deck : activeBattle.p2Deck;
    const myMove = isP1 ? activeBattle.p1Move : activeBattle.p2Move;
    const used = (activeBattle.roundHistory || []).map((r) => isP1 ? r.p1CardId : r.p2CardId);
    const moved = myMove.stance !== 'none';

    $('#view-arena').innerHTML = `
      <div class="stack">
        <div class="panel row-between">
          <div>
            <div class="muted small">Manche ${activeBattle.round} / 3</div>
            <h2>${profile.displayName} ${isP1 ? activeBattle.p1Score : activeBattle.p2Score} — ${isP1 ? activeBattle.p2Score : activeBattle.p1Score} ${isP1 ? activeBattle.p2Name : activeBattle.p1Name}</h2>
          </div>
          <button id="forfeitBtn" class="btn danger">Abandonner</button>
        </div>
        <div class="grid-cards">
          ${myDeck.map((cid) => {
            const c = byId(cid);
            const dis = used.includes(cid);
            return `<div style="${dis ? 'opacity:.35;pointer-events:none' : ''}">${cardHTML(c, { showStats: true, selected: selectedCardForMove === cid || myMove.cardId === cid })}</div>`;
          }).join('')}
        </div>
        <div class="tabs">
          ${['assault', 'defense', 'counter'].map((st) => `<button type="button" class="tab-btn ${selectedStance === st ? 'on' : ''}" data-st="${st}">${st === 'assault' ? 'Assaut (+ATK)' : st === 'defense' ? 'Défense (+DEF)' : 'Contre (+VIT)'}</button>`).join('')}
        </div>
        <button id="sendMoveBtn" class="btn primary" ${moved || !selectedCardForMove ? 'disabled' : ''}>${moved ? 'En attente de l’adversaire…' : 'Valider le coup'}</button>
      </div>`;

    $$('#view-arena [data-card]').forEach((el) => {
      if (!moved) el.onclick = () => { selectedCardForMove = Number(el.dataset.card); renderArena(); };
    });
    $$('#view-arena [data-st]').forEach((el) => {
      if (!moved) el.onclick = () => { selectedStance = el.dataset.st; renderArena(); };
    });
    $('#sendMoveBtn').onclick = () => updateDoc(doc(db, 'battles', activeBattle.id), {
      [isP1 ? 'p1Move' : 'p2Move']: { cardId: selectedCardForMove, stance: selectedStance },
      updatedAt: serverTimestamp()
    });
    $('#forfeitBtn').onclick = () => updateDoc(doc(db, 'battles', activeBattle.id), {
      status: 'finished', winnerId: isP1 ? activeBattle.p2Id : activeBattle.p1Id, updatedAt: serverTimestamp()
    });
    return;
  }

  $('#view-arena').innerHTML = `
    <div class="stack">
      <div class="row-between">
        <div>
          <h1>Arène des Duels</h1>
          <p class="muted small">Affrontez les autres joueurs sur cette page dédiée (${profile.elo} ELO)</p>
        </div>
        <div class="tabs">
          <button type="button" class="tab-btn ${arenaTab === 'pvp' ? 'on' : ''}" data-at="pvp">Matchmaking PvP</button>
          <button type="button" class="tab-btn ${arenaTab === 'challenge' ? 'on' : ''}" data-at="challenge">Défier (${openBattles.length})</button>
          <button type="button" class="tab-btn ${arenaTab === 'deck' ? 'on' : ''}" data-at="deck">Mon Deck (${selectedDeck.length}/3)</button>
        </div>
      </div>

      ${arenaTab === 'pvp' ? `
        <div class="panel stack">
          <h3>Matchmaking Classé PvP</h3>
          <p class="muted small">${waitingQueue.length} joueur(s) actuellement en file d’attente</p>
          ${queueEntry ? `<button id="leaveQueueBtn" class="btn danger">Quitter la file d’attente</button>` : `<button id="joinQueueBtn" class="btn primary" ${selectedDeck.length !== 3 ? 'disabled' : ''}>Trouver un adversaire PvP</button>`}
        </div>
      ` : arenaTab === 'challenge' ? `
        <div class="panel stack">
          <div class="row-between">
            <h3>Défier des joueurs (Salons Ouverts)</h3>
            <button id="createOpenBtn" class="btn primary" ${selectedDeck.length !== 3 ? 'disabled' : ''}>+ Lancer un défi ouvert</button>
          </div>
          ${openBattles.length === 0 ? '<div class="empty">Aucun défi ouvert pour le moment.</div>' : openBattles.map((b) => `
            <div class="row-between" style="padding-top:10px;border-top:1px solid var(--line)">
              <div><strong>${b.p1Name}</strong> <span class="muted small">${b.p1Site} · ${b.p1Elo} ELO</span></div>
              ${b.p1Id === profile.uid ? `<button class="btn danger" data-cancel-b="${b.id}">Annuler</button>` : `<button class="btn primary" data-join-b="${b.id}" ${selectedDeck.length !== 3 ? 'disabled' : ''}>Relever le défi</button>`}
            </div>`).join('')}
        </div>
      ` : `
        <div class="panel stack">
          <h3>Deck de Duel (${selectedDeck.length} / 3 cartes)</h3>
          <div class="grid-cards">${owned.map((c) => cardHTML(c, { selected: selectedDeck.includes(c.id), showStats: true })).join('')}</div>
        </div>
      `}
    </div>`;

  $$('[data-at]').forEach((b) => { b.onclick = () => { arenaTab = b.dataset.at; renderArena(); }; });
  $$('#view-arena [data-card]').forEach((el) => {
    el.onclick = () => {
      const id = Number(el.dataset.card);
      if (selectedDeck.includes(id)) selectedDeck = selectedDeck.filter((x) => x !== id);
      else selectedDeck = selectedDeck.length >= 3 ? [...selectedDeck.slice(1), id] : [...selectedDeck, id];
      renderArena();
    };
  });
  if ($('#joinQueueBtn')) $('#joinQueueBtn').onclick = async () => {
    const opp = waitingQueue.find((w) => w.uid !== profile.uid);
    if (opp) {
      const bRef = doc(collection(db, 'battles'));
      await runTransaction(db, async (tx) => {
        const qRef = doc(db, 'battleQueue', opp.uid);
        const qSnap = await tx.get(qRef);
        if (!qSnap.exists() || qSnap.data().status !== 'waiting') throw new Error('Indisponible');
        tx.set(bRef, {
          p1Id: opp.uid, p1Name: opp.displayName, p1Site: opp.site, p1Elo: opp.elo, p1Avatar: opp.avatarId, p1Frame: opp.frameId, p1Deck: opp.deck,
          p2Id: profile.uid, p2Name: profile.displayName, p2Site: profile.site, p2Elo: profile.elo, p2Avatar: profile.avatarId, p2Frame: profile.frameId, p2Deck: selectedDeck,
          mode: 'ranked', status: 'active', round: 1, p1Score: 0, p2Score: 0,
          p1Move: { cardId: 0, stance: 'none' }, p2Move: { cardId: 0, stance: 'none' },
          roundHistory: [], winnerId: '', p1Claimed: false, p2Claimed: false, turnStartedAt: Date.now(),
          createdAt: serverTimestamp(), updatedAt: serverTimestamp()
        });
        tx.update(qRef, { status: 'matched', battleId: bRef.id, matchedWith: profile.uid, updatedAt: serverTimestamp() });
      });
    } else {
      await setDoc(doc(db, 'battleQueue', profile.uid), {
        uid: profile.uid, displayName: profile.displayName, site: profile.site, elo: profile.elo,
        avatarId: profile.avatarId, frameId: profile.frameId, deck: selectedDeck, status: 'waiting',
        battleId: '', matchedWith: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp()
      });
    }
  };
  if ($('#leaveQueueBtn')) $('#leaveQueueBtn').onclick = () => deleteDoc(doc(db, 'battleQueue', profile.uid));
  if ($('#createOpenBtn')) $('#createOpenBtn').onclick = () => setDoc(doc(collection(db, 'battles')), {
    p1Id: profile.uid, p1Name: profile.displayName, p1Site: profile.site, p1Elo: profile.elo, p1Avatar: profile.avatarId, p1Frame: profile.frameId, p1Deck: selectedDeck,
    p2Id: '', p2Name: '', p2Site: '', p2Elo: 0, p2Avatar: '', p2Frame: '', p2Deck: [],
    mode: 'ranked', status: 'open', round: 1, p1Score: 0, p2Score: 0,
    p1Move: { cardId: 0, stance: 'none' }, p2Move: { cardId: 0, stance: 'none' },
    roundHistory: [], winnerId: '', p1Claimed: false, p2Claimed: false, turnStartedAt: Date.now(),
    createdAt: serverTimestamp(), updatedAt: serverTimestamp()
  });
  $$('[data-join-b]').forEach((b) => {
    b.onclick = () => updateDoc(doc(db, 'battles', b.dataset.joinB), {
      p2Id: profile.uid, p2Name: profile.displayName, p2Site: profile.site, p2Elo: profile.elo, p2Avatar: profile.avatarId, p2Frame: profile.frameId, p2Deck: selectedDeck,
      status: 'active', turnStartedAt: Date.now(), updatedAt: serverTimestamp()
    });
  });
  $$('[data-cancel-b]').forEach((b) => {
    b.onclick = () => updateDoc(doc(db, 'battles', b.dataset.cancelB), { status: 'cancelled', updatedAt: serverTimestamp() });
  });
}

function renderTrades() {
  const pendingRec = receivedTrades.filter((t) => t.status === 'pending').length;
  const others = allPlayers.filter((p) => p.uid !== profile.uid);

  $('#view-trades').innerHTML = `
    <div class="stack">
      <div class="row-between">
        <div>
          <h1>Échanges entre Élèves</h1>
          <p class="muted small">Proposez ou acceptez des échanges de cartes avec les autres joueurs</p>
        </div>
        <div class="tabs">
          <button type="button" class="tab-btn ${tradeTab === 'received' ? 'on' : ''}" data-tt="received">Reçues (${pendingRec})</button>
          <button type="button" class="tab-btn ${tradeTab === 'sent' ? 'on' : ''}" data-tt="sent">Envoyées (${sentTrades.length})</button>
          <button type="button" class="tab-btn ${tradeTab === 'new' ? 'on' : ''}" data-tt="new">+ Proposer</button>
        </div>
      </div>

      ${tradeTab === 'received' ? `
        <div class="panel stack">
          ${receivedTrades.length === 0 ? '<div class="empty">Aucune offre d’échange reçue.</div>' : receivedTrades.map((t) => `
            <div class="row-between" style="padding-top:8px;border-top:1px solid var(--line)">
              <div>
                <strong>${t.fromName}</strong> <span class="muted small">(${t.fromSite})</span>
                <div class="muted small">Donne : ${t.give.map((id) => byId(id)?.name).join(', ')} · Demande : ${t.get.map((id) => byId(id)?.name).join(', ')}</div>
              </div>
              ${t.status === 'pending' ? `<div style="display:flex;gap:6px"><button class="btn danger" data-dec-t="${t.id}">Refuser</button><button class="btn primary" data-acc-t="${t.id}">Accepter</button></div>` : `<span class="muted small">${t.status}</span>`}
            </div>`).join('')}
        </div>
      ` : tradeTab === 'sent' ? `
        <div class="panel stack">
          ${sentTrades.length === 0 ? '<div class="empty">Aucune proposition envoyée.</div>' : sentTrades.map((t) => `
            <div class="row-between" style="padding-top:8px;border-top:1px solid var(--line)">
              <div>
                <strong>À ${t.toName}</strong>
                <div class="muted small">Offert : ${t.give.map((id) => byId(id)?.name).join(', ')} · Demandé : ${t.get.map((id) => byId(id)?.name).join(', ')}</div>
              </div>
              ${t.status === 'pending' ? `<button class="btn danger" data-can-t="${t.id}">Annuler</button>` : `<span class="muted small">${t.status}</span>`}
            </div>`).join('')}
        </div>
      ` : `
        <form id="newTradeForm" class="panel stack">
          <label class="lbl">Destinataire<select id="trTarget" class="field">${others.map((p) => `<option value="${p.uid}">${p.displayName} (${p.site})</option>`).join('')}</select></label>
          <div class="row-2">
            <label class="lbl">Carte à donner<select id="trGive" class="field">${CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0).map((c) => `<option value="${c.id}">${c.name} (×${profile.inv[String(c.id)]})</option>`).join('')}</select></label>
            <label class="lbl">Carte demandée<select id="trGet" class="field">${CARDS.map((c) => `<option value="${c.id}">${c.name} (${c.r})</option>`).join('')}</select></label>
          </div>
          <button type="submit" class="btn primary" ${others.length === 0 ? 'disabled' : ''}>Envoyer l’offre d’échange</button>
        </form>
      `}
    </div>`;

  $$('[data-tt]').forEach((b) => { b.onclick = () => { tradeTab = b.dataset.tt; renderTrades(); }; });

  $$('[data-acc-t]').forEach((b) => {
    b.onclick = async () => {
      const t = receivedTrades.find((x) => x.id === b.dataset.accT);
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pd = (await tx.get(pRef)).data();
        const inv = { ...(pd.inv || {}) };
        for (const id of t.get) { if ((inv[String(id)] || 0) < 1) throw new Error('Carte manquante'); inv[String(id)]--; }
        for (const id of t.give) { inv[String(id)] = (inv[String(id)] || 0) + 1; }
        tx.update(pRef, sanitizePlayer({ ...pd, inv, tradesCompleted: (pd.tradesCompleted || 0) + 1 }));
        tx.update(doc(db, 'trades', t.id), { status: 'accepted', updatedAt: serverTimestamp() });
      });
      toast('Échange accepté !');
    };
  });
  $$('[data-dec-t]').forEach((b) => {
    b.onclick = () => updateDoc(doc(db, 'trades', b.dataset.decT), { status: 'declined', updatedAt: serverTimestamp() });
  });
  $$('[data-can-t]').forEach((b) => {
    b.onclick = () => updateDoc(doc(db, 'trades', b.dataset.canT), { status: 'cancelled', updatedAt: serverTimestamp() });
  });
  if ($('#newTradeForm')) {
    $('#newTradeForm').onsubmit = async (e) => {
      e.preventDefault();
      const target = others.find((p) => p.uid === $('#trTarget').value);
      const giveId = Number($('#trGive').value);
      const getId = Number($('#trGet').value);
      if (!target || !giveId || !getId) return;
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pd = (await tx.get(pRef)).data();
        const inv = { ...(pd.inv || {}) };
        if ((inv[String(giveId)] || 0) < 1) throw new Error('Carte indisponible');
        inv[String(giveId)]--;
        tx.update(pRef, sanitizePlayer({ ...pd, inv }));
        tx.set(doc(collection(db, 'trades')), {
          fromId: profile.uid, fromName: profile.displayName, fromSite: profile.site,
          toId: target.uid, toName: target.displayName,
          give: [giveId], get: [getId], status: 'pending', fromClaimed: false,
          createdAt: serverTimestamp(), updatedAt: serverTimestamp()
        });
      });
      tradeTab = 'sent';
      renderTrades();
      toast('Offre envoyée !');
    };
  }
}

function renderMarket() {
  const now = Date.now();
  const browse = listings.filter((l) => l.sellerId !== profile.uid && l.endsAt > now);
  const mine = myListings.filter((l) => l.status === 'active');
  if (marketTab === 'trades') marketTab = 'browse';

  $('#view-market').innerHTML = `
    <div class="stack">
      <div class="row-between">
        <div>
          <h1>Marché aux Enchères</h1>
          <p class="muted small">Suivez les enchères en direct (qui mène et à quel prix)</p>
        </div>
        <button id="openSellBtn" class="btn primary">+ Mettre aux enchères</button>
      </div>

      <div class="tabs">
        <button type="button" class="tab-btn ${marketTab === 'browse' ? 'on' : ''}" data-mt="browse">Enchères (${browse.length})</button>
        <button type="button" class="tab-btn ${marketTab === 'mine' ? 'on' : ''}" data-mt="mine">Mes ventes (${mine.length}/5)</button>
      </div>

      ${marketTab === 'browse' ? (
        browse.length === 0 ? '<div class="empty">Aucune enchère en cours.</div>' : `<div class="stack">${browse.map((l) => {
          const c = byId(l.cardId);
          const hasBid = Boolean(l.bidderId);
          const minBid = hasBid ? l.currentBid + 1 : l.price;
          const isLead = l.bidderId === profile.uid;
          return `<div class="panel stack">
            <div class="row-between">
              <div>
                <strong>${c?.name || 'Carte'} (${c?.r})</strong>
                <div class="muted small">Vendeur : ${l.sellerName} · ${l.sellerSite} · Reste ${formatLeft(l.endsAt - now)}</div>
                <div class="badge-info ${isLead ? 'badge-lead' : 'badge-other'}" style="margin-top:4px">
                  ${isLead ? `Vous menez à ${l.currentBid} ●` : hasBid ? `Menée par ${l.bidderName} (${l.bidderSite}) à ${l.currentBid} ●` : `Prix de départ : ${l.price} ● (aucune enchère)`}
                </div>
              </div>
              <div style="display:flex;gap:8px;align-items:center">
                <input type="number" class="field" style="width:105px;margin:0" min="${minBid}" placeholder="${minBid} ●" id="bid-${l.id}" />
                <button class="btn primary" data-bid="${l.id}">Enchérir</button>
              </div>
            </div>
          </div>`;
        }).join('')}</div>`
      ) : (
        mine.length === 0 ? '<div class="empty">Aucune enchère active publiée.</div>' : `<div class="stack">${mine.map((l) => {
          const c = byId(l.cardId);
          const hasBid = Boolean(l.bidderId);
          return `<div class="panel row-between">
            <div>
              <strong>${c?.name}</strong> <span class="muted small">· Départ ${l.price} ● · ${formatLeft(l.endsAt - now)}</span>
              <div class="badge-info ${hasBid ? 'badge-lead' : 'muted'}" style="margin-top:4px">
                ${hasBid ? `En tête : ${l.bidderName} (${l.bidderSite}) mène à ${l.currentBid} ● (${l.bidCount} offre${l.bidCount > 1 ? 's' : ''})` : 'Aucun enchérisseur pour l’instant'}
              </div>
            </div>
            ${!hasBid ? `<button class="btn danger" data-cancel-l="${l.id}">Retirer</button>` : `<span class="small muted">En cours</span>`}
          </div>`;
        }).join('')}</div>`
      )}
    </div>`;

  $$('[data-mt]').forEach((b) => { b.onclick = () => { marketTab = b.dataset.mt; renderMarket(); }; });

  $$('[data-bid]').forEach((b) => {
    b.onclick = async () => {
      const l = listings.find((x) => x.id === b.dataset.bid);
      if (!l) return;
      const minBid = l.bidderId ? l.currentBid + 1 : l.price;
      const val = Math.floor(Number($(`#bid-${l.id}`).value) || minBid);
      if (val < minBid) return toast(`Enchère minimum : ${minBid} ●`);
      const extra = l.bidderId === profile.uid ? val - l.currentBid : val;
      if (profile.coins < extra) return toast('Pièces ● insuffisantes');
      try {
        await runTransaction(db, async (tx) => {
          const lRef = doc(db, 'listings', l.id);
          const pRef = doc(db, 'players', profile.uid);
          const ld = (await tx.get(lRef)).data();
          const pd = (await tx.get(pRef)).data();
          if (ld.status !== 'active' || ld.endsAt <= Date.now()) throw new Error('Enchère terminée');
          const needed = ld.bidderId ? ld.currentBid + 1 : ld.price;
          if (val < needed) throw new Error(`Minimum : ${needed} ●`);
          const cost = ld.bidderId === profile.uid ? val - ld.currentBid : val;
          if (pd.coins < cost) throw new Error('Pièces insuffisantes');
          tx.update(pRef, sanitizePlayer({ ...pd, coins: pd.coins - cost }));
          if (ld.bidderId && ld.bidderId !== profile.uid) {
            tx.set(doc(db, 'bidRefunds', `${l.id}_${ld.bidCount}`), {
              listingId: l.id, userId: ld.bidderId, cardId: ld.cardId, amount: ld.currentBid,
              claimed: false, createdAt: serverTimestamp(), updatedAt: serverTimestamp()
            });
          }
          tx.update(lRef, {
            currentBid: val, bidderId: profile.uid, bidderName: profile.displayName,
            bidderSite: profile.site, bidCount: (ld.bidCount || 0) + 1, updatedAt: serverTimestamp()
          });
        });
        toast(`Vous menez à ${val} ● !`);
      } catch (err) { toast(err.message || 'Enchère impossible'); }
    };
  });

  $$('[data-cancel-l]').forEach((b) => {
    b.onclick = async () => {
      const l = myListings.find((x) => x.id === b.dataset.cancelL);
      if (!l || l.bidderId) return;
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pd = (await tx.get(pRef)).data();
        const inv = { ...(pd.inv || {}) };
        inv[String(l.cardId)] = (inv[String(l.cardId)] || 0) + 1;
        tx.update(pRef, sanitizePlayer({ ...pd, inv }));
        tx.update(doc(db, 'listings', l.id), { status: 'cancelled', updatedAt: serverTimestamp() });
      });
      toast('Enchère retirée');
    };
  });

  $('#openSellBtn').onclick = () => {
    const owned = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);
    if (!owned.length) return toast('Aucune carte disponible');
    let picked = owned[0].id;
    const ov = $('#sellModal');
    ov.innerHTML = `<div class="sheet-panel stack">
      <h2>Mettre aux enchères</h2>
      <label class="lbl">Carte<select id="sellSel" class="field">${owned.map((c) => `<option value="${c.id}">${c.name} (${c.r})</option>`).join('')}</select></label>
      <div class="row-2">
        <label class="lbl">Prix de départ (●)<input id="sellPrice" class="field" type="number" min="1" value="${owned[0].price}" /></label>
        <label class="lbl">Durée<select id="sellDur" class="field">
          <option value="30">30 minutes</option>
          <option value="60">1 heure</option>
          <option value="360">6 heures</option>
          <option value="720">12 heures</option>
          <option value="1440">24 heures</option>
        </select></label>
      </div>
      <button id="confirmSell" class="btn primary wide">Lancer l’enchère</button>
      <button id="closeSell" class="btn wide">Annuler</button>
    </div>`;
    ov.hidden = false;
    $('#sellSel').onchange = (e) => { picked = Number(e.target.value); $('#sellPrice').value = byId(picked).price; };
    $('#closeSell').onclick = () => { ov.hidden = true; };
    $('#confirmSell').onclick = async () => {
      const price = Math.max(1, Math.floor(Number($('#sellPrice').value)));
      const mins = Math.max(30, Number($('#sellDur').value));
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pd = (await tx.get(pRef)).data();
        const inv = { ...(pd.inv || {}) };
        if ((inv[String(picked)] || 0) < 1) throw new Error('Indisponible');
        inv[String(picked)]--;
        tx.update(pRef, sanitizePlayer({ ...pd, inv }));
        tx.set(doc(collection(db, 'listings')), {
          sellerId: profile.uid, sellerName: profile.displayName, sellerSite: profile.site,
          cardId: picked, price, currentBid: 0, bidderId: '', bidderName: '', bidderSite: '', bidCount: 0,
          endsAt: Date.now() + mins * 60000, status: 'active', buyerId: '', buyerName: '',
          sellerClaimed: false, winnerClaimed: false, createdAt: serverTimestamp(), updatedAt: serverTimestamp()
        });
      });
      ov.hidden = true;
      toast('Carte mise aux enchères !');
    };
  };
}

function renderAdmin() {
  if (!isAdminUser()) {
    $('#view-admin').innerHTML = '<div class="empty">Accès réservé aux administrateurs.</div>';
    return;
  }
  const playersList = allPlayers.some((p) => p.uid === profile.uid) ? allPlayers : [profile, ...allPlayers];
  if (!adminSelectedUid || !playersList.some((p) => p.uid === adminSelectedUid)) {
    adminSelectedUid = profile.uid;
    adminDeleteArmed = false;
  }
  const target = playersList.find((p) => p.uid === adminSelectedUid) || profile;
  const targetPromoted = adminDocs.some((a) => a.uid === target.uid);
  const mutateTarget = async (fn) => {
    await runTransaction(db, async (tx) => {
      const pRef = doc(db, 'players', target.uid);
      const snap = await tx.get(pRef);
      if (!snap.exists()) return;
      tx.update(pRef, sanitizePlayer(fn(snap.data())));
    });
  };

  $('#view-admin').innerHTML = `
    <div class="stack">
      <div>
        <h1>Panel Administration</h1>
        <p class="muted small">Super-Admins : ${SUPER_ADMIN_EMAILS.join(' · ')} (${adminDocs.length} promu(s))</p>
      </div>
      <div class="panel stack">
        <label class="lbl">Joueur géré
          <select id="admPlayerSel" class="field">
            ${playersList.map((p) => `<option value="${p.uid}" ${p.uid === target.uid ? 'selected' : ''}>${p.displayName}${p.uid === profile.uid ? ' (Vous)' : ''} · ${p.site} · ${p.coins} ● · ${p.elo} ELO</option>`).join('')}
          </select>
        </label>
        <div class="row-between">
          <div>
            <strong>${target.displayName}</strong> <span class="muted small">· ${target.site} · ${target.coins} ● · ${target.packs} paquet(s)</span>
          </div>
          ${target.uid !== profile.uid ? (targetPromoted
            ? `<button id="admDemoteBtn" class="btn danger">Retirer Admin</button>`
            : `<button id="admPromoteBtn" class="btn primary">Nommer Admin</button>`) : '<span class="muted small">Admin actif</span>'}
        </div>
      </div>

      <div class="split-grid">
        <div class="panel stack">
          <h3>Donner de l’argent &amp; paquets</h3>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <button class="btn primary" data-adm-coins="100">+100 ●</button>
            <button class="btn primary" data-adm-coins="500">+500 ●</button>
            <button class="btn primary" data-adm-coins="2000">+2000 ●</button>
            <button class="btn" data-adm-packs="5">+5 paquets</button>
            <button class="btn" data-adm-packs="20">+20 paquets</button>
          </div>
          <div class="row-2">
            <div style="display:flex;gap:6px"><input id="admCoinIn" type="number" class="field" value="1000" min="1" /><button id="admAddCoinsBtn" class="btn primary">+</button></div>
            <div style="display:flex;gap:6px"><input id="admPackIn" type="number" class="field" value="10" min="1" /><button id="admAddPacksBtn" class="btn">+</button></div>
          </div>
        </div>

        <form id="admEditForm" class="panel stack">
          <h3>Gérer le compte</h3>
          <label class="lbl">Pseudo<input id="admName" class="field" maxlength="32" value="${target.displayName}" /></label>
          <div class="row-2">
            <label class="lbl">Site<select id="admSite" class="field"><option value="Labbé" ${target.site === 'Labbé' ? 'selected' : ''}>Site Labbé</option><option value="Marceau" ${target.site === 'Marceau' ? 'selected' : ''}>Site Marceau</option></select></label>
            <label class="lbl">ELO<input id="admElo" type="number" class="field" value="${target.elo}" /></label>
          </div>
          <div class="row-2">
            <button type="submit" class="btn primary">Enregistrer compte</button>
            ${target.uid !== profile.uid ? (adminDeleteArmed
              ? `<button type="button" id="admDelConfirm" class="btn danger">Confirmer suppression</button>`
              : `<button type="button" id="admDelArm" class="btn danger">Supprimer compte</button>`) : ''}
          </div>
        </form>
      </div>

      <div class="panel stack">
        <div class="row-between">
          <h3>Donner des cartes gratuitement</h3>
          <div style="display:flex;gap:6px">
            <button id="admAllCardsBtn" class="btn primary">Tout débloquer (×1)</button>
            <button id="admClearCardsBtn" class="btn danger">Tout vider</button>
          </div>
        </div>
        <div class="grid-cards">
          ${CARDS.map((c) => {
            const q = (target.inv || {})[String(c.id)] || 0;
            return `<div class="stack" style="gap:6px">
              ${cardHTML(c, { count: q, showStats: false, interactive: false, hideIcon: true })}
              <div style="display:flex;gap:4px">
                <button class="btn danger" style="flex:1;padding:6px" data-adm-card="${c.id}" data-adm-delta="-1" ${q < 1 ? 'disabled' : ''}>-1</button>
                <button class="btn primary" style="flex:1;padding:6px" data-adm-card="${c.id}" data-adm-delta="1">+1</button>
                <button class="btn" style="flex:1;padding:6px" data-adm-card="${c.id}" data-adm-delta="5">+5</button>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>`;

  $('#admPlayerSel').onchange = (e) => { adminSelectedUid = e.target.value; adminDeleteArmed = false; renderAdmin(); };
  if ($('#admPromoteBtn')) $('#admPromoteBtn').onclick = async () => {
    await setDoc(doc(db, 'admins', target.uid), { uid: target.uid, displayName: target.displayName, grantedBy: profile.uid, createdAt: serverTimestamp() });
    toast(`${target.displayName} nommé Admin !`);
  };
  if ($('#admDemoteBtn')) $('#admDemoteBtn').onclick = async () => {
    await deleteDoc(doc(db, 'admins', target.uid));
    toast(`Droits Admin retirés à ${target.displayName}`);
  };
  $$('[data-adm-coins]').forEach((b) => {
    b.onclick = async () => {
      const amt = Number(b.dataset.admCoins);
      await mutateTarget((p) => ({ ...p, coins: (p.coins || 0) + amt }));
      toast(`+${amt} ● attribués !`);
    };
  });
  $$('[data-adm-packs]').forEach((b) => {
    b.onclick = async () => {
      const amt = Number(b.dataset.admPacks);
      await mutateTarget((p) => ({ ...p, packs: Math.min(999, (p.packs || 0) + amt) }));
      toast(`+${amt} paquet(s) attribué(s) !`);
    };
  });
  $('#admAddCoinsBtn').onclick = async () => {
    const amt = Math.max(1, Math.floor(Number($('#admCoinIn').value) || 0));
    await mutateTarget((p) => ({ ...p, coins: (p.coins || 0) + amt }));
    toast(`+${amt} ● attribués !`);
  };
  $('#admAddPacksBtn').onclick = async () => {
    const amt = Math.max(1, Math.floor(Number($('#admPackIn').value) || 0));
    await mutateTarget((p) => ({ ...p, packs: Math.min(999, (p.packs || 0) + amt) }));
    toast(`+${amt} paquet(s) attribué(s) !`);
  };
  $('#admEditForm').onsubmit = async (e) => {
    e.preventDefault();
    await mutateTarget((p) => ({
      ...p,
      displayName: $('#admName').value.trim().slice(0, 32) || p.displayName,
      site: $('#admSite').value === 'Marceau' ? 'Marceau' : 'Labbé',
      elo: Math.max(100, Math.floor(Number($('#admElo').value) || 1000))
    }));
    toast('Compte mis à jour !');
  };
  if ($('#admDelArm')) $('#admDelArm').onclick = () => { adminDeleteArmed = true; renderAdmin(); };
  if ($('#admDelConfirm')) $('#admDelConfirm').onclick = async () => {
    await deleteDoc(doc(db, 'players', target.uid));
    adminDeleteArmed = false;
    adminSelectedUid = profile.uid;
    toast('Compte joueur supprimé');
    renderAdmin();
  };
  $('#admAllCardsBtn').onclick = async () => {
    await mutateTarget((p) => {
      const next = { ...(p.inv || {}) };
      CARDS.forEach((c) => { next[String(c.id)] = Math.max(1, next[String(c.id)] || 0); });
      return { ...p, inv: next };
    });
    toast('Toutes les cartes débloquées !');
  };
  $('#admClearCardsBtn').onclick = async () => {
    await mutateTarget((p) => ({ ...p, inv: {} }));
    toast('Inventaire vidé');
  };
  $$('[data-adm-card]').forEach((b) => {
    b.onclick = async () => {
      const cid = String(b.dataset.admCard);
      const d = Number(b.dataset.admDelta);
      await mutateTarget((p) => {
        const next = { ...(p.inv || {}) };
        const q = Math.max(0, (next[cid] || 0) + d);
        if (q === 0) delete next[cid]; else next[cid] = q;
        return { ...p, inv: next };
      });
      toast(`${d > 0 ? `+${d}` : d} carte mise à jour`);
    };
  });
}

function renderLeaderboard() {
  const sorted = [...allPlayers].sort((a, b) => (b.elo || 1000) - (a.elo || 1000));
  const labbe = allPlayers.filter((p) => p.site === 'Labbé');
  const marceau = allPlayers.filter((p) => p.site === 'Marceau');
  const pts = (arr) => arr.reduce((s, p) => s + Math.max(0, p.elo - 1000) + p.wins * 35, 0);
  const lp = pts(labbe); const mp = pts(marceau);
  const pct = Math.round((lp / Math.max(1, lp + mp)) * 100);

  $('#view-leaderboard').innerHTML = `
    <div class="stack">
      <h1>Classement Global Temps Réel</h1>
      <div class="panel stack">
        <div class="row-between">
          <div><strong style="color:#2563eb">Site Labbé</strong><div class="mono">${lp} pts · ${labbe.length} joueur(s)</div></div>
          <div style="text-align:right"><strong style="color:#059669">Site Marceau</strong><div class="mono">${mp} pts · ${marceau.length} joueur(s)</div></div>
        </div>
        <div class="bar" style="width:100%;background:#10b981"><i style="width:${pct}%;background:#2563eb"></i></div>
      </div>
      <div class="panel stack">
        ${sorted.map((p, i) => `
          <div class="row-between" style="padding:10px 0;border-bottom:1px solid var(--line)">
            <div><strong class="mono">#${i + 1}</strong> ${p.displayName} <span class="muted small">${p.site}${p.classe ? ' · ' + p.classe : ''}</span></div>
            <div class="mono"><strong>${p.elo} ELO</strong> · ${p.wins}V/${p.losses}D</div>
          </div>`).join('')}
      </div>
    </div>`;
}

function renderProfile() {
  const claimed = profile.claimedAchievements || [];
  let draftClasse = profile.classe || '';
  let draftSite = profile.site || 'Labbé';

  const draw = () => {
    const curTheme = localStorage.getItem('wikijh_theme') === 'dark' ? 'dark' : 'light';
    $('#view-profile').innerHTML = `
      <div class="stack">
        <div class="panel row-between">
          <div>
            <strong>Thème de l’application</strong>
            <div class="muted small">Choisissez entre mode clair et mode sombre</div>
          </div>
          <div class="tabs">
            <button type="button" class="tab-btn ${curTheme === 'light' ? 'on' : ''}" data-theme="light">☀ Clair</button>
            <button type="button" class="tab-btn ${curTheme === 'dark' ? 'on' : ''}" data-theme="dark">🌙 Sombre</button>
          </div>
        </div>
        <div class="split-grid">
          <form id="profForm" class="panel stack">
            <h2>Profil &amp; Filière</h2>
            <label class="lbl">Pseudo<input id="pfName" class="field" maxlength="32" value="${profile.displayName}" /></label>
            <label class="lbl">Site<select id="pfSite" class="field"><option value="Labbé" ${draftSite === 'Labbé' ? 'selected' : ''}>Site Labbé (Général &amp; Techno)</option><option value="Marceau" ${draftSite === 'Marceau' ? 'selected' : ''}>Site Marceau (Lycée Pro)</option></select></label>
            <div class="lbl">Classe / Filière
              <button type="button" id="pfClasseBtn" class="field picker-btn">
                <span>${draftClasse || 'Sélectionner une classe…'}</span><span>▾</span>
              </button>
            </div>
            <button type="submit" class="btn primary">Enregistrer</button>
            <button type="button" id="logoutBtn" class="btn danger">Se déconnecter</button>
          </form>
          <div class="panel stack">
            <h2>Succès (${claimed.length} / ${ACHIEVEMENTS.length})</h2>
            ${ACHIEVEMENTS.map((a) => {
              const cur = Math.min(a.target, a.val(profile));
              const ok = claimed.includes(a.id);
              return `<div class="row-between">
                <div><strong>${a.title}</strong><div class="muted small">${a.desc} (${cur}/${a.target})</div></div>
                ${ok ? '<span class="muted small">Réclamé</span>' : `<button class="btn primary" data-ach="${a.id}" ${cur >= a.target ? '' : 'disabled'}>+${a.coins} ●</button>`}
              </div>`;
            }).join('')}
          </div>
        </div>
      </div>`;

    $$('[data-theme]').forEach((b) => {
      b.onclick = () => {
        applyTheme(b.dataset.theme);
        draw();
        toast(b.dataset.theme === 'dark' ? 'Thème sombre activé' : 'Thème clair activé');
      };
    });
    $('#pfSite').onchange = (e) => { draftSite = e.target.value; };
    $('#pfClasseBtn').onclick = () => openClassPicker(draftSite, draftClasse, (cls, st) => {
      draftClasse = cls; draftSite = st; draw();
    });
    $('#profForm').onsubmit = async (e) => {
      e.preventDefault();
      await mutateProfile((p) => ({
        ...p,
        displayName: $('#pfName').value.trim().slice(0, 32) || p.displayName,
        site: draftSite === 'Marceau' ? 'Marceau' : 'Labbé',
        classe: draftClasse.slice(0, 32)
      }));
      toast('Profil enregistré !');
    };
    $('#logoutBtn').onclick = () => signOut(auth);
    $$('[data-ach]').forEach((b) => {
      b.onclick = async () => {
        const a = ACHIEVEMENTS.find((x) => x.id === b.dataset.ach);
        await mutateProfile((p) => ({
          ...p, coins: p.coins + a.coins, claimedAchievements: [...(p.claimedAchievements || []), a.id]
        }));
        toast(`+${a.coins} ● !`);
      };
    });
  };
  draw();
}

function renderActive() {
  renderTopbar();
  if (activeTab === 'packs') renderPacks();
  if (activeTab === 'arena') renderArena();
  if (activeTab === 'collection') renderCollection();
  if (activeTab === 'trades') renderTrades();
  if (activeTab === 'market') renderMarket();
  if (activeTab === 'leaderboard') renderLeaderboard();
  if (activeTab === 'profile') renderProfile();
  if (activeTab === 'admin') renderAdmin();
}

function closeFloatingMenus() {
  $('#plusMenu').hidden = true;
  $('#notifMenu').hidden = true;
  $('#menuBackdrop').hidden = true;
}

function navigate(tab) {
  closeFloatingMenus();
  activeTab = tab;
  const viewId = `view-${tab}`;
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === viewId));
  renderActive();
}

$$('[data-nav]').forEach((b) => { b.onclick = () => navigate(b.dataset.nav); });
$$('[data-plus-toggle]').forEach((b) => {
  b.onclick = () => {
    const next = $('#plusMenu').hidden;
    closeFloatingMenus();
    if (next) {
      $('#plusMenu').hidden = false;
      $('#menuBackdrop').hidden = false;
    }
  };
});
$('#menuBackdrop').onclick = closeFloatingMenus;
$('#notifBtn').onclick = () => {
  const next = $('#notifMenu').hidden;
  closeFloatingMenus();
  if (next) {
    const list = getNotifications();
    $('#notifMenu').innerHTML = `<strong>Notifications</strong>` + (list.length === 0
      ? '<p class="muted small">Aucune notification.</p>'
      : list.map((n) => `<button type="button" class="btn" style="text-align:left" data-notif-nav="${n.nav}"><strong>${n.title}</strong><div class="muted small">${n.sub}</div></button>`).join(''));
    $$('[data-notif-nav]').forEach((btn) => { btn.onclick = () => navigate(btn.dataset.notifNav); });
    $('#notifMenu').hidden = false;
    $('#menuBackdrop').hidden = false;
  }
};
$$('[data-plus-action]').forEach((b) => {
  b.onclick = () => {
    const a = b.dataset.plusAction;
    if (a === 'profile' || a === 'achievements' || a === 'settings') navigate('profile');
    else if (a === 'admin' && isAdminUser()) navigate('admin');
    else if (a === 'arena') navigate('arena');
    else if (a === 'leaderboard') navigate('leaderboard');
  };
});
$('#coinPill').onclick = () => navigate('profile');
$$('.site-opt').forEach((b) => {
  b.onclick = () => {
    obSite = b.dataset.site;
    $$('.site-opt').forEach((x) => x.classList.toggle('active', x === b));
  };
});

$('#obClasseBtn').onclick = () => openClassPicker(obSite, obClasse, (cls, st) => {
  obClasse = cls;
  obSite = st;
  $('#obClasseText').textContent = cls;
  $('#obClasseText').classList.remove('muted');
  $$('.site-opt').forEach((x) => x.classList.toggle('active', x.dataset.site === st));
});

$('#googleBtn').onclick = async () => {
  try { await signInWithPopup(auth, provider); }
  catch (e) { $('#authErr').textContent = e.message; $('#authErr').hidden = false; }
};

$('#onboardForm').onsubmit = async (e) => {
  e.preventDefault();
  if (!obClasse) return toast('Sélectionnez votre classe / filière.');
  const fresh = sanitizePlayer({
    uid: currentUser.uid, displayName: $('#obName').value, site: obSite,
    classe: obClasse, coins: 0, packs: MAX_PACKS, inv: { '1': 1, '2': 1, '8': 1 }
  });
  await setDoc(doc(db, 'players', currentUser.uid), fresh);
  $('#onboardModal').hidden = true;
  startAppListeners();
};

function processAuctionSettlement() {
  const now = Date.now();
  myListings.filter((l) => !l.sellerClaimed && !claimedListings.has(l.id) && l.bidderId && (l.status === 'sold' || l.endsAt <= now)).forEach((l) => {
    claimedListings.add(l.id);
    runTransaction(db, async (tx) => {
      const lRef = doc(db, 'listings', l.id);
      const pRef = doc(db, 'players', currentUser.uid);
      const ld = (await tx.get(lRef)).data();
      const pd = (await tx.get(pRef)).data();
      if (ld.sellerClaimed || !ld.bidderId) return;
      const amt = ld.currentBid > 0 ? ld.currentBid : ld.price;
      tx.update(pRef, sanitizePlayer({ ...pd, coins: pd.coins + amt, marketSales: (pd.marketSales || 0) + 1 }));
      tx.update(lRef, { status: 'sold', buyerId: ld.bidderId, buyerName: ld.bidderName, sellerClaimed: true, updatedAt: serverTimestamp() });
    }).catch(() => {});
  });
  myBidListings.filter((l) => l.bidderId === currentUser.uid && !l.winnerClaimed && l.endsAt <= now && l.status !== 'cancelled' && !claimedWins.has(l.id)).forEach((l) => {
    claimedWins.add(l.id);
    runTransaction(db, async (tx) => {
      const lRef = doc(db, 'listings', l.id);
      const pRef = doc(db, 'players', currentUser.uid);
      const ld = (await tx.get(lRef)).data();
      const pd = (await tx.get(pRef)).data();
      if (ld.winnerClaimed || ld.bidderId !== currentUser.uid || ld.endsAt > Date.now()) return;
      const inv = { ...(pd.inv || {}) };
      inv[String(ld.cardId)] = (inv[String(ld.cardId)] || 0) + 1;
      tx.update(pRef, sanitizePlayer({ ...pd, inv }));
      tx.update(lRef, { status: 'sold', buyerId: ld.bidderId, buyerName: ld.bidderName, winnerClaimed: true, updatedAt: serverTimestamp() });
    }).catch(() => {});
  });
}

setInterval(() => {
  if (profile) processAuctionSettlement();
  if (profile && activeTab === 'market') renderMarket();
}, 1000);

function startAppListeners() {
  onSnapshot(doc(db, 'players', currentUser.uid), (s) => {
    if (s.exists()) { profile = s.data(); renderActive(); }
  });
  onSnapshot(doc(db, 'admins', currentUser.uid), (s) => {
    isPromotedAdmin = s.exists();
    renderTopbar();
    if (activeTab === 'admin') renderAdmin();
  }, () => { isPromotedAdmin = false; });
  onSnapshot(collection(db, 'admins'), (s) => {
    adminDocs = s.docs.map((d) => ({ uid: d.id, ...d.data() }));
    if (activeTab === 'admin') renderAdmin();
  }, () => { adminDocs = []; });
  onSnapshot(query(collection(db, 'players'), where('visibility', '==', 'public')), (s) => {
    allPlayers = s.docs.map((d) => d.data());
    if (activeTab === 'leaderboard') renderLeaderboard();
    if (activeTab === 'trades') renderTrades();
    if (activeTab === 'admin') renderAdmin();
  });
  onSnapshot(query(collection(db, 'listings'), where('status', '==', 'active')), (s) => {
    listings = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (activeTab === 'market') renderMarket();
  });
  onSnapshot(query(collection(db, 'listings'), where('sellerId', '==', currentUser.uid)), (s) => {
    myListings = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    processAuctionSettlement();
    if (activeTab === 'market') renderMarket();
  });
  onSnapshot(query(collection(db, 'listings'), where('bidderId', '==', currentUser.uid)), (s) => {
    myBidListings = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    processAuctionSettlement();
  });
  onSnapshot(query(collection(db, 'bidRefunds'), where('userId', '==', currentUser.uid)), (s) => {
    s.docs.forEach((d) => {
      const r = { id: d.id, ...d.data() };
      if (r.claimed || claimedRefunds.has(r.id)) return;
      claimedRefunds.add(r.id);
      runTransaction(db, async (tx) => {
        const rRef = doc(db, 'bidRefunds', r.id);
        const pRef = doc(db, 'players', currentUser.uid);
        const rd = (await tx.get(rRef)).data();
        const pd = (await tx.get(pRef)).data();
        if (rd.claimed) return;
        tx.update(pRef, sanitizePlayer({ ...pd, coins: pd.coins + rd.amount }));
        tx.update(rRef, { claimed: true, updatedAt: serverTimestamp() });
      }).catch(() => {});
    });
  });
  onSnapshot(query(collection(db, 'trades'), where('toId', '==', currentUser.uid)), (s) => {
    receivedTrades = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    renderTopbar();
    if (activeTab === 'trades') renderTrades();
  });
  onSnapshot(query(collection(db, 'trades'), where('fromId', '==', currentUser.uid)), (s) => {
    sentTrades = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (activeTab === 'trades') renderTrades();
    sentTrades.filter((t) => ['accepted', 'declined', 'cancelled'].includes(t.status) && !t.fromClaimed).forEach((t) => {
      runTransaction(db, async (tx) => {
        const tRef = doc(db, 'trades', t.id);
        const pRef = doc(db, 'players', currentUser.uid);
        const td = (await tx.get(tRef)).data();
        const pd = (await tx.get(pRef)).data();
        if (td.fromClaimed) return;
        const inv = { ...(pd.inv || {}) };
        (td.status === 'accepted' ? td.get : td.give).forEach((cid) => { inv[String(cid)] = (inv[String(cid)] || 0) + 1; });
        tx.update(pRef, sanitizePlayer({ ...pd, inv, tradesCompleted: (pd.tradesCompleted || 0) + (td.status === 'accepted' ? 1 : 0) }));
        tx.update(tRef, { fromClaimed: true, updatedAt: serverTimestamp() });
      }).catch(() => {});
    });
  });
  onSnapshot(query(collection(db, 'battles'), where('status', '==', 'open')), (s) => {
    openBattles = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (activeTab === 'arena') renderArena();
  });
  onSnapshot(query(collection(db, 'battleQueue'), where('status', '==', 'waiting')), (s) => {
    waitingQueue = s.docs.map((d) => d.data());
    if (activeTab === 'arena') renderArena();
  });
  onSnapshot(doc(db, 'battleQueue', currentUser.uid), (s) => {
    queueEntry = s.exists() ? s.data() : null;
    if (queueEntry?.status === 'matched') deleteDoc(doc(db, 'battleQueue', currentUser.uid)).catch(() => {});
    if (activeTab === 'arena') renderArena();
  });

  const syncBattle = (list) => {
    list.filter((b) => b.status === 'finished' && ((b.p1Id === currentUser.uid && !b.p1Claimed) || (b.p2Id === currentUser.uid && !b.p2Claimed))).forEach((b) => {
      const isP1 = b.p1Id === currentUser.uid;
      const won = b.winnerId === currentUser.uid;
      runTransaction(db, async (tx) => {
        const bRef = doc(db, 'battles', b.id);
        const pRef = doc(db, 'players', currentUser.uid);
        const bd = (await tx.get(bRef)).data();
        const pd = (await tx.get(pRef)).data();
        if (isP1 ? bd.p1Claimed : bd.p2Claimed) return;
        const nextStreak = won ? (pd.streak || 0) + 1 : 0;
        tx.update(pRef, sanitizePlayer({
          ...pd, coins: pd.coins + (won ? 65 : 20), elo: Math.max(100, pd.elo + (won ? 24 : -14)),
          wins: pd.wins + (won ? 1 : 0), losses: pd.losses + (won ? 0 : 1),
          streak: nextStreak, bestStreak: Math.max(pd.bestStreak || 0, nextStreak)
        }));
        tx.update(bRef, { [isP1 ? 'p1Claimed' : 'p2Claimed']: true, updatedAt: serverTimestamp() });
      }).catch(() => {});
    });

    activeBattle = list.find((b) => b.status === 'active') || null;
    if (activeBattle && activeBattle.p1Move.stance !== 'none' && activeBattle.p2Move.stance !== 'none') {
      runTransaction(db, async (tx) => {
        const bRef = doc(db, 'battles', activeBattle.id);
        const b = (await tx.get(bRef)).data();
        if (b.status !== 'active' || b.p1Move.stance === 'none' || b.p2Move.stance === 'none') return;
        const sum = resolveRound(b.round, b.p1Move, b.p2Move, b.p1Site, b.p2Site || 'Marceau');
        const p1s = b.p1Score + (sum.winner === 'p1' ? 1 : 0);
        const p2s = b.p2Score + (sum.winner === 'p2' ? 1 : 0);
        const done = p1s >= 2 || p2s >= 2 || b.round >= 3;
        tx.update(bRef, {
          round: done ? b.round : b.round + 1, p1Score: p1s, p2Score: p2s,
          p1Move: { cardId: 0, stance: 'none' }, p2Move: { cardId: 0, stance: 'none' },
          roundHistory: [...(b.roundHistory || []), sum], status: done ? 'finished' : 'active',
          winnerId: done ? (p1s >= p2s ? b.p1Id : b.p2Id) : '', turnStartedAt: Date.now(), updatedAt: serverTimestamp()
        });
      }).catch(() => {});
    }
    if (activeTab === 'arena') renderArena();
  };

  onSnapshot(query(collection(db, 'battles'), where('p1Id', '==', currentUser.uid)), (s) => syncBattle(s.docs.map((d) => ({ id: d.id, ...d.data() }))));
  onSnapshot(query(collection(db, 'battles'), where('p2Id', '==', currentUser.uid)), (s) => syncBattle(s.docs.map((d) => ({ id: d.id, ...d.data() }))));
}

onAuthStateChanged(auth, async (u) => {
  currentUser = u;
  if (!u) { $('#authScreen').hidden = false; $('#appShell').hidden = true; return; }
  $('#authScreen').hidden = true;
  $('#appShell').hidden = false;
  const snap = await getDoc(doc(db, 'players', u.uid));
  if (!snap.exists()) {
    $('#obName').value = u.displayName || (u.email || '').split('@')[0] || 'Élève JH';
    $('#onboardModal').hidden = false;
  } else {
    startAppListeners();
  }
});
