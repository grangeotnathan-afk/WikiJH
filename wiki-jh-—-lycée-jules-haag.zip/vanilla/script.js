import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getAuth, GoogleAuthProvider, onAuthStateChanged, signInWithPopup, signOut } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js';
import {
  collection, deleteDoc, doc, getDoc, getFirestore, onSnapshot,
  query, runTransaction, serverTimestamp, setDoc, updateDoc, where
} from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

// Remplacez ces valeurs par votre propre configuration Firebase si vous hébergez hors AI Studio
const firebaseConfig = {
  apiKey: "AIzaSyDnaYORXfGtjwcaf9tq9e8IBEksNqY1YE8",
  authDomain: "dazzling-mind-1v0ns.firebaseapp.com",
  projectId: "dazzling-mind-1v0ns",
  storageBucket: "dazzling-mind-1v0ns.firebasestorage.app",
  messagingSenderId: "989726825664",
  appId: "1:989726825664:web:dc2f7cbb66e3deb62be125"
};
const FIRESTORE_DB_ID = "ai-studio-4df8dac4-a8e8-4310-a617-786ddf969228";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app, FIRESTORE_DB_ID);
const provider = new GoogleAuthProvider();

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const MAX_PACKS = 10;
const PACK_INTERVAL_MS = 10 * 60 * 1000;
const EXTRA_PACK_COST = 120;
const DAILY_COINS = 75;
const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const RARITY_ORDER = ['EX', 'L', 'UR', 'SR', 'R', 'PC', 'C'];
const RARITY_SCORE = { C: 10, PC: 25, R: 55, SR: 110, UR: 220, L: 480, EX: 1200 };

const CARDS = [
  { id: 1, r: 'C', name: 'Site Labbé', sub: 'Commune', icon: '◆', img: '/assets/aistudio/labbe_d17a5889.jpg', campus: 'Labbé', w: 42, atk: 36, def: 42, spd: 32, rec: 8, price: 20 },
  { id: 2, r: 'PC', name: 'Site Marceau', sub: 'Peu commune', icon: '✦', img: '/assets/aistudio/marceau_9d47ae5e.jpg', campus: 'Marceau', w: 14.5, atk: 46, def: 44, spd: 44, rec: 18, price: 45 },
  { id: 3, r: 'R', name: 'Cour Intérieure Labbé', sub: 'Rare', icon: '❖', img: '/assets/aistudio/images_28d4c789.jpeg', campus: 'Labbé', w: 5.5, atk: 58, def: 64, spd: 48, rec: 35, price: 90 },
  { id: 4, r: 'SR', name: 'Atelier Pro Marceau', sub: 'Super rare', icon: '⚙', img: '/assets/aistudio/images-5_536a8b68.jpeg', campus: 'Marceau', w: 2.35, atk: 71, def: 66, spd: 62, rec: 75, price: 190 },
  { id: 5, r: 'UR', name: 'Lycée Jules Haag', sub: 'Ultra rare', icon: '✹', img: '/assets/aistudio/labbe_d17a5889.jpg', campus: 'Jules Haag', w: 0.55, atk: 84, def: 82, spd: 76, rec: 160, price: 420 },
  { id: 6, r: 'L', name: 'Jules Haag Légende', sub: 'Légendaire', icon: '♛', img: '/assets/aistudio/marceau_9d47ae5e.jpg', campus: 'Jules Haag', w: 0.14, atk: 94, def: 91, spd: 89, rec: 350, price: 950 },
  { id: 7, r: 'EX', name: 'JH Exotique', sub: 'Exotique', icon: '❂', img: '/assets/aistudio/images-2_948d2426.jpeg', campus: 'Jules Haag', w: 0.03, atk: 106, def: 100, spd: 102, rec: 800, price: 2500 },
  { id: 8, r: 'C', name: 'Cour de Marceau', sub: 'Commune', icon: '◈', img: '/assets/aistudio/images-4_d3acd662.jpeg', campus: 'Marceau', w: 18, atk: 38, def: 36, spd: 42, rec: 8, price: 22 },
  { id: 9, r: 'PC', name: 'Horloge de Labbé', sub: 'Peu commune', icon: '◷', img: '/assets/aistudio/images-3_79d7815b.jpeg', campus: 'Labbé', w: 9, atk: 43, def: 52, spd: 40, rec: 18, price: 48 },
  { id: 10, r: 'R', name: 'Verrière Marceau', sub: 'Rare', icon: '◇', img: '/assets/aistudio/marceau_9d47ae5e.jpg', campus: 'Marceau', w: 4.5, atk: 61, def: 54, spd: 66, rec: 35, price: 95 },
  { id: 11, r: 'SR', name: 'Escalier Art Déco', sub: 'Super rare', icon: '🌀', img: '/assets/aistudio/images-2_948d2426.jpeg', campus: 'Labbé', w: 1.85, atk: 74, def: 68, spd: 58, rec: 75, price: 210 },
  { id: 12, r: 'UR', name: 'Beffroi Art Déco', sub: 'Ultra rare', icon: '♜', img: '/assets/aistudio/images-3_79d7815b.jpeg', campus: 'Labbé', w: 0.48, atk: 86, def: 85, spd: 72, rec: 160, price: 440 },
  { id: 13, r: 'UR', name: 'Agora Stendhal-Marceau', sub: 'Ultra rare', icon: '✧', img: '/assets/aistudio/images-4_d3acd662.jpeg', campus: 'Marceau', w: 0.4, atk: 82, def: 80, spd: 86, rec: 160, price: 440 },
  { id: 14, r: 'L', name: 'Couronne Jules Haag', sub: 'Légendaire', icon: '✪', img: '/assets/aistudio/labbe_d17a5889.jpg', campus: 'Jules Haag', w: 0.1, atk: 92, def: 95, spd: 88, rec: 350, price: 980 },
  { id: 15, r: 'R', name: 'Amphithéâtre Labbé', sub: 'Rare', icon: '◈', img: '/assets/aistudio/images-1_7f26794d.jpeg', campus: 'Labbé', w: 4, atk: 56, def: 60, spd: 55, rec: 35, price: 95 }
];

const COSMETICS = [
  { id: 'av_horloge', type: 'avatar', name: 'Horloger', price: 0, sym: '◷' },
  { id: 'av_eclaireur', type: 'avatar', name: 'Éclaireur', price: 0, sym: '◆' },
  { id: 'av_stratege', type: 'avatar', name: 'Stratège', price: 120, sym: '♛' },
  { id: 'av_alchimiste', type: 'avatar', name: 'Ingénieur', price: 160, sym: '⚙' },
  { id: 'fr_classic', type: 'frame', name: 'Acier Sobre', price: 0 },
  { id: 'fr_labbe', type: 'frame', name: 'Cobalt Labbé', price: 140 },
  { id: 'fr_marceau', type: 'frame', name: 'Émeraude Marceau', price: 140 },
  { id: 'fr_gold', type: 'frame', name: 'Or Jules Haag', price: 300 },
  { id: 'bn_obsidian', type: 'banner', name: 'Ardoise Nuit', price: 0 },
  { id: 'ti_eleve', type: 'title', name: 'Élève de Jules Haag', price: 0 },
  { id: 'ti_duelliste', type: 'title', name: 'Duelliste Classé', price: 100 },
  { id: 'ti_legende', type: 'title', name: 'Légende Jules Haag', price: 500 }
];

const ACHIEVEMENTS = [
  { id: 'ach_first_pack', title: 'Premier Booster', desc: 'Ouvrir 1 paquet', coins: 40, target: 1, val: (p) => p.opened },
  { id: 'ach_collector_7', title: 'Explorateur', desc: '7 cartes uniques', coins: 110, target: 7, val: (p) => Object.values(p.inv || {}).filter((n) => n > 0).length },
  { id: 'ach_collector_all', title: 'Wiki Master', desc: 'Toutes les 15 cartes', coins: 450, target: 15, val: (p) => Object.values(p.inv || {}).filter((n) => n > 0).length },
  { id: 'ach_first_win', title: 'Baptême Arène', desc: '1 victoire PvP', coins: 65, target: 1, val: (p) => p.wins },
  { id: 'ach_first_trade', title: 'Entraide', desc: '1 échange finalisé', coins: 75, target: 1, val: (p) => p.tradesCompleted },
  { id: 'ach_first_sale', title: 'Négociant', desc: '1 vente au Marché', coins: 80, target: 1, val: (p) => p.marketSales }
];

const byId = (id) => CARDS.find((c) => c.id === id);
const cosById = (id) => COSMETICS.find((c) => c.id === id);

let currentUser = null;
let profile = null;
let allPlayers = [];
let listings = [];
let myListings = [];
let receivedTrades = [];
let sentTrades = [];
let openBattles = [];
let activeBattle = null;
let waitingQueue = [];
let queueEntry = null;
let activeTab = 'packs';
let selectedDeck = [];
let selectedCardForMove = null;
let selectedStance = 'assault';
let obSite = 'Labbé';

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2500);
}

function cardHTML(c, { count = 0, locked = false, selected = false, showStats = false } = {}) {
  return `<button type="button" class="jh-card ${locked ? 'locked' : ''} ${selected ? 'sel' : ''}" data-r="${c.r}" data-card="${c.id}">
    <div class="art">
      ${locked ? '' : `<img src="${c.img}" alt="${c.name}" />`}
      <span class="icon">${locked ? '?' : c.icon}</span>
      <span class="r-tag">${c.r}</span>
      ${count > 1 && !locked ? `<span class="qty">×${count}</span>` : ''}
    </div>
    <div class="info">
      <h4>${locked ? 'Carte inconnue' : c.name}</h4>
      <p>${locked ? 'Non découverte' : `${c.sub} · ${c.campus}`}</p>
      ${showStats && !locked ? `<div class="stats"><span>ATQ ${c.atk}</span><span>DEF ${c.def}</span><span>VIT ${c.spd}</span></div>` : ''}
    </div>
  </button>`;
}

function sanitizePlayer(p) {
  return {
    uid: p.uid,
    visibility: 'public',
    displayName: String(p.displayName || 'Élève JH').trim().slice(0, 32),
    site: p.site === 'Marceau' ? 'Marceau' : 'Labbé',
    classe: String(p.classe || '').slice(0, 32),
    avatarId: p.avatarId || 'av_horloge',
    frameId: p.frameId || 'fr_classic',
    bannerId: p.bannerId || 'bn_obsidian',
    titleId: p.titleId || 'ti_eleve',
    bio: String(p.bio || '').slice(0, 140),
    showcaseCardId: Number(p.showcaseCardId || 1),
    coins: Math.max(0, Math.floor(p.coins || 0)),
    packs: Math.max(0, Math.floor(p.packs || 0)),
    lastPackAt: Number(p.lastPackAt || Date.now()),
    inv: p.inv || {},
    opened: Math.max(0, Math.floor(p.opened || 0)),
    elo: Math.max(0, Math.floor(p.elo || 1000)),
    wins: Math.max(0, Math.floor(p.wins || 0)),
    losses: Math.max(0, Math.floor(p.losses || 0)),
    streak: Math.max(0, Math.floor(p.streak || 0)),
    bestStreak: Math.max(0, Math.floor(p.bestStreak || 0)),
    tradesCompleted: Math.max(0, Math.floor(p.tradesCompleted || 0)),
    marketSales: Math.max(0, Math.floor(p.marketSales || 0)),
    unlockedCosmetics: p.unlockedCosmetics || ['av_horloge', 'av_eclaireur', 'fr_classic', 'bn_obsidian', 'ti_eleve'],
    claimedAchievements: p.claimedAchievements || [],
    lastDailyAt: Number(p.lastDailyAt || 0),
    createdAt: p.createdAt || serverTimestamp(),
    updatedAt: serverTimestamp()
  };
}

async function mutateProfile(fn) {
  const ref = doc(db, 'players', currentUser.uid);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) return;
    tx.update(ref, sanitizePlayer(fn(snap.data())));
  });
}

function drawCard() {
  const tot = CARDS.reduce((s, c) => s + c.w, 0);
  let x = Math.random() * tot;
  for (const c of CARDS) {
    x -= c.w;
    if (x <= 0) return c;
  }
  return CARDS[0];
}

function resolveRound(round, m1, m2, s1, s2) {
  const c1 = byId(m1.cardId) || CARDS[0];
  const c2 = byId(m2.cardId) || CARDS[0];
  const pow = (c, st, site) => {
    let base = st === 'assault' ? c.atk * 1.2 + c.spd * 0.25 : st === 'defense' ? c.def * 1.25 + c.atk * 0.2 : c.spd * 1.2 + c.atk * 0.25;
    if (c.campus === site || c.campus === 'Jules Haag') base *= 1.1;
    return Math.round(base);
  };
  let p1Power = pow(c1, m1.stance, s1);
  let p2Power = pow(c2, m2.stance, s2);
  let note = 'Égalité tactique';
  if ((m1.stance === 'assault' && m2.stance === 'counter') || (m1.stance === 'defense' && m2.stance === 'assault') || (m1.stance === 'counter' && m2.stance === 'defense')) {
    p1Power = Math.round(p1Power * 1.18);
    note = 'Avantage J1 (+18%)';
  } else if ((m2.stance === 'assault' && m1.stance === 'counter') || (m2.stance === 'defense' && m1.stance === 'assault') || (m2.stance === 'counter' && m1.stance === 'defense')) {
    p2Power = Math.round(p2Power * 1.18);
    note = 'Avantage J2 (+18%)';
  }
  const winner = p1Power > p2Power ? 'p1' : p2Power > p1Power ? 'p2' : 'draw';
  return { round, p1CardId: c1.id, p2CardId: c2.id, p1Stance: m1.stance, p2Stance: m2.stance, p1Power, p2Power, winner, note };
}

function renderTopbar() {
  if (!profile) return;
  $('#coinVal').textContent = `${profile.coins.toLocaleString('fr-FR')} ●`;
  $('#profileLabel').textContent = `${cosById(profile.avatarId)?.sym || '◆'} Profil`;
  $$('[data-nav]').forEach((b) => b.classList.toggle('active', b.dataset.nav === activeTab));
}

function renderPacks() {
  const dailyOk = Date.now() - (profile.lastDailyAt || 0) >= DAILY_COOLDOWN_MS;
  const unique = Object.values(profile.inv || {}).filter((n) => n > 0).length;
  $('#view-packs').innerHTML = `
    <div class="split-grid">
      <div class="panel pack-hero">
        <div class="pack-num mono">${profile.packs} <span class="muted" style="font-size:20px">/ ${MAX_PACKS}</span></div>
        <div class="bar"><i style="width:${Math.min(100, profile.packs / MAX_PACKS * 100)}%"></i></div>
        <button id="openPackBtn" class="pack-btn" ${profile.packs < 1 ? 'disabled' : ''}>
          <img src="/assets/aistudio/labbe_d17a5889.jpg" alt="Labbé" />
          <div class="pack-mid">Wiki JH</div>
          <img src="/assets/aistudio/marceau_9d47ae5e.jpg" alt="Marceau" />
        </button>
        <button id="openPackCta" class="btn primary" ${profile.packs < 1 ? 'disabled' : ''}>Ouvrir un booster (5 cartes)</button>
      </div>
      <div class="stack">
        <div class="panel stack">
          <h2>Bonus &amp; Boutique Boosters</h2>
          <div class="row-between">
            <div><strong>Présence Quotidienne</strong><div class="muted small">+${DAILY_COINS} ● et +1 booster</div></div>
            <button id="dailyBtn" class="btn" ${dailyOk ? '' : 'disabled'}>${dailyOk ? 'Réclamer' : 'Déjà pris'}</button>
          </div>
          <div class="row-between">
            <div><strong>Booster Supplémentaire</strong><div class="muted small">5 cartes aléatoires</div></div>
            <button id="buyPackBtn" class="btn" ${profile.coins < EXTRA_PACK_COST ? 'disabled' : ''}>${EXTRA_PACK_COST} ●</button>
          </div>
        </div>
        <div class="panel stack">
          <div class="row-between"><span>Collection</span><strong class="mono">${unique} / ${CARDS.length}</strong></div>
          <div class="row-2">
            <button class="btn" data-nav="arena">Entrer en Arène</button>
            <button class="btn" data-nav="commerce">Marché &amp; Échanges</button>
          </div>
        </div>
      </div>
    </div>`;

  const openFn = async () => {
    if (profile.packs < 1) return;
    const pulled = Array.from({ length: 5 }, drawCard).sort((a, b) => RARITY_ORDER.indexOf(b.r) - RARITY_ORDER.indexOf(a.r));
    await mutateProfile((p) => {
      const inv = { ...(p.inv || {}) };
      pulled.forEach((c) => { inv[String(c.id)] = (inv[String(c.id)] || 0) + 1; });
      return { ...p, packs: p.packs - 1, lastPackAt: p.packs >= MAX_PACKS ? Date.now() : p.lastPackAt, opened: (p.opened || 0) + 1, inv };
    });
    const ov = $('#revealModal');
    ov.innerHTML = `<div class="sheet-panel stack">
      <h2>Cartes obtenues</h2>
      <div class="grid-mini">${pulled.map((c) => cardHTML(c, { showStats: true })).join('')}</div>
      <button id="closeReveal" class="btn primary wide">Continuer</button>
    </div>`;
    ov.hidden = false;
    $('#closeReveal').onclick = () => { ov.hidden = true; };
  };
  $('#openPackBtn').onclick = $('#openPackCta').onclick = openFn;
  $('#dailyBtn').onclick = async () => {
    await mutateProfile((p) => ({ ...p, coins: p.coins + DAILY_COINS, packs: p.packs + 1, lastDailyAt: Date.now() }));
    toast(`+${DAILY_COINS} ● et +1 booster !`);
  };
  $('#buyPackBtn').onclick = async () => {
    await mutateProfile((p) => ({ ...p, coins: p.coins - EXTRA_PACK_COST, packs: p.packs + 1 }));
    toast('+1 Booster acheté !');
  };
  $$('#view-packs [data-nav]').forEach((b) => { b.onclick = () => navigate(b.dataset.nav); });
}

function renderCollection() {
  const inv = profile.inv || {};
  const owned = CARDS.filter((c) => (inv[String(c.id)] || 0) > 0);
  let extraCount = 0; let extraCoins = 0;
  CARDS.forEach((c) => {
    const q = inv[String(c.id)] || 0;
    if (q > 1) { extraCount += q - 1; extraCoins += (q - 1) * c.rec; }
  });
  $('#view-collection').innerHTML = `
    <div class="stack">
      <div class="row-between">
        <div><h1>Collection (${owned.length} / ${CARDS.length})</h1></div>
        <button id="recycleBtn" class="btn" ${extraCount < 1 ? 'disabled' : ''}>Recycler ${extraCount} doublon(s) (+${extraCoins} ●)</button>
      </div>
      <div class="grid-cards">
        ${CARDS.map((c) => cardHTML(c, { count: inv[String(c.id)] || 0, locked: !(inv[String(c.id)] > 0), showStats: true })).join('')}
      </div>
    </div>`;
  $('#recycleBtn').onclick = async () => {
    await mutateProfile((p) => {
      const next = { ...(p.inv || {}) };
      CARDS.forEach((c) => { if ((next[String(c.id)] || 0) > 1) next[String(c.id)] = 1; });
      return { ...p, inv: next, coins: p.coins + extraCoins };
    });
    toast(`+${extraCoins} ● gagnés !`);
  };
}

function renderArena() {
  const inv = profile.inv || {};
  const owned = CARDS.filter((c) => (inv[String(c.id)] || 0) > 0);
  selectedDeck = selectedDeck.filter((id) => (inv[String(id)] || 0) > 0);
  while (selectedDeck.length < 3 && owned.length >= 3) {
    const next = owned.find((c) => !selectedDeck.includes(c.id));
    if (!next) break;
    selectedDeck.push(next.id);
  }

  if (activeBattle && activeBattle.status === 'active') {
    const isP1 = activeBattle.p1Id === profile.uid;
    const myDeck = isP1 ? activeBattle.p1Deck : activeBattle.p2Deck;
    const myMove = isP1 ? activeBattle.p1Move : activeBattle.p2Move;
    const used = (activeBattle.roundHistory || []).map((r) => isP1 ? r.p1CardId : r.p2CardId);
    const moved = myMove.stance !== 'none';

    $('#view-arena').innerHTML = `
      <div class="stack">
        <div class="panel row-between">
          <div>
            <div class="muted small">Manche ${activeBattle.round} / 3</div>
            <h2>${profile.displayName} ${isP1 ? activeBattle.p1Score : activeBattle.p2Score} — ${isP1 ? activeBattle.p2Score : activeBattle.p1Score} ${isP1 ? activeBattle.p2Name : activeBattle.p1Name}</h2>
          </div>
          <button id="forfeitBtn" class="btn danger">Abandonner</button>
        </div>
        <div class="grid-cards">
          ${myDeck.map((cid) => {
            const c = byId(cid);
            const dis = used.includes(cid);
            return `<div style="${dis ? 'opacity:.35;pointer-events:none' : ''}">${cardHTML(c, { showStats: true, selected: selectedCardForMove === cid || myMove.cardId === cid })}</div>`;
          }).join('')}
        </div>
        <div class="tabs">
          ${['assault', 'defense', 'counter'].map((st) => `<button type="button" class="tab-btn ${selectedStance === st ? 'on' : ''}" data-st="${st}">${st === 'assault' ? 'Assaut (+ATK)' : st === 'defense' ? 'Défense (+DEF)' : 'Contre (+VIT)'}</button>`).join('')}
        </div>
        <button id="sendMoveBtn" class="btn primary" ${moved || !selectedCardForMove ? 'disabled' : ''}>${moved ? 'En attente de l’adversaire…' : 'Valider le coup'}</button>
      </div>`;

    $$('#view-arena [data-card]').forEach((el) => {
      if (!moved) el.onclick = () => { selectedCardForMove = Number(el.dataset.card); renderArena(); };
    });
    $$('#view-arena [data-st]').forEach((el) => {
      if (!moved) el.onclick = () => { selectedStance = el.dataset.st; renderArena(); };
    });
    $('#sendMoveBtn').onclick = async () => {
      await updateDoc(doc(db, 'battles', activeBattle.id), {
        [isP1 ? 'p1Move' : 'p2Move']: { cardId: selectedCardForMove, stance: selectedStance },
        updatedAt: serverTimestamp()
      });
    };
    $('#forfeitBtn').onclick = async () => {
      await updateDoc(doc(db, 'battles', activeBattle.id), {
        status: 'finished',
        winnerId: isP1 ? activeBattle.p2Id : activeBattle.p1Id,
        updatedAt: serverTimestamp()
      });
    };
    return;
  }

  $('#view-arena').innerHTML = `
    <div class="split-grid">
      <div class="panel stack">
        <h2>Deck de Duel (${selectedDeck.length} / 3)</h2>
        <div class="grid-mini">${owned.map((c) => cardHTML(c, { selected: selectedDeck.includes(c.id), showStats: true })).join('')}</div>
      </div>
      <div class="stack">
        <div class="panel stack">
          <h3>Matchmaking Classé (${profile.elo} ELO)</h3>
          <p class="muted small">${waitingQueue.length} joueur(s) en attente</p>
          ${queueEntry ? `<button id="leaveQueueBtn" class="btn danger">Quitter la file d’attente</button>` : `<button id="joinQueueBtn" class="btn primary" ${selectedDeck.length !== 3 ? 'disabled' : ''}>Trouver un adversaire PvP</button>`}
        </div>
        <div class="panel stack">
          <div class="row-between"><h3>Salons Ouverts</h3><button id="createOpenBtn" class="btn">+ Créer un défi</button></div>
          ${openBattles.length === 0 ? '<div class="empty">Aucun salon ouvert</div>' : openBattles.map((b) => `
            <div class="row-between">
              <div><strong>${b.p1Name}</strong> <span class="muted small">${b.p1Site} · ${b.p1Elo} ELO</span></div>
              ${b.p1Id === profile.uid ? `<button class="btn danger" data-cancel-b="${b.id}">Annuler</button>` : `<button class="btn primary" data-join-b="${b.id}">Rejoindre</button>`}
            </div>`).join('')}
        </div>
      </div>
    </div>`;

  $$('#view-arena [data-card]').forEach((el) => {
    el.onclick = () => {
      const id = Number(el.dataset.card);
      if (selectedDeck.includes(id)) selectedDeck = selectedDeck.filter((x) => x !== id);
      else selectedDeck = selectedDeck.length >= 3 ? [...selectedDeck.slice(1), id] : [...selectedDeck, id];
      renderArena();
    };
  });
  if ($('#joinQueueBtn')) $('#joinQueueBtn').onclick = async () => {
    const opp = waitingQueue.find((w) => w.uid !== profile.uid);
    if (opp) {
      const bRef = doc(collection(db, 'battles'));
      await runTransaction(db, async (tx) => {
        const qRef = doc(db, 'battleQueue', opp.uid);
        const qSnap = await tx.get(qRef);
        if (!qSnap.exists() || qSnap.data().status !== 'waiting') throw new Error('Indisponible');
        tx.set(bRef, {
          p1Id: opp.uid, p1Name: opp.displayName, p1Site: opp.site, p1Elo: opp.elo, p1Avatar: opp.avatarId, p1Frame: opp.frameId, p1Deck: opp.deck,
          p2Id: profile.uid, p2Name: profile.displayName, p2Site: profile.site, p2Elo: profile.elo, p2Avatar: profile.avatarId, p2Frame: profile.frameId, p2Deck: selectedDeck,
          mode: 'ranked', status: 'active', round: 1, p1Score: 0, p2Score: 0,
          p1Move: { cardId: 0, stance: 'none' }, p2Move: { cardId: 0, stance: 'none' },
          roundHistory: [], winnerId: '', p1Claimed: false, p2Claimed: false, turnStartedAt: Date.now(),
          createdAt: serverTimestamp(), updatedAt: serverTimestamp()
        });
        tx.update(qRef, { status: 'matched', battleId: bRef.id, matchedWith: profile.uid, updatedAt: serverTimestamp() });
      });
    } else {
      await setDoc(doc(db, 'battleQueue', profile.uid), {
        uid: profile.uid, displayName: profile.displayName, site: profile.site, elo: profile.elo,
        avatarId: profile.avatarId, frameId: profile.frameId, deck: selectedDeck, status: 'waiting',
        battleId: '', matchedWith: '', createdAt: serverTimestamp(), updatedAt: serverTimestamp()
      });
    }
  };
  if ($('#leaveQueueBtn')) $('#leaveQueueBtn').onclick = () => deleteDoc(doc(db, 'battleQueue', profile.uid));
  $('#createOpenBtn').onclick = async () => {
    await setDoc(doc(collection(db, 'battles')), {
      p1Id: profile.uid, p1Name: profile.displayName, p1Site: profile.site, p1Elo: profile.elo, p1Avatar: profile.avatarId, p1Frame: profile.frameId, p1Deck: selectedDeck,
      p2Id: '', p2Name: '', p2Site: '', p2Elo: 0, p2Avatar: '', p2Frame: '', p2Deck: [],
      mode: 'ranked', status: 'open', round: 1, p1Score: 0, p2Score: 0,
      p1Move: { cardId: 0, stance: 'none' }, p2Move: { cardId: 0, stance: 'none' },
      roundHistory: [], winnerId: '', p1Claimed: false, p2Claimed: false, turnStartedAt: Date.now(),
      createdAt: serverTimestamp(), updatedAt: serverTimestamp()
    });
  };
  $$('[data-join-b]').forEach((b) => {
    b.onclick = () => updateDoc(doc(db, 'battles', b.dataset.joinB), {
      p2Id: profile.uid, p2Name: profile.displayName, p2Site: profile.site, p2Elo: profile.elo, p2Avatar: profile.avatarId, p2Frame: profile.frameId, p2Deck: selectedDeck,
      status: 'active', turnStartedAt: Date.now(), updatedAt: serverTimestamp()
    });
  });
  $$('[data-cancel-b]').forEach((b) => {
    b.onclick = () => updateDoc(doc(db, 'battles', b.dataset.cancelB), { status: 'cancelled', updatedAt: serverTimestamp() });
  });
}

function renderCommerce() {
  const browse = listings.filter((l) => l.sellerId !== profile.uid && l.endsAt > Date.now());
  const mine = myListings.filter((l) => l.status === 'active' && l.endsAt > Date.now());
  $('#view-commerce').innerHTML = `
    <div class="stack">
      <div class="row-between">
        <h1>Marché &amp; Échanges</h1>
        <button id="openSellBtn" class="btn primary">+ Vendre une carte</button>
      </div>
      <div class="split-grid">
        <div class="panel stack">
          <h3>En vente (${browse.length})</h3>
          ${browse.length === 0 ? '<div class="empty">Aucune carte en vente</div>' : browse.map((l) => `
            <div class="row-between">
              <div><strong>${byId(l.cardId)?.name}</strong> <span class="mono" style="color:var(--acc)">${l.price} ●</span><div class="muted small">${l.sellerName} · ${l.sellerSite}</div></div>
              <button class="btn primary" data-buy="${l.id}">Acheter</button>
            </div>`).join('')}
          ${mine.length ? `<h4>Mes ventes (${mine.length}/5)</h4>` + mine.map((l) => `
            <div class="row-between"><span>${byId(l.cardId)?.name} · ${l.price} ●</span><button class="btn danger" data-cancel-l="${l.id}">Retirer</button></div>`).join('') : ''}
        </div>
        <div class="panel stack">
          <h3>Échanges reçus (${receivedTrades.filter((t) => t.status === 'pending').length})</h3>
          ${receivedTrades.length === 0 ? '<div class="empty">Aucune offre reçue</div>' : receivedTrades.map((t) => `
            <div class="row-between">
              <div><strong>${t.fromName}</strong><div class="muted small">Offre : ${t.give.map((id) => byId(id)?.name).join(', ')}</div></div>
              ${t.status === 'pending' ? `<button class="btn primary" data-acc-t="${t.id}">Accepter</button>` : `<span class="muted small">${t.status}</span>`}
            </div>`).join('')}
        </div>
      </div>
    </div>`;

  $$('[data-buy]').forEach((b) => {
    b.onclick = async () => {
      const l = listings.find((x) => x.id === b.dataset.buy);
      if (!l || profile.coins < l.price) return toast('Pièces insuffisantes');
      await runTransaction(db, async (tx) => {
        const lRef = doc(db, 'listings', l.id);
        const pRef = doc(db, 'players', profile.uid);
        const lSnap = await tx.get(lRef);
        const pSnap = await tx.get(pRef);
        const pd = pSnap.data();
        const ld = lSnap.data();
        if (ld.status !== 'active' || pd.coins < ld.price) throw new Error('Indisponible');
        const inv = { ...(pd.inv || {}) };
        inv[String(ld.cardId)] = (inv[String(ld.cardId)] || 0) + 1;
        tx.update(pRef, sanitizePlayer({ ...pd, coins: pd.coins - ld.price, inv }));
        tx.update(lRef, { status: 'sold', buyerId: profile.uid, buyerName: profile.displayName, updatedAt: serverTimestamp() });
      });
      toast('Achat réussi !');
    };
  });
  $$('[data-cancel-l]').forEach((b) => {
    b.onclick = async () => {
      const l = myListings.find((x) => x.id === b.dataset.cancelL);
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pSnap = await tx.get(pRef);
        const pd = pSnap.data();
        const inv = { ...(pd.inv || {}) };
        inv[String(l.cardId)] = (inv[String(l.cardId)] || 0) + 1;
        tx.update(pRef, sanitizePlayer({ ...pd, inv }));
        tx.update(doc(db, 'listings', l.id), { status: 'cancelled', updatedAt: serverTimestamp() });
      });
      toast('Annonce retirée');
    };
  });
  $$('[data-acc-t]').forEach((b) => {
    b.onclick = async () => {
      const t = receivedTrades.find((x) => x.id === b.dataset.accT);
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pd = (await tx.get(pRef)).data();
        const inv = { ...(pd.inv || {}) };
        for (const id of t.get) { if ((inv[String(id)] || 0) < 1) throw new Error('Carte manquante'); inv[String(id)]--; }
        for (const id of t.give) { inv[String(id)] = (inv[String(id)] || 0) + 1; }
        tx.update(pRef, sanitizePlayer({ ...pd, inv, tradesCompleted: (pd.tradesCompleted || 0) + 1 }));
        tx.update(doc(db, 'trades', t.id), { status: 'accepted', updatedAt: serverTimestamp() });
      });
      toast('Échange accepté !');
    };
  });
  $('#openSellBtn').onclick = () => {
    const owned = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);
    if (!owned.length) return toast('Aucune carte à vendre');
    let picked = owned[0].id;
    const ov = $('#sellModal');
    ov.innerHTML = `<div class="sheet-panel stack">
      <h2>Mettre en vente</h2>
      <label class="lbl">Carte<select id="sellSel" class="field">${owned.map((c) => `<option value="${c.id}">${c.name} (${c.r})</option>`).join('')}</select></label>
      <label class="lbl">Prix (●)<input id="sellPrice" class="field" type="number" min="1" value="${owned[0].price}" /></label>
      <button id="confirmSell" class="btn primary wide">Confirmer</button>
      <button id="closeSell" class="btn wide">Annuler</button>
    </div>`;
    ov.hidden = false;
    $('#sellSel').onchange = (e) => { picked = Number(e.target.value); $('#sellPrice').value = byId(picked).price; };
    $('#closeSell').onclick = () => { ov.hidden = true; };
    $('#confirmSell').onclick = async () => {
      const price = Math.max(1, Math.floor(Number($('#sellPrice').value)));
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pd = (await tx.get(pRef)).data();
        const inv = { ...(pd.inv || {}) };
        if ((inv[String(picked)] || 0) < 1) throw new Error('Indisponible');
        inv[String(picked)]--;
        tx.update(pRef, sanitizePlayer({ ...pd, inv }));
        tx.set(doc(collection(db, 'listings')), {
          sellerId: profile.uid, sellerName: profile.displayName, sellerSite: profile.site,
          cardId: picked, price, endsAt: Date.now() + 3600000, status: 'active',
          buyerId: '', buyerName: '', sellerClaimed: false, createdAt: serverTimestamp(), updatedAt: serverTimestamp()
        });
      });
      ov.hidden = true;
      toast('Mise en vente publiée !');
    };
  };
}

function renderLeaderboard() {
  const sorted = [...allPlayers].sort((a, b) => (b.elo || 1000) - (a.elo || 1000));
  const labbe = allPlayers.filter((p) => p.site === 'Labbé');
  const marceau = allPlayers.filter((p) => p.site === 'Marceau');
  const pts = (arr) => arr.reduce((s, p) => s + Math.max(0, p.elo - 1000) + p.wins * 35, 0);
  const lp = pts(labbe); const mp = pts(marceau);
  const pct = Math.round((lp / Math.max(1, lp + mp)) * 100);

  $('#view-leaderboard').innerHTML = `
    <div class="stack">
      <h1>Classement Global Temps Réel</h1>
      <div class="panel stack">
        <div class="row-between">
          <div><strong style="color:#60a5fa">Site Labbé</strong><div class="mono">${lp} pts · ${labbe.length} joueur(s)</div></div>
          <div style="text-align:right"><strong style="color:#34d399">Site Marceau</strong><div class="mono">${mp} pts · ${marceau.length} joueur(s)</div></div>
        </div>
        <div class="bar" style="width:100%;background:#10b981"><i style="width:${pct}%;background:#3b82f6"></i></div>
      </div>
      <div class="panel stack">
        ${sorted.map((p, i) => `
          <div class="row-between" style="padding:8px 0;border-bottom:1px solid var(--line)">
            <div><strong class="mono">#${i + 1}</strong> ${p.displayName} <span class="muted small">${p.site}</span></div>
            <div class="mono"><strong>${p.elo} ELO</strong> · ${p.wins}V/${p.losses}D</div>
          </div>`).join('')}
      </div>
    </div>`;
}

function renderProfile() {
  const claimed = profile.claimedAchievements || [];
  $('#view-profile').innerHTML = `
    <div class="split-grid">
      <form id="profForm" class="panel stack">
        <h2>Profil &amp; Personnalisation</h2>
        <label class="lbl">Pseudo<input id="pfName" class="field" maxlength="32" value="${profile.displayName}" /></label>
        <label class="lbl">Site<select id="pfSite" class="field"><option value="Labbé" ${profile.site === 'Labbé' ? 'selected' : ''}>Site Labbé (Général &amp; Techno)</option><option value="Marceau" ${profile.site === 'Marceau' ? 'selected' : ''}>Site Marceau (Lycée Pro)</option></select></label>
        <label class="lbl">Classe<input id="pfClasse" class="field" maxlength="32" value="${profile.classe}" /></label>
        <button type="submit" class="btn primary">Enregistrer</button>
        <button type="button" id="logoutBtn" class="btn danger">Se déconnecter</button>
      </form>
      <div class="panel stack">
        <h2>Succès (${claimed.length} / ${ACHIEVEMENTS.length})</h2>
        ${ACHIEVEMENTS.map((a) => {
          const cur = Math.min(a.target, a.val(profile));
          const ok = claimed.includes(a.id);
          return `<div class="row-between">
            <div><strong>${a.title}</strong><div class="muted small">${a.desc} (${cur}/${a.target})</div></div>
            ${ok ? '<span class="muted small">Réclamé</span>' : `<button class="btn primary" data-ach="${a.id}" ${cur >= a.target ? '' : 'disabled'}>+${a.coins} ●</button>`}
          </div>`;
        }).join('')}
      </div>
    </div>`;

  $('#profForm').onsubmit = async (e) => {
    e.preventDefault();
    await mutateProfile((p) => ({
      ...p,
      displayName: $('#pfName').value.trim().slice(0, 32) || p.displayName,
      site: $('#pfSite').value === 'Marceau' ? 'Marceau' : 'Labbé',
      classe: $('#pfClasse').value.trim().slice(0, 32)
    }));
    toast('Profil enregistré !');
  };
  $('#logoutBtn').onclick = () => signOut(auth);
  $$('[data-ach]').forEach((b) => {
    b.onclick = async () => {
      const a = ACHIEVEMENTS.find((x) => x.id === b.dataset.ach);
      await mutateProfile((p) => ({
        ...p,
        coins: p.coins + a.coins,
        claimedAchievements: [...(p.claimedAchievements || []), a.id]
      }));
      toast(`+${a.coins} ● !`);
    };
  });
}

function renderActive() {
  renderTopbar();
  if (activeTab === 'packs') renderPacks();
  if (activeTab === 'arena') renderArena();
  if (activeTab === 'collection') renderCollection();
  if (activeTab === 'commerce') renderCommerce();
  if (activeTab === 'leaderboard') renderLeaderboard();
  if (activeTab === 'profile') renderProfile();
}

function navigate(tab) {
  activeTab = tab;
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === `view-${tab}`));
  renderActive();
}

$$('[data-nav]').forEach((b) => { b.onclick = () => navigate(b.dataset.nav); });
$$('.site-opt').forEach((b) => {
  b.onclick = () => {
    obSite = b.dataset.site;
    $$('.site-opt').forEach((x) => x.classList.toggle('active', x === b));
  };
});

$('#googleBtn').onclick = async () => {
  try {
    await signInWithPopup(auth, provider);
  } catch (e) {
    $('#authErr').textContent = e.message;
    $('#authErr').hidden = false;
  }
};

$('#onboardForm').onsubmit = async (e) => {
  e.preventDefault();
  const fresh = sanitizePlayer({
    uid: currentUser.uid,
    displayName: $('#obName').value,
    site: obSite,
    classe: $('#obClasse').value,
    coins: 150,
    packs: MAX_PACKS,
    inv: { '1': 1, '2': 1, '8': 1 }
  });
  await setDoc(doc(db, 'players', currentUser.uid), fresh);
  $('#onboardModal').hidden = true;
  startAppListeners();
};

function startAppListeners() {
  onSnapshot(doc(db, 'players', currentUser.uid), (s) => {
    if (s.exists()) { profile = s.data(); renderActive(); }
  });
  onSnapshot(query(collection(db, 'players'), where('visibility', '==', 'public')), (s) => {
    allPlayers = s.docs.map((d) => d.data());
    if (activeTab === 'leaderboard') renderLeaderboard();
  });
  onSnapshot(query(collection(db, 'listings'), where('status', '==', 'active')), (s) => {
    listings = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (activeTab === 'commerce') renderCommerce();
  });
  onSnapshot(query(collection(db, 'listings'), where('sellerId', '==', currentUser.uid)), (s) => {
    myListings = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    myListings.filter((l) => l.status === 'sold' && !l.sellerClaimed).forEach((l) => {
      runTransaction(db, async (tx) => {
        const lRef = doc(db, 'listings', l.id);
        const pRef = doc(db, 'players', currentUser.uid);
        const ld = (await tx.get(lRef)).data();
        const pd = (await tx.get(pRef)).data();
        if (ld.status !== 'sold' || ld.sellerClaimed) return;
        tx.update(pRef, sanitizePlayer({ ...pd, coins: pd.coins + ld.price, marketSales: (pd.marketSales || 0) + 1 }));
        tx.update(lRef, { sellerClaimed: true, updatedAt: serverTimestamp() });
      }).catch(() => {});
    });
    if (activeTab === 'commerce') renderCommerce();
  });
  onSnapshot(query(collection(db, 'trades'), where('toId', '==', currentUser.uid)), (s) => {
    receivedTrades = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (activeTab === 'commerce') renderCommerce();
  });
  onSnapshot(query(collection(db, 'trades'), where('fromId', '==', currentUser.uid)), (s) => {
    sentTrades = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    sentTrades.filter((t) => ['accepted', 'declined', 'cancelled'].includes(t.status) && !t.fromClaimed).forEach((t) => {
      runTransaction(db, async (tx) => {
        const tRef = doc(db, 'trades', t.id);
        const pRef = doc(db, 'players', currentUser.uid);
        const td = (await tx.get(tRef)).data();
        const pd = (await tx.get(pRef)).data();
        if (td.fromClaimed) return;
        const inv = { ...(pd.inv || {}) };
        (td.status === 'accepted' ? td.get : td.give).forEach((cid) => { inv[String(cid)] = (inv[String(cid)] || 0) + 1; });
        tx.update(pRef, sanitizePlayer({ ...pd, inv, tradesCompleted: (pd.tradesCompleted || 0) + (td.status === 'accepted' ? 1 : 0) }));
        tx.update(tRef, { fromClaimed: true, updatedAt: serverTimestamp() });
      }).catch(() => {});
    });
  });
  onSnapshot(query(collection(db, 'battles'), where('status', '==', 'open')), (s) => {
    openBattles = s.docs.map((d) => ({ id: d.id, ...d.data() }));
    if (activeTab === 'arena') renderArena();
  });
  onSnapshot(query(collection(db, 'battleQueue'), where('status', '==', 'waiting')), (s) => {
    waitingQueue = s.docs.map((d) => d.data());
    if (activeTab === 'arena') renderArena();
  });
  onSnapshot(doc(db, 'battleQueue', currentUser.uid), (s) => {
    queueEntry = s.exists() ? s.data() : null;
    if (queueEntry?.status === 'matched') deleteDoc(doc(db, 'battleQueue', currentUser.uid)).catch(() => {});
    if (activeTab === 'arena') renderArena();
  });

  const syncBattle = (list) => {
    list.filter((b) => b.status === 'finished' && ((b.p1Id === currentUser.uid && !b.p1Claimed) || (b.p2Id === currentUser.uid && !b.p2Claimed))).forEach((b) => {
      const isP1 = b.p1Id === currentUser.uid;
      const won = b.winnerId === currentUser.uid;
      runTransaction(db, async (tx) => {
        const bRef = doc(db, 'battles', b.id);
        const pRef = doc(db, 'players', currentUser.uid);
        const bd = (await tx.get(bRef)).data();
        const pd = (await tx.get(pRef)).data();
        if (isP1 ? bd.p1Claimed : bd.p2Claimed) return;
        const nextStreak = won ? (pd.streak || 0) + 1 : 0;
        tx.update(pRef, sanitizePlayer({
          ...pd,
          coins: pd.coins + (won ? 65 : 20),
          elo: Math.max(100, pd.elo + (won ? 24 : -14)),
          wins: pd.wins + (won ? 1 : 0),
          losses: pd.losses + (won ? 0 : 1),
          streak: nextStreak,
          bestStreak: Math.max(pd.bestStreak || 0, nextStreak)
        }));
        tx.update(bRef, { [isP1 ? 'p1Claimed' : 'p2Claimed']: true, updatedAt: serverTimestamp() });
      }).catch(() => {});
    });

    activeBattle = list.find((b) => b.status === 'active') || null;
    if (activeBattle && activeBattle.p1Move.stance !== 'none' && activeBattle.p2Move.stance !== 'none') {
      runTransaction(db, async (tx) => {
        const bRef = doc(db, 'battles', activeBattle.id);
        const b = (await tx.get(bRef)).data();
        if (b.status !== 'active' || b.p1Move.stance === 'none' || b.p2Move.stance === 'none') return;
        const sum = resolveRound(b.round, b.p1Move, b.p2Move, b.p1Site, b.p2Site || 'Marceau');
        const p1s = b.p1Score + (sum.winner === 'p1' ? 1 : 0);
        const p2s = b.p2Score + (sum.winner === 'p2' ? 1 : 0);
        const done = p1s >= 2 || p2s >= 2 || b.round >= 3;
        tx.update(bRef, {
          round: done ? b.round : b.round + 1,
          p1Score: p1s, p2Score: p2s,
          p1Move: { cardId: 0, stance: 'none' }, p2Move: { cardId: 0, stance: 'none' },
          roundHistory: [...(b.roundHistory || []), sum],
          status: done ? 'finished' : 'active',
          winnerId: done ? (p1s >= p2s ? b.p1Id : b.p2Id) : '',
          turnStartedAt: Date.now(), updatedAt: serverTimestamp()
        });
      }).catch(() => {});
    }
    if (activeTab === 'arena') renderArena();
  };

  onSnapshot(query(collection(db, 'battles'), where('p1Id', '==', currentUser.uid)), (s) => {
    syncBattle(s.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
  onSnapshot(query(collection(db, 'battles'), where('p2Id', '==', currentUser.uid)), (s) => {
    syncBattle(s.docs.map((d) => ({ id: d.id, ...d.data() })));
  });
}

onAuthStateChanged(auth, async (u) => {
  currentUser = u;
  if (!u) {
    $('#authScreen').hidden = false;
    $('#appShell').hidden = true;
    return;
  }
  $('#authScreen').hidden = true;
  $('#appShell').hidden = false;
  const snap = await getDoc(doc(db, 'players', u.uid));
  if (!snap.exists()) {
    $('#obName').value = u.displayName || (u.email || '').split('@')[0] || 'Élève JH';
    $('#onboardModal').hidden = false;
  } else {
    startAppListeners();
  }
});
