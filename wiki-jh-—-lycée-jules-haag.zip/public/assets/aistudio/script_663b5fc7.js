(() => {
'use strict';


const firebaseConfig = {
  apiKey: "AIzaSyBXAUd1glfT05sP0PU_u7JOdFuvOsww1ik",
  authDomain: "wikijh-e39cb.firebaseapp.com",
  projectId: "wikijh-e39cb",
  storageBucket: "wikijh-e39cb.firebasestorage.app",
  messagingSenderId: "748249053695",
  appId: "1:748249053695:android:16c03feb0e6a6968138fca"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

const MAX = 10, PER = 5, INTERVAL = 10 * 60 * 1000, SLOTS = 5;
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];

const CARDS = [
  { id: 1, r: 'C',  name: 'Site Labbé',    sub: 'Commune',     icon: '◆', img: 'img/labbe.jpg',   w: 72.75 },
  { id: 2, r: 'PC', name: 'Site Marceau',  sub: 'Peu commune', icon: '✦', img: 'img/marceau.jpg', w: 18.32 },
  { id: 3, r: 'R',  name: 'Bâtiment Labbé',   sub: 'Rare',       icon: '❖', img: 'img/labbe.jpg',   w: 6.2 },
  { id: 4, r: 'SR', name: 'Bâtiment Marceau', sub: 'Super rare', icon: '✺', img: 'img/marceau.jpg', w: 2.26 },
  { id: 5, r: 'UR', name: 'Lycée Jules Haag', sub: 'Ultra rare', icon: '✹', img: 'img/labbe.jpg',   w: 0.4 },
  { id: 6, r: 'L',  name: 'Jules Haag Légende', sub: 'Légendaire', icon: '♛', img: 'img/marceau.jpg', w: 0.059 },
  { id: 7, r: 'EX', name: 'JH Exotique',      sub: 'Exotique',   icon: '❂', img: 'img/labbe.jpg',   w: 0.00036 },
];
const RORDER = ['EX', 'L', 'UR', 'SR', 'R', 'PC', 'C'];
const byId = id => CARDS.find(c => c.id === id);
const fmt = n => n.toLocaleString('fr-FR');

let user = null;
let profile = null;
let usersCache = [];
let marketTab = 'browse';
let tradeTab = 'received';
let giveSel = new Set(), getSel = new Set(), tradeTarget = null;

function freshProfile() {
  return { packs: MAX, last: Date.now(), coins: 100, inv: {}, opened: 0, created: Date.now() };
}

function cardHTML(c, o = {}) {
  const cls = ['card'];
  if (o.locked) cls.push('locked');
  if (['UR', 'L'].includes(c.r) && !o.locked) cls.push('sheen');
  if (c.r === 'EX' && !o.locked) cls.push('ex');
  if (o.mini) cls.push('mini');
  const art = o.locked
    ? '<div class="art">?</div>'
    : `<div class="art"><div class="photo" style="background-image:url(${c.img})"></div><span class="icon">${c.icon}</span></div>`;
  return `<div class="${cls.join(' ')}" data-r="${c.r}" data-id="${c.id}">
    <span class="badge">${c.r}</span>${o.count > 1 ? `<span class="count">×${o.count}</span>` : ''}
    ${art}
    <div class="info"><h4>${o.locked ? '???' : c.name}</h4><p style="margin:0">${o.locked ? 'Carte non découverte' : c.sub}</p></div></div>`;
}

function miniCardHTML(c) {
  return `<div class="mini-card" data-r="${c.r}"><div class="art"><div class="photo" style="background-image:url(${c.img})"></div><span>${c.icon}</span></div><div class="nm">${c.name}</div></div>`;
}

function toast(m) {
  const t = $('#toast');
  t.textContent = m;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 2200);
}

function lock(on) {
  const b = document.body;
  if (on) { b.dataset.y = scrollY; b.style.top = -scrollY + 'px'; b.classList.add('lock'); }
  else if (b.classList.contains('lock')) { b.classList.remove('lock'); b.style.top = ''; scrollTo(0, +b.dataset.y || 0); }
}

function bump() { const c = $('#coins'); c.classList.add('bump'); setTimeout(() => c.classList.remove('bump'), 250); }

async function loadProfile() {
  const snap = await db.collection('users').doc(user.uid).get();
  if (snap.exists) {
    profile = Object.assign(freshProfile(), snap.data());
    if (!profile.inv) profile.inv = {};
  } else {
    profile = freshProfile();
    await saveProfile();
  }
}

async function saveProfile() {
  await db.collection('users').doc(user.uid).set(profile, { merge: true });
}

function tick() {
  if (!profile) return;
  const now = Date.now();
  if (profile.packs >= MAX) { profile.packs = MAX; profile.last = now; return; }
  const gain = Math.floor((now - profile.last) / INTERVAL);
  if (gain > 0) {
    profile.packs = Math.min(MAX, profile.packs + gain);
    profile.last = profile.packs >= MAX ? now : profile.last + gain * INTERVAL;
    saveProfile();
  }
}

function refresh() {
  if (!profile) return;
  tick();
  $('#packCount').textContent = profile.packs;
  $('#coinVal').textContent = fmt(profile.coins);
  $('#packBar').style.width = (profile.packs / MAX * 100) + '%';
  $('#packBtn').classList.toggle('disabled', profile.packs < 1);
  $('#openBtn').disabled = profile.packs < 1;
  const t = $('#timerLine');
  if (profile.packs >= MAX) { t.innerHTML = 'Paquets au maximum'; }
  else {
    const left = Math.max(0, INTERVAL - (Date.now() - profile.last));
    const m = Math.floor(left / 60000), s = Math.floor(left % 60000 / 1000);
    t.innerHTML = `Prochain dans <b id="timer">${m}:${String(s).padStart(2, '0')}</b>`;
  }
}
setInterval(refresh, 1000);
document.addEventListener('visibilitychange', refresh);

function draw() {
  const tot = CARDS.reduce((a, c) => a + c.w, 0);
  let x = Math.random() * tot;
  for (const c of CARDS) { if ((x -= c.w) < 0) return c; }
  return CARDS[0];
}

const CUT = 13;
const TEETH = 22, AMP = 1.1;
const zigTop = () => { const p = []; for (let i = 0; i < TEETH; i++) p.push(`${(i / TEETH * 100).toFixed(2)}% 0%`, `${((i + .5) / TEETH * 100).toFixed(2)}% ${AMP}%`); p.push('100% 0%'); return p; };
const zigBot = () => { const p = []; for (let i = TEETH; i > 0; i--) p.push(`${(i / TEETH * 100).toFixed(2)}% 100%`, `${((i - .5) / TEETH * 100).toFixed(2)}% ${100 - AMP}%`); p.push('0% 100%'); return p; };
const tear = (() => { const p = []; for (let i = 0; i <= 16; i++) p.push([i / 16 * 100, CUT + (((i * 37) % 7) - 3) * .32]); return p; })();
const tearFwd = () => tear.map(([x, y]) => `${x.toFixed(2)}% ${y.toFixed(2)}%`);
const poly = pts => `polygon(${pts.join(',')})`;
const CLIP_ALL = poly([...zigTop(), ...zigBot()]);
const CLIP_TOP = poly([...zigTop(), ...tearFwd().reverse()]);
const CLIP_MAIN = poly([...tearFwd(), ...zigBot()]);
const artHTML = clip => `<div class="pk-art" style="clip-path:${clip}"><div class="pk-crimp t"></div><div class="pk-frame"></div><div class="pk-photo p1"></div>
  <div class="pk-mid"><i>◆ ◆ ◆</i><em>Wiki JH</em><small>Booster · 5 cartes</small></div><div class="pk-photo p2"></div><div class="pk-crimp b"></div><div class="pk-shade"></div><div class="pk-gloss"></div></div>`;

const packBtn = $('#packBtn');
packBtn.innerHTML = artHTML(CLIP_ALL);
const pkStageEl = $('.pack-stage');
pkStageEl.addEventListener('pointermove', e => {
  const r = packBtn.getBoundingClientRect();
  packBtn.style.setProperty('--ry', ((e.clientX - r.left) / r.width - .5) * 18 + 'deg');
  packBtn.style.setProperty('--rx', -((e.clientY - r.top) / r.height - .5) * 18 + 'deg');
});
pkStageEl.addEventListener('pointerleave', () => { packBtn.style.setProperty('--rx', '0deg'); packBtn.style.setProperty('--ry', '0deg'); });

let busy = false;
let phase = 'idle', pulled = [], idx = 0, cut = null, cutP = 0;

async function openPack() {
  if (busy || !$('#reveal').hidden) return;
  tick();
  if (profile.packs < 1) return;
  busy = true;
  if (profile.packs === MAX) profile.last = Date.now();
  profile.packs--;
  profile.opened++;
  const list = Array.from({ length: PER }, draw).sort((a, b) => RORDER.indexOf(b.r) - RORDER.indexOf(a.r));
  list.forEach(c => profile.inv[c.id] = (profile.inv[c.id] || 0) + 1);
  await saveProfile();
  refresh();
  showReveal(list);
}
$('#openBtn').onclick = packBtn.onclick = openPack;

function setCut(p, dir = 1) {
  cutP = p;
  const cl = $('#cutline');
  cl.style.setProperty('--p', p);
  cl.style.setProperty('--o', dir > 0 ? 'left' : 'right');
  cl.style.setProperty('--k', dir > 0 ? p * 100 : (1 - p) * 100);
  $('#pkTop').style.transform = p ? `rotate(${p * 3 * dir}deg) translateY(${-p * 1.5}px)` : '';
}

function showReveal(list) {
  pulled = list; idx = 0; phase = 'cut'; cut = null;
  const ov = $('#reveal'), st = $('#pkStage');
  ov.classList.remove('exburst');
  $('#revealHint').classList.remove('exhint');
  ov.hidden = false;
  lock(true);
  st.hidden = false;
  st.classList.remove('opened');
  $('#cardStage').hidden = true;
  $('#summary').hidden = true;
  $('#pkMain').innerHTML = artHTML(CLIP_MAIN);
  $('#pkTop').innerHTML = artHTML(CLIP_TOP);
  const cl = $('#cutline');
  cl.classList.remove('drag', 'auto');
  setCut(0);
}

const ovl = $('#reveal');
ovl.addEventListener('pointerdown', e => {
  if (phase !== 'cut' || e.target.closest('.close')) return;
  cut = { x: e.clientX, t: performance.now(), dir: 1, moved: false, w: $('#pk').getBoundingClientRect().width };
});
ovl.addEventListener('pointermove', e => {
  if (!cut) return;
  const dx = e.clientX - cut.x;
  if (Math.abs(dx) > 6) { cut.moved = true; cut.dir = dx > 0 ? 1 : -1; $('#cutline').classList.add('drag'); }
  if (cut.moved) setCut(Math.min(1, Math.abs(dx) / (cut.w * .8)), cut.dir);
});
const endCut = () => {
  if (!cut) return;
  const c = cut;
  cut = null;
  if (phase !== 'cut') return;
  if (cutP >= .55) { setCut(1, c.dir); openUp(); }
  else if (!c.moved) { $('#cutline').classList.add('drag', 'auto'); setCut(1, 1); phase = 'opening'; setTimeout(openUp, 260); }
  else setCut(0, c.dir);
};
ovl.addEventListener('pointerup', endCut);
ovl.addEventListener('pointercancel', endCut);

function openUp() {
  phase = 'opening';
  $('#pkStage').classList.add('opened');
  if (navigator.vibrate) navigator.vibrate([20, 30, 40]);
  setTimeout(startCards, 720);
}

function startCards() {
  if (phase !== 'opening') return;
  $('#pkStage').hidden = true;
  $('#cardStage').hidden = false;
  $('#revealStack').innerHTML = pulled.map(c => `<div class="cw">${cardHTML(c)}</div>`).join('');
  $('#dots').innerHTML = pulled.map(() => '<i></i>').join('');
  phase = 'cards';
  idx = 0;
  requestAnimationFrame(() => requestAnimationFrame(() => showCard(0)));
}

function showCard(i) {
  const ws = $$('#revealStack .cw'), c = pulled[i];
  ws.forEach((w, k) => { w.classList.toggle('cur', k === i); w.classList.toggle('gone', k < i); });
  if (['SR', 'UR', 'L', 'EX'].includes(c.r)) ws[i].classList.add('glow');
  const cap = $('#cardCap');
  cap.textContent = `${c.name} · ${c.sub}`;
  cap.style.color = `var(--${c.r})`;
  $$('#dots i').forEach((d, k) => d.classList.toggle('on', k === i));
  const h = $('#revealHint');
  h.classList.toggle('exhint', c.r === 'EX');
  h.textContent = c.r === 'EX' ? '✦ EXOTIQUE ✦' : i === PER - 1 ? 'Touchez pour terminer' : "Touchez n'importe où pour continuer";
  if (c.r === 'EX') { ovl.classList.remove('exburst'); void ovl.offsetWidth; ovl.classList.add('exburst'); }
  if (navigator.vibrate) navigator.vibrate(c.r === 'EX' ? [40, 40, 40, 40, 120] : c.r === 'L' ? [30, 40, 60] : 10);
}

ovl.addEventListener('click', e => {
  if (phase !== 'cards' || e.target.closest('.close')) return;
  if (idx < PER - 1) { idx++; showCard(idx); } else finishReveal();
});

function finishReveal() {
  phase = 'summary';
  $$('#revealStack .cw')[idx].classList.replace('cur', 'gone');
  setTimeout(() => {
    $('#cardStage').hidden = true;
    const again = $('#again');
    again.classList.add('wait');
    setTimeout(() => again.classList.remove('wait'), 600);
    $('#summaryGrid').innerHTML = pulled.map((c, i) => cardHTML(c, { mini: true }).replace('class="card', `style="animation-delay:${i * .07}s" class="card`)).join('');
    $('#summary').hidden = false;
  }, 220);
}

const closeReveal = () => {
  if (phase === 'cut' || phase === 'opening') toast('Cartes ajoutées à votre collection');
  phase = 'idle';
  cut = null;
  ovl.hidden = true;
  lock(false);
  refresh();
  setTimeout(() => busy = false, 500);
};
$('#revealClose').onclick = $('#again').onclick = closeReveal;

let page = 1, filter = new Set();
const PAGE = 50;

function renderCollection() {
  const owned = CARDS.filter(c => profile.inv[c.id] > 0);
  const have = RORDER.filter(r => owned.some(c => c.r === r));
  filter.forEach(r => { if (!have.includes(r)) filter.delete(r); });
  const fr = $('#rarityFilters');
  fr.hidden = !have.length;
  fr.innerHTML = have.map(r => `<button class="rf ${filter.has(r) ? 'on' : ''}" data-r="${r}" style="color:var(--rc)">${r}</button>`).join('');
  $$('.rf').forEach(b => b.onclick = () => { filter.has(b.dataset.r) ? filter.delete(b.dataset.r) : filter.add(b.dataset.r); page = 1; renderCollection(); });
  const q = $('#search').value.trim().toLowerCase();
  const list = [...owned].reverse().filter(c => (!filter.size || filter.has(c.r)) && (c.name + ' ' + c.sub).toLowerCase().includes(q));
  const pages = Math.max(1, Math.ceil(list.length / PAGE));
  page = Math.min(page, pages);
  $('.pager').hidden = pages <= 1;
  $('#pageInfo').textContent = `Page ${page} / ${pages}`;
  $('#prev').disabled = page <= 1;
  $('#next').disabled = page >= pages;
  $('#ownedChip').textContent = `${owned.length} / ${CARDS.length}`;
  $('#grid').innerHTML = list.slice((page - 1) * PAGE, page * PAGE).map(c => cardHTML(c, { count: profile.inv[c.id] })).join('')
    || `<p class="muted empty" style="grid-column:1/-1">${owned.length ? 'Aucune carte trouvée.' : "Vous n'avez encore aucune carte. Ouvrez un paquet !"}</p>`;
  $$('#grid .card').forEach(el => el.onclick = () => showDetail(+el.dataset.id));
}
$('#search').oninput = () => { page = 1; renderCollection(); };
$('#prev').onclick = () => { page--; renderCollection(); };
$('#next').onclick = () => { page++; renderCollection(); };

function showDetail(id) {
  const c = byId(id), box = $('#detailCard');
  box.innerHTML = cardHTML(c, { count: profile.inv[id] }).replace('class="card', 'class="card tilt');
  $('#detail').hidden = false;
  lock(true);
  const el = box.firstElementChild;
  const mv = e => {
    const r = el.getBoundingClientRect(), p = e.touches ? e.touches[0] : e;
    const x = (p.clientX - r.left) / r.width, y = (p.clientY - r.top) / r.height;
    el.style.transform = `rotateY(${(x - .5) * 24}deg) rotateX(${(.5 - y) * 24}deg)`;
    el.style.setProperty('--px', (120 - x * 180) + '%');
  };
  box.onmousemove = mv;
  box.ontouchmove = e => { e.preventDefault(); mv(e); };
  box.onmouseleave = box.ontouchend = () => { el.style.transform = ''; };
}
const closeDetail = () => { $('#detail').hidden = true; lock(false); };
$('#detailClose').onclick = closeDetail;
$('#detail').onclick = e => { if (e.target.id === 'detail') closeDetail(); };
$('#detail').ontouchmove = e => e.preventDefault();

const fmtT = ms => { const s = Math.max(0, Math.ceil(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}:${String(s % 60).padStart(2, '0')}`; };

async function renderMarket() {
  const mySnap = await db.collection('listings').where('seller', '==', user.uid).get();
  const active = [];
  mySnap.forEach(d => { const l = d.data(); if (!l.sold && l.end > Date.now()) active.push({ id: d.id, ...l }); });
  $('#slotChip').textContent = `${active.length} / ${SLOTS}`;
  $('#sellBtn').disabled = active.length >= SLOTS;

  if (marketTab === 'browse') {
    const snap = await db.collection('listings').where('sold', '==', false).get();
    const now = Date.now();
    const items = [];
    snap.forEach(d => {
      const l = d.data();
      if (l.end > now && l.seller !== user.uid) items.push({ id: d.id, ...l });
    });
    items.sort((a, b) => a.end - b.end);
    $('#marketPanel').innerHTML = items.length ? items.map(l => {
      const c = byId(l.card);
      return `<div class="row">${cardHTML(c, { mini: true })}
        <div class="mid"><b>${c.name}</b><div class="price"><span>${fmt(l.price)} ●</span></div>
        <div class="muted">Vendeur : ${l.sellerName} · ${l.sellerSite}<br>Se termine dans <span class="tl" data-end="${l.end}">${fmtT(l.end - Date.now())}</span></div></div>
        <button class="btn small" data-buy="${l.id}">Acheter</button></div>`;
    }).join('') : '<div class="empty">Aucune carte en vente pour le moment.</div>';
    $$('[data-buy]').forEach(b => b.onclick = () => buyListing(b.dataset.buy));
  }

  if (marketTab === 'mine') {
    $('#marketPanel').innerHTML = active.length ? active.map(l => {
      const c = byId(l.card);
      return `<div class="row">${cardHTML(c, { mini: true })}
        <div class="mid"><b>${c.name}</b><div class="price"><span>${fmt(l.price)} ●</span></div>
        <div class="muted">Se termine dans <span class="tl" data-end="${l.end}">${fmtT(l.end - Date.now())}</span></div></div>
        <button class="btn small danger" data-cancel="${l.id}">Retirer</button></div>`;
    }).join('') : '<div class="empty">Vous n'avez aucune carte en vente.</div>';
    $$('[data-cancel]').forEach(b => b.onclick = () => cancelListing(b.dataset.cancel));
  }
}

async function buyListing(id) {
  const ref = db.collection('listings').doc(id);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      if (!snap.exists) throw new Error('Vente introuvable');
      const l = snap.data();
      if (l.sold) throw new Error('Déjà vendue');
      if (l.end < Date.now()) throw new Error('Vente expirée');
      if (l.seller === user.uid) throw new Error('Vous ne pouvez pas acheter votre propre carte');
      const buyerSnap = await tx.get(db.collection('users').doc(user.uid));
      const buyer = buyerSnap.data();
      if (buyer.coins < l.price) throw new Error('Pièces insuffisantes');
      const sellerSnap = await tx.get(db.collection('users').doc(l.seller));
      const seller = sellerSnap.data();
      tx.update(db.collection('users').doc(user.uid), { coins: buyer.coins - l.price, [`inv.${l.card}`]: (buyer.inv[l.card] || 0) + 1 });
      tx.update(db.collection('users').doc(l.seller), { coins: seller.coins + l.price });
      tx.update(ref, { sold: true, buyer: user.uid, buyerName: profile.name });
    });
    await loadProfile();
    refresh();
    bump();
    toast('Achat réussi !');
    renderMarket();
  } catch (e) {
    toast(e.message);
  }
}

async function cancelListing(id) {
  const ref = db.collection('listings').doc(id);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      if (!snap.exists) throw new Error('Vente introuvable');
      const l = snap.data();
      if (l.sold) throw new Error('Déjà vendue');
      const mySnap = await tx.get(db.collection('users').doc(user.uid));
      const me = mySnap.data();
      tx.update(db.collection('users').doc(user.uid), { [`inv.${l.card}`]: (me.inv[l.card] || 0) + 1 });
      tx.delete(ref);
    });
    await loadProfile();
    refresh();
    toast('Carte retirée du marché');
    renderMarket();
  } catch (e) {
    toast(e.message);
  }
}

let picked = null;
function openSell() {
  const own = CARDS.filter(c => profile.inv[c.id] > 0).reverse();
  if (!own.length) return toast('Vous n'avez aucune carte à vendre');
  picked = null;
  $('#priceIn').value = '';
  $('#picker').innerHTML = own.map(c => cardHTML(c, { mini: true, count: profile.inv[c.id] })).join('');
  $$('#picker .card').forEach(el => el.onclick = () => {
    $$('#picker .card').forEach(x => x.classList.remove('sel'));
    el.classList.add('sel');
    picked = +el.dataset.id;
  });
  $('#sellSheet').hidden = false;
  lock(true);
}
function closeSell() { $('#sellSheet').hidden = true; lock(false); }
$('#sellBtn').onclick = openSell;
$('#sellClose').onclick = closeSell;
$('#sellSheet').onclick = e => { if (e.target.id === 'sellSheet') closeSell(); };

$('#sellConfirm').onclick = async () => {
  const price = Math.floor(+$('#priceIn').value);
  if (!picked) return toast('Choisissez une carte');
  if (!(price >= 1)) return toast('Entrez un prix valide');
  if (!(profile.inv[picked] > 0)) return toast('Carte indisponible');
  const mySnap = await db.collection('listings').where('seller', '==', user.uid).get();
  const active = [];
  mySnap.forEach(d => { const l = d.data(); if (!l.sold && l.end > Date.now()) active.push(d.id); });
  if (active.length >= SLOTS) return toast('5 cartes maximum en vente');
  profile.inv[picked]--;
  await saveProfile();
  await db.collection('listings').add({
    card: picked,
    price,
    seller: user.uid,
    sellerName: profile.name,
    sellerSite: profile.site,
    end: Date.now() + (+$('#durIn').value) * 60000,
    sold: false,
    created: Date.now()
  });
  closeSell();
  toast('Carte mise en vente');
  renderMarket();
};

async function resolveExpired() {
  if (!user) return;
  const now = Date.now();
  const snap = await db.collection('listings').where('seller', '==', user.uid).where('sold', '==', false).get();
  snap.forEach(async d => {
    const l = d.data();
    if (l.end <= now) {
      await db.runTransaction(async tx => {
        const sellerSnap = await tx.get(db.collection('users').doc(l.seller));
        const seller = sellerSnap.data();
        tx.update(db.collection('users').doc(l.seller), { [`inv.${l.card}`]: (seller.inv[l.card] || 0) + 1 });
        tx.delete(d.ref);
      });
      await loadProfile();
      refresh();
      toast(`${byId(l.card).name} n'a pas trouvé preneur, carte retirée`);
      if (marketTab) renderMarket();
    }
  });
}
setInterval(resolveExpired, 30000);

async function renderTrades() {
  const received = await db.collection('trades').where('to', '==', user.uid).orderBy('created', 'desc').limit(30).get();
  const sent = await db.collection('trades').where('from', '==', user.uid).orderBy('created', 'desc').limit(30).get();

  const pendingReceived = [];
  received.forEach(d => { const t = d.data(); if (t.status === 'pending') pendingReceived.push({ id: d.id, ...t }); });
  $('#tradeChip').textContent = pendingReceived.length;
  $('#bellDot').hidden = pendingReceived.length === 0;

  if (tradeTab === 'received') {
    const items = [];
    received.forEach(d => items.push({ id: d.id, ...d.data() }));
    $('#tradePanel').innerHTML = items.length ? items.map(t => tradeOfferHTML(t, 'received')).join('') : '<div class="empty">Aucune offre reçue.</div>';
    $$('[data-accept]').forEach(b => b.onclick = () => respondTrade(b.dataset.accept, true));
    $$('[data-decline]').forEach(b => b.onclick = () => respondTrade(b.dataset.decline, false));
  }

  if (tradeTab === 'sent') {
    const items = [];
    sent.forEach(d => items.push({ id: d.id, ...d.data() }));
    $('#tradePanel').innerHTML = items.length ? items.map(t => tradeOfferHTML(t, 'sent')).join('') : '<div class="empty">Aucune offre envoyée.</div>';
    $$('[data-cancel-trade]').forEach(b => b.onclick = () => cancelTrade(b.dataset.cancelTrade));
  }

  if (tradeTab === 'new') {
    renderTradeForm();
  }
}

function tradeOfferHTML(t, dir) {
  const giveCards = t.give.map(id => byId(id));
  const getCards = t.get.map(id => byId(id));
  const other = dir === 'received' ? t.fromName : t.toName;
  const otherSite = dir === 'received' ? t.fromSite : t.toSite;
  let status = '';
  if (t.status === 'accepted') status = '<span class="status-tag ok">Acceptée</span>';
  if (t.status === 'declined') status = '<span class="status-tag no">Refusée</span>';
  if (t.status === 'cancelled') status = '<span class="status-tag">Annulée</span>';
  if (t.status === 'pending') status = '<span class="status-tag">En attente</span>';
  let actions = '';
  if (dir === 'received' && t.status === 'pending') {
    actions = `<div class="trade-actions"><button class="btn small danger" data-decline="${t.id}">Refuser</button><button class="btn small" data-accept="${t.id}">Accepter</button></div>`;
  }
  if (dir === 'sent' && t.status === 'pending') {
    actions = `<div class="trade-actions"><button class="btn small danger" data-cancel-trade="${t.id}">Annuler</button></div>`;
  }
  return `<div class="trade-offer">
    <div class="who"><span>${dir === 'received' ? 'De' : 'À'} : ${other} <span class="site">· ${otherSite}</span></span>${status}</div>
    <div class="trade-cols">
      <div class="trade-col"><h5>Vous donnez</h5><div class="cards">${giveCards.map(miniCardHTML).join('') || '<span class="muted">—</span>'}</div></div>
      <div class="trade-col"><h5>Vous recevez</h5><div class="cards">${getCards.map(miniCardHTML).join('') || '<span class="muted">—</span>'}</div></div>
    </div>
    ${actions}
  </div>`;
}

async function respondTrade(id, accept) {
  const ref = db.collection('trades').doc(id);
  try {
    await db.runTransaction(async tx => {
      const snap = await tx.get(ref);
      if (!snap.exists) throw new Error('Offre introuvable');
      const t = snap.data();
      if (t.status !== 'pending') throw new Error('Offre déjà traitée');
      if (accept) {
        const fromSnap = await tx.get(db.collection('users').doc(t.from));
        const toSnap = await tx.get(db.collection('users').doc(t.to));
        const from = fromSnap.data(), to = toSnap.data();
        for (const cid of t.give) {
          if (!(from.inv[cid] > 0)) throw new Error(`${byId(cid).name} n'est plus disponible chez ${t.fromName}`);
        }
        for (const cid of t.get) {
          if (!(to.inv[cid] > 0)) throw new Error(`Vous n'avez plus ${byId(cid).name}`);
        }
        const fromInv = { ...from.inv }, toInv = { ...to.inv };
        t.give.forEach(cid => { fromInv[cid]--; toInv[cid] = (toInv[cid] || 0) + 1; });
        t.get.forEach(cid => { toInv[cid]--; fromInv[cid] = (fromInv[cid] || 0) + 1; });
        tx.update(db.collection('users').doc(t.from), { inv: fromInv });
        tx.update(db.collection('users').doc(t.to), { inv: toInv });
        tx.update(ref, { status: 'accepted' });
      } else {
        tx.update(ref, { status: 'declined' });
      }
    });
    await loadProfile();
    refresh();
    toast(accept ? 'Échange accepté !' : 'Échange refusé');
    renderTrades();
  } catch (e) {
    toast(e.message);
  }
}

async function cancelTrade(id) {
  await db.collection('trades').doc(id).update({ status: 'cancelled' });
  toast('Offre annulée');
  renderTrades();
}

async function loadUsers() {
  const snap = await db.collection('users').get();
  usersCache = [];
  snap.forEach(d => {
    if (d.id !== user.uid) usersCache.push({ uid: d.id, ...d.data() });
  });
}

function renderTradeForm() {
  giveSel = new Set();
  getSel = new Set();
  tradeTarget = null;
  $('#tradeUser').value = '';
  $('#userList').innerHTML = '';
  $('#getPicker').innerHTML = '';
  const doubles = CARDS.filter(c => profile.inv[c.id] > 1);
  $('#givePicker').innerHTML = doubles.length ? doubles.map(c => cardHTML(c, { mini: true, count: profile.inv[c.id] })).join('') : '<div class="empty" style="grid-column:1/-1">Vous n'avez pas de carte en double à échanger.</div>';
  $$('#givePicker .card').forEach(el => el.onclick = () => {
    const id = +el.dataset.id;
    if (giveSel.has(id)) { giveSel.delete(id); el.classList.remove('sel'); }
    else { giveSel.add(id); el.classList.add('sel'); }
  });
}

$('#tradeUser').oninput = async () => {
  const q = $('#tradeUser').value.trim().toLowerCase();
  if (!q) { $('#userList').innerHTML = ''; return; }
  await loadUsers();
  const matches = usersCache.filter(u => u.name && u.name.toLowerCase().includes(q)).slice(0, 8);
  $('#userList').innerHTML = matches.map(u => `<div class="user-item" data-uid="${u.uid}"><span>${u.name}</span><span class="site">${u.site || ''}</span></div>`).join('') || '<div class="empty">Aucun joueur trouvé.</div>';
  $$('.user-item').forEach(el => el.onclick = async () => {
    $$('.user-item').forEach(x => x.classList.remove('sel'));
    el.classList.add('sel');
    tradeTarget = el.dataset.uid;
    const target = usersCache.find(u => u.uid === tradeTarget);
    const theirCards = CARDS.filter(c => target.inv && target.inv[c.id] > 0);
    $('#getPicker').innerHTML = theirCards.length ? theirCards.map(c => cardHTML(c, { mini: true, count: target.inv[c.id] })).join('') : '<div class="empty" style="grid-column:1/-1">Ce joueur n'a aucune carte.</div>';
    $$('#getPicker .card').forEach(el2 => el2.onclick = () => {
      const id = +el2.dataset.id;
      if (getSel.has(id)) { getSel.delete(id); el2.classList.remove('sel'); }
      else { getSel.add(id); el2.classList.add('sel'); }
    });
  });
};

$('#tradeConfirm').onclick = async () => {
  if (!tradeTarget) return toast('Choisissez un joueur');
  if (!giveSel.size && !getSel.size) return toast('Sélectionnez au moins une carte');
  const target = usersCache.find(u => u.uid === tradeTarget);
  await db.collection('trades').add({
    from: user.uid,
    fromName: profile.name,
    fromSite: profile.site,
    to: tradeTarget,
    toName: target.name,
    toSite: target.site,
    give: [...giveSel],
    get: [...getSel],
    status: 'pending',
    created: Date.now()
  });
  $('#tradeSheet').hidden = true;
  lock(false);
  toast('Offre envoyée !');
  tradeTab = 'sent';
  $$('.ttab').forEach(b => b.classList.toggle('on', b.dataset.ttab === 'sent'));
  renderTrades();
};

function go(v) {
  $$('.view').forEach(e => e.classList.toggle('active', e.id === 'view-' + v));
  $$('#tabbar [data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === v));
  $('#moreMenu').hidden = true;
  scrollTo({ top: 0 });
  if (v === 'collection') renderCollection();
  if (v === 'trades') renderTrades();
  if (v === 'market') renderMarket();
}
$$('#tabbar [data-view]').forEach(b => b.onclick = () => go(b.dataset.view));
$('#moreBtn').onclick = e => { e.stopPropagation(); $('#moreMenu').hidden = !$('#moreMenu').hidden; };
document.addEventListener('click', e => { if (!e.target.closest('#moreMenu')) $('#moreMenu').hidden = true; });
$$('[data-go]').forEach(b => b.onclick = () => go(b.dataset.go));
$('#resetBtn').onclick = async () => {
  if (confirm('Réinitialiser toute la partie ?')) {
    profile = freshProfile();
    await saveProfile();
    refresh();
    go('packs');
    toast('Partie réinitialisée');
  }
};
$('#logoutBtn').onclick = () => auth.signOut();
$('#bellBtn').onclick = () => { go('trades'); };

$$('.mtab').forEach(b => b.onclick = () => {
  marketTab = b.dataset.mtab;
  $$('.mtab').forEach(x => x.classList.toggle('on', x === b));
  renderMarket();
});
$$('.ttab').forEach(b => b.onclick = () => {
  tradeTab = b.dataset.ttab;
  $$('.ttab').forEach(x => x.classList.toggle('on', x === b));
  renderTrades();
});

$('#tradeClose').onclick = () => { $('#tradeSheet').hidden = true; lock(false); };
$('#tradeSheet').onclick = e => { if (e.target.id === 'tradeSheet') { $('#tradeSheet').hidden = true; lock(false); } };

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    if (!$('#detail').hidden) closeDetail();
    if (!$('#sellSheet').hidden) closeSell();
    if (!$('#reveal').hidden) closeReveal();
    if (!$('#tradeSheet').hidden) { $('#tradeSheet').hidden = true; lock(false); }
  }
});

setInterval(() => { $$('.tl').forEach(e => e.textContent = fmtT(+e.dataset.end - Date.now())); }, 1000);

auth.onAuthStateChanged(async u => {
  if (u) {
    user = u;
    const email = u.email || '';
    let site = 'Labbé';
    if (email.toLowerCase().includes('marceau')) site = 'Marceau';
    const name = u.displayName || email.split('@')[0];
    const snap = await db.collection('users').doc(u.uid).get();
    if (snap.exists) {
      profile = Object.assign(freshProfile(), snap.data());
      profile.name = name;
      profile.site = profile.site || site;
    } else {
      profile = freshProfile();
      profile.name = name;
      profile.site = site;
    }
    await saveProfile();
    $('#authScreen').hidden = true;
    $('#appShell').hidden = false;
    refresh();
    go('packs');
  } else {
    user = null;
    profile = null;
    $('#authScreen').hidden = false;
    $('#appShell').hidden = true;
  }
});

$('#googleBtn').onclick = async () => {
  $('#authErr').hidden = true;
  try {
    const provider = new firebase.auth.GoogleAuthProvider();
    await auth.signInWithPopup(provider);
  } catch (e) {
    $('#authErr').textContent = e.message;
    $('#authErr').hidden = false;
  }
};
})();

