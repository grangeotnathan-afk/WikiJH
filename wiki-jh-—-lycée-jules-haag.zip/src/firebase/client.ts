import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import {
  doc,
  getDocFromServer,
  getFirestore,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { DEFAULT_UNLOCKED_COSMETICS, MAX_PACKS } from '../data/gameData';
import { OperationType, type PlayerProfile, type Site } from '../types/game';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Veuillez vérifier votre configuration Firebase.');
    }
  }
}

export const SUPER_ADMIN_EMAILS = [
  'grangeotnathan@gmail.com',
  'darkknight1111100000@gmail.com',
] as const;

export function isSuperAdminEmail(email?: string | null): boolean {
  if (!email) return false;
  return SUPER_ADMIN_EMAILS.includes(email.trim().toLowerCase() as (typeof SUPER_ADMIN_EMAILS)[number]);
}

export function buildFreshPlayer(
  uid: string,
  displayName: string,
  site: Site
): PlayerProfile {
  const safeName = displayName.trim().slice(0, 32) || 'Élève JH';
  return {
    uid,
    visibility: 'public',
    displayName: safeName,
    site,
    classe: 'Terminale',
    avatarId: 'av_horloge',
    frameId: 'fr_classic',
    bannerId: site === 'Labbé' ? 'bn_obsidian' : 'bn_obsidian',
    titleId: 'ti_eleve',
    bio: `Élève du site ${site} · Lycée Jules Haag`,
    showcaseCardId: site === 'Labbé' ? 1 : 2,
    coins: 0,
    packs: MAX_PACKS,
    lastPackAt: Date.now(),
    inv: { '1': 1, '2': 1, '8': 1 },
    opened: 0,
    elo: 1000,
    wins: 0,
    losses: 0,
    streak: 0,
    bestStreak: 0,
    tradesCompleted: 0,
    marketSales: 0,
    unlockedCosmetics: [...DEFAULT_UNLOCKED_COSMETICS],
    claimedAchievements: [],
    lastDailyAt: 0,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

export function sanitizePlayerUpdate(p: PlayerProfile): Record<string, unknown> {
  return {
    uid: p.uid,
    visibility: 'public',
    displayName: p.displayName.trim().slice(0, 32) || 'Élève JH',
    site: p.site === 'Marceau' ? 'Marceau' : 'Labbé',
    classe: (p.classe || '').trim().slice(0, 32),
    avatarId: (p.avatarId || 'av_horloge').slice(0, 32),
    frameId: (p.frameId || 'fr_classic').slice(0, 32),
    bannerId: (p.bannerId || 'bn_obsidian').slice(0, 32),
    titleId: (p.titleId || 'ti_eleve').slice(0, 32),
    bio: (p.bio || '').trim().slice(0, 140),
    showcaseCardId: Math.max(0, Math.min(100, Math.floor(p.showcaseCardId || 0))),
    coins: Math.max(0, Math.min(100000000, Math.floor(p.coins || 0))),
    packs: Math.max(0, Math.min(999, Math.floor(p.packs || 0))),
    lastPackAt: Math.max(0, Number(p.lastPackAt || Date.now())),
    inv: p.inv || {},
    opened: Math.max(0, Math.floor(p.opened || 0)),
    elo: Math.max(0, Math.min(10000, Math.floor(p.elo || 1000))),
    wins: Math.max(0, Math.floor(p.wins || 0)),
    losses: Math.max(0, Math.floor(p.losses || 0)),
    streak: Math.max(0, Math.floor(p.streak || 0)),
    bestStreak: Math.max(0, Math.floor(p.bestStreak || 0)),
    tradesCompleted: Math.max(0, Math.floor(p.tradesCompleted || 0)),
    marketSales: Math.max(0, Math.floor(p.marketSales || 0)),
    unlockedCosmetics: (p.unlockedCosmetics || []).slice(0, 60),
    claimedAchievements: (p.claimedAchievements || []).slice(0, 60),
    lastDailyAt: Math.max(0, Number(p.lastDailyAt || 0)),
    createdAt: p.createdAt || serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}
