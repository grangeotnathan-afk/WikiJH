import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  runTransaction,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import {
  ChevronDown,
  Coins,
  Layers,
  Package,
  Search,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  UserCheck,
  UserMinus,
  Users,
} from 'lucide-react';
import { CARDS, RARITY_META } from '../data/gameData';
import {
  SUPER_ADMIN_EMAILS,
  db,
  handleFirestoreError,
  sanitizePlayerUpdate,
} from '../firebase/client';
import {
  OperationType,
  type AdminGrantDoc,
  type PlayerProfile,
  type Site,
} from '../types/game';
import { CardVisual } from './CardVisual';
import { ClassPickerModal } from './ClassPickerModal';

interface AdminViewProps {
  profile: PlayerProfile;
  allPlayers: PlayerProfile[];
  onToast: (msg: string) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  profile,
  allPlayers,
  onToast,
}) => {
  const [adminDocs, setAdminDocs] = useState<AdminGrantDoc[]>([]);
  const [selectedUid, setSelectedUid] = useState<string>(profile.uid);
  const [search, setSearch] = useState('');
  const [customCoins, setCustomCoins] = useState('1000');
  const [customPacks, setCustomPacks] = useState('10');

  // Account edit form for selected player
  const [editName, setEditName] = useState('');
  const [editSite, setEditSite] = useState<Site>('Labbé');
  const [editClasse, setEditClasse] = useState('');
  const [editElo, setEditElo] = useState('1000');
  const [editCoins, setEditCoins] = useState('0');
  const [editPacks, setEditPacks] = useState('0');
  const [editWins, setEditWins] = useState('0');
  const [editLosses, setEditLosses] = useState('0');
  const [classPickerOpen, setClassPickerOpen] = useState(false);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'admins'),
      (snap) => {
        setAdminDocs(snap.docs.map((d) => d.data() as AdminGrantDoc));
      },
      (err) => {
        // Only super admins or listed admins can list /admins
        console.error(err);
      }
    );
    return () => unsub();
  }, []);

  const targetPlayer = useMemo(() => {
    return allPlayers.find((p) => p.uid === selectedUid) || profile;
  }, [allPlayers, selectedUid, profile]);

  useEffect(() => {
    setEditName(targetPlayer.displayName);
    setEditSite(targetPlayer.site);
    setEditClasse(targetPlayer.classe || '');
    setEditElo(String(targetPlayer.elo));
    setEditCoins(String(targetPlayer.coins));
    setEditPacks(String(targetPlayer.packs));
    setEditWins(String(targetPlayer.wins));
    setEditLosses(String(targetPlayer.losses));
  }, [targetPlayer]);

  const filteredPlayers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...allPlayers]
      .sort((a, b) => {
        if (a.uid === profile.uid) return -1;
        if (b.uid === profile.uid) return 1;
        return a.displayName.localeCompare(b.displayName);
      })
      .filter((p) => !q || `${p.displayName} ${p.site} ${p.classe} ${p.uid}`.toLowerCase().includes(q));
  }, [allPlayers, profile.uid, search]);

  const adminUidSet = useMemo(() => new Set(adminDocs.map((a) => a.uid)), [adminDocs]);

  const mutateTargetPlayer = async (
    updater: (cur: PlayerProfile) => PlayerProfile,
    successMsg: string
  ) => {
    const pRef = doc(db, 'players', targetPlayer.uid);
    try {
      await runTransaction(db, async (tx) => {
        const snap = await tx.get(pRef);
        if (!snap.exists()) throw new Error('Joueur introuvable');
        const current = snap.data() as PlayerProfile;
        const next = updater(current);
        tx.update(pRef, sanitizePlayerUpdate(next));
      });
      onToast(successMsg);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `players/${targetPlayer.uid}`);
    }
  };

  const handleAddCoins = async (delta: number) => {
    await mutateTargetPlayer(
      (p) => ({ ...p, coins: Math.max(0, p.coins + delta) }),
      `${delta >= 0 ? `+${delta}` : delta} ● appliqué à ${targetPlayer.displayName}`
    );
  };

  const handleSetCoinsExact = async () => {
    const val = Math.max(0, Math.floor(Number(customCoins) || 0));
    await mutateTargetPlayer(
      (p) => ({ ...p, coins: val }),
      `Solde de ${targetPlayer.displayName} défini à ${val.toLocaleString('fr-FR')} ●`
    );
  };

  const handleAddPacks = async (delta: number) => {
    await mutateTargetPlayer(
      (p) => ({ ...p, packs: Math.max(0, Math.min(999, p.packs + delta)) }),
      `+${delta} paquet(s) donné(s) à ${targetPlayer.displayName}`
    );
  };

  const handleGiveCard = async (cardId: number, qtyDelta: number) => {
    const card = CARDS.find((c) => c.id === cardId);
    await mutateTargetPlayer((p) => {
      const nextInv = { ...(p.inv || {}) };
      const k = String(cardId);
      const nextQ = Math.max(0, (nextInv[k] || 0) + qtyDelta);
      if (nextQ === 0) delete nextInv[k];
      else nextInv[k] = nextQ;
      return { ...p, inv: nextInv };
    }, `${qtyDelta > 0 ? `+${qtyDelta}` : qtyDelta}× ${card?.name || 'Carte'} pour ${targetPlayer.displayName}`);
  };

  const handleGiveAllCards = async () => {
    await mutateTargetPlayer((p) => {
      const nextInv = { ...(p.inv || {}) };
      for (const c of CARDS) {
        const k = String(c.id);
        nextInv[k] = Math.max(1, nextInv[k] || 0);
      }
      return { ...p, inv: nextInv };
    }, `Toutes les ${CARDS.length} cartes débloquées pour ${targetPlayer.displayName} !`);
  };

  const handleResetInventory = async () => {
    await mutateTargetPlayer(
      (p) => ({ ...p, inv: {} }),
      `Inventaire de ${targetPlayer.displayName} vidé.`
    );
  };

  const handleSaveAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = editName.trim().slice(0, 32);
    if (!cleanName) {
      onToast('Le pseudo ne peut pas être vide.');
      return;
    }
    await mutateTargetPlayer(
      (p) => ({
        ...p,
        displayName: cleanName,
        site: editSite,
        classe: editClasse.trim().slice(0, 32),
        elo: Math.max(0, Math.min(10000, Math.floor(Number(editElo) || 1000))),
        coins: Math.max(0, Math.floor(Number(editCoins) || 0)),
        packs: Math.max(0, Math.min(999, Math.floor(Number(editPacks) || 0))),
        wins: Math.max(0, Math.floor(Number(editWins) || 0)),
        losses: Math.max(0, Math.floor(Number(editLosses) || 0)),
      }),
      `Compte de ${cleanName} enregistré !`
    );
  };

  const handleToggleAdmin = async (player: PlayerProfile) => {
    const isCurrentlyPromoted = adminUidSet.has(player.uid);
    try {
      if (isCurrentlyPromoted) {
        await deleteDoc(doc(db, 'admins', player.uid));
        onToast(`${player.displayName} retiré des admins.`);
      } else {
        await setDoc(doc(db, 'admins', player.uid), {
          uid: player.uid,
          displayName: player.displayName.slice(0, 32),
          site: player.site,
          grantedByUid: profile.uid,
          grantedByName: profile.displayName.slice(0, 32),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        onToast(`${player.displayName} est maintenant Admin !`);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `admins/${player.uid}`);
    }
  };

  const handleDeleteTargetAccount = async () => {
    if (targetPlayer.uid === profile.uid) {
      onToast('Vous ne pouvez pas supprimer votre propre compte connecté.');
      return;
    }
    try {
      await deleteDoc(doc(db, 'players', targetPlayer.uid));
      if (adminUidSet.has(targetPlayer.uid)) {
        await deleteDoc(doc(db, 'admins', targetPlayer.uid));
      }
      setConfirmDeleteOpen(false);
      setSelectedUid(profile.uid);
      onToast(`Compte ${targetPlayer.displayName} supprimé.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `players/${targetPlayer.uid}`);
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 text-xs font-bold mb-2">
            <ShieldCheck className="w-4 h-4" />
            Accès Administrateur Sécurisé
          </div>
          <h1 className="font-display text-3xl font-bold text-[var(--txt)]">
            Panneau d’Administration
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1">
            Gérez les comptes joueurs, attribuez gratuitement des pièces ou des cartes et nommez de nouveaux administrateurs.
          </p>
        </div>
      </div>

      {/* Super-Admins & Promoted Admins Registry */}
      <section className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4">
        <h2 className="font-display text-lg font-bold text-[var(--txt)] flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-emerald-500" />
          Administrateurs autorisés
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] space-y-2">
            <div className="text-xs font-bold text-[var(--txt)]">
              Super-Admins principaux (vérifiés par email Google)
            </div>
            <ul className="space-y-1 text-xs font-mono-num text-[var(--mut)]">
              {SUPER_ADMIN_EMAILS.map((email) => (
                <li key={email} className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-semibold">
                  <span>✓</span>
                  <span>{email}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-4 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] space-y-2">
            <div className="text-xs font-bold text-[var(--txt)]">
              Admins promus ({adminDocs.length})
            </div>
            {adminDocs.length === 0 ? (
              <p className="text-xs text-[var(--mut)]">
                Aucun autre joueur promu pour le moment. Sélectionnez un joueur ci-dessous pour le nommer admin.
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {adminDocs.map((ad) => (
                  <span
                    key={ad.uid}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 text-xs font-bold"
                  >
                    {ad.displayName} ({ad.site})
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Player Selector */}
        <aside className="lg:col-span-4 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-[var(--txt)] flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-500" />
              Joueurs ({allPlayers.length})
            </h2>
            <button
              type="button"
              onClick={() => setSelectedUid(profile.uid)}
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              Moi ({profile.displayName})
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-[var(--mut)] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un joueur…"
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-xs text-[var(--txt)]"
            />
          </div>

          <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
            {filteredPlayers.map((p) => {
              const isSelected = p.uid === targetPlayer.uid;
              const isMe = p.uid === profile.uid;
              const isPromoted = adminUidSet.has(p.uid);
              return (
                <button
                  key={p.uid}
                  type="button"
                  onClick={() => setSelectedUid(p.uid)}
                  className={`w-full p-3 rounded-xl border text-left transition-colors flex items-center justify-between gap-2 ${
                    isSelected
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500'
                      : 'bg-[var(--surface-2)]/60 border-[var(--line)] hover:border-emerald-400'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-[var(--txt)] truncate flex items-center gap-1.5">
                      <span>{p.displayName}</span>
                      {isMe && (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-600 text-white text-[9px]">
                          MOI
                        </span>
                      )}
                      {isPromoted && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-500 text-white text-[9px]">
                          ADMIN
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-[var(--mut)] truncate">
                      {p.site} · {p.classe || 'Sans classe'}
                    </div>
                  </div>
                  <div className="text-right shrink-0 font-mono-num">
                    <div className="text-xs font-extrabold text-[var(--acc)]">
                      {p.coins.toLocaleString('fr-FR')} ●
                    </div>
                    <div className="text-[10px] text-[var(--mut)]">{p.elo} ELO</div>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Right Column: Management Controls for Target Player */}
        <div className="lg:col-span-8 space-y-6">
          {/* Selected Account Header & Admin Toggle */}
          <section className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-[var(--mut)]">Compte sélectionné</div>
              <h2 className="font-display text-2xl font-bold text-[var(--txt)]">
                {targetPlayer.displayName}
              </h2>
              <p className="text-xs text-[var(--mut)] font-mono-num mt-0.5">
                {targetPlayer.site} · {targetPlayer.classe || 'Sans classe'} · {targetPlayer.coins.toLocaleString('fr-FR')} ● · {targetPlayer.packs} paquets
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleToggleAdmin(targetPlayer)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-colors ${
                  adminUidSet.has(targetPlayer.uid)
                    ? 'bg-amber-500/15 border-amber-500/40 text-amber-700 dark:text-amber-300'
                    : 'bg-emerald-600 border-emerald-600 text-white hover:bg-emerald-500'
                }`}
              >
                {adminUidSet.has(targetPlayer.uid) ? (
                  <>
                    <UserMinus className="w-4 h-4" />
                    Retirer rôle Admin
                  </>
                ) : (
                  <>
                    <UserCheck className="w-4 h-4" />
                    Mettre Admin
                  </>
                )}
              </button>

              {targetPlayer.uid !== profile.uid && (
                <button
                  type="button"
                  onClick={() => setConfirmDeleteOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300"
                >
                  <Trash2 className="w-4 h-4" />
                  Supprimer compte
                </button>
              )}
            </div>
          </section>

          {/* Coins & Packs Grants */}
          <section className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4">
            <h3 className="font-display text-lg font-bold text-[var(--txt)] flex items-center gap-2">
              <Coins className="w-5 h-5 text-emerald-500" />
              Donner de l’argent & des paquets (gratuit)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] space-y-3">
                <div className="text-xs font-bold text-[var(--txt)]">
                  Pièces (Actuel : {targetPlayer.coins.toLocaleString('fr-FR')} ●)
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[100, 1000, 10000, -100].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => handleAddCoins(amt)}
                      className="px-3 py-1.5 rounded-lg bg-[var(--surface)] border border-[var(--line)] hover:border-emerald-500 text-xs font-bold font-mono-num text-[var(--txt)]"
                    >
                      {amt > 0 ? `+${amt}` : amt} ●
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min={0}
                    value={customCoins}
                    onChange={(e) => setCustomCoins(e.target.value)}
                    placeholder="Montant exact"
                    className="flex-1 px-3 py-2 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-xs font-mono-num text-[var(--txt)]"
                  />
                  <button
                    type="button"
                    onClick={handleSetCoinsExact}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold whitespace-nowrap"
                  >
                    Définir solde
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] space-y-3">
                <div className="text-xs font-bold text-[var(--txt)] flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-emerald-500" />
                  Paquets (Actuel : {targetPlayer.packs})
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {[1, 5, 10, 50].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => handleAddPacks(amt)}
                      className="px-3 py-1.5 rounded-lg bg-[var(--surface)] border border-[var(--line)] hover:border-emerald-500 text-xs font-bold font-mono-num text-[var(--txt)]"
                    >
                      +{amt} paquets
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min={0}
                    max={999}
                    value={customPacks}
                    onChange={(e) => setCustomPacks(e.target.value)}
                    placeholder="Nb paquets"
                    className="flex-1 px-3 py-2 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-xs font-mono-num text-[var(--txt)]"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddPacks(Math.max(0, Math.floor(Number(customPacks) || 0)))}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold whitespace-nowrap"
                  >
                    + Ajouter paquets
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* Grant Free Cards */}
          <section className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-display text-lg font-bold text-[var(--txt)] flex items-center gap-2">
                <Layers className="w-5 h-5 text-emerald-500" />
                Donner des cartes gratuitement à {targetPlayer.displayName}
              </h3>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleGiveAllCards}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                >
                  Débloquer toutes les cartes (×1)
                </button>
                <button
                  type="button"
                  onClick={handleResetInventory}
                  className="px-3.5 py-2 rounded-xl border border-rose-300 text-rose-700 dark:text-rose-300 text-xs font-bold"
                >
                  Vider inventaire
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {CARDS.map((c) => {
                const qty = targetPlayer.inv?.[String(c.id)] || 0;
                return (
                  <div
                    key={c.id}
                    className="p-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] flex flex-col gap-2"
                  >
                    <CardVisual card={c} compact count={qty} hideIcon />
                    <div className="text-[11px] font-mono-num text-center text-[var(--mut)]">
                      Possédé : <strong style={{ color: RARITY_META[c.r].color }}>{qty}</strong>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <button
                        type="button"
                        onClick={() => handleGiveCard(c.id, -1)}
                        disabled={qty <= 0}
                        className="py-1 rounded-lg bg-[var(--surface)] border border-[var(--line)] text-xs font-bold text-rose-600 disabled:opacity-35"
                      >
                        -1
                      </button>
                      <button
                        type="button"
                        onClick={() => handleGiveCard(c.id, 1)}
                        className="py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold"
                      >
                        +1
                      </button>
                      <button
                        type="button"
                        onClick={() => handleGiveCard(c.id, 5)}
                        className="py-1 rounded-lg bg-[var(--surface)] border border-[var(--line)] text-xs font-bold text-emerald-600 dark:text-emerald-400"
                      >
                        +5
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Full Account Editor */}
          <form
            onSubmit={handleSaveAccount}
            className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4"
          >
            <h3 className="font-display text-lg font-bold text-[var(--txt)]">
              Modifier les informations du compte ({targetPlayer.displayName})
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Pseudo</label>
                <input
                  type="text"
                  maxLength={32}
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Site</label>
                <select
                  value={editSite}
                  onChange={(e) => setEditSite(e.target.value === 'Marceau' ? 'Marceau' : 'Labbé')}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)]"
                >
                  <option value="Labbé">Site Labbé (Général & Techno)</option>
                  <option value="Marceau">Site Marceau (Lycée Pro)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Classe / Filière</label>
                <button
                  type="button"
                  onClick={() => setClassPickerOpen(true)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-left flex items-center justify-between text-[var(--txt)]"
                >
                  <span>{editClasse || 'Choisir une filière…'}</span>
                  <ChevronDown className="w-4 h-4 text-[var(--mut)]" />
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">ELO</label>
                <input
                  type="number"
                  min={0}
                  max={10000}
                  value={editElo}
                  onChange={(e) => setEditElo(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm font-mono-num text-[var(--txt)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Pièces (●)</label>
                <input
                  type="number"
                  min={0}
                  value={editCoins}
                  onChange={(e) => setEditCoins(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm font-mono-num text-[var(--txt)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Paquets</label>
                <input
                  type="number"
                  min={0}
                  max={999}
                  value={editPacks}
                  onChange={(e) => setEditPacks(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm font-mono-num text-[var(--txt)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Victoires</label>
                <input
                  type="number"
                  min={0}
                  value={editWins}
                  onChange={(e) => setEditWins(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm font-mono-num text-[var(--txt)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Défaites</label>
                <input
                  type="number"
                  min={0}
                  value={editLosses}
                  onChange={(e) => setEditLosses(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm font-mono-num text-[var(--txt)]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold"
            >
              Enregistrer les modifications du compte
            </button>
          </form>
        </div>
      </div>

      <ClassPickerModal
        isOpen={classPickerOpen}
        initialSiteFilter={editSite}
        selectedClass={editClasse}
        onSelect={(cls, suggestedSite) => {
          setEditClasse(cls);
          if (suggestedSite) setEditSite(suggestedSite);
          setClassPickerOpen(false);
        }}
        onClose={() => setClassPickerOpen(false)}
      />

      {confirmDeleteOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setConfirmDeleteOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-lg font-bold text-[var(--txt)]">
              Supprimer ce compte joueur ?
            </h3>
            <p className="text-xs text-[var(--mut)] leading-relaxed">
              Vous êtes sur le point de supprimer définitivement la fiche joueur de{' '}
              <strong className="text-[var(--txt)]">{targetPlayer.displayName}</strong>.
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteOpen(false)}
                className="px-4 py-2 rounded-xl bg-[var(--surface-2)] text-xs font-bold text-[var(--txt)]"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleDeleteTargetAccount}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold"
              >
                Confirmer la suppression
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
