import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import { ArrowLeftRight, Plus, ShoppingBag, Tag } from 'lucide-react';
import {
  CARDS,
  MAX_MARKET_SLOTS,
  RARITY_ORDER,
  getCardById,
  playSfx,
} from '../data/gameData';
import { db, handleFirestoreError, sanitizePlayerUpdate } from '../firebase/client';
import {
  OperationType,
  type MarketListing,
  type PlayerProfile,
  type Rarity,
  type TradeOffer,
} from '../types/game';
import { CardVisual } from './CardVisual';

interface CommerceViewProps {
  profile: PlayerProfile;
  allPlayers: PlayerProfile[];
  onToast: (msg: string) => void;
}

export const CommerceView: React.FC<CommerceViewProps> = ({
  profile,
  allPlayers,
  onToast,
}) => {
  const [section, setSection] = useState<'market' | 'trades'>('market');
  const [marketTab, setMarketTab] = useState<'browse' | 'mine'>('browse');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'ALL'>('ALL');
  const [listings, setListings] = useState<MarketListing[]>([]);
  const [myListings, setMyListings] = useState<MarketListing[]>([]);
  const [sellOpen, setSellOpen] = useState(false);
  const [sellCardId, setSellCardId] = useState<number | null>(null);
  const [sellPrice, setSellPrice] = useState('');
  const [sellDurationMin, setSellDurationMin] = useState(120);

  // Trades state
  const [tradeTab, setTradeTab] = useState<'received' | 'sent' | 'new'>('received');
  const [receivedTrades, setReceivedTrades] = useState<TradeOffer[]>([]);
  const [sentTrades, setSentTrades] = useState<TradeOffer[]>([]);
  const [playerQuery, setPlayerQuery] = useState('');
  const [targetPlayer, setTargetPlayer] = useState<PlayerProfile | null>(null);
  const [giveCards, setGiveCards] = useState<number[]>([]);
  const [getCards, setGetCards] = useState<number[]>([]);

  const claimedListingsRef = useRef<Set<string>>(new Set());
  const claimedTradesRef = useRef<Set<string>>(new Set());

  // Subscribe to active listings & own listings
  useEffect(() => {
    const qActive = query(collection(db, 'listings'), where('status', '==', 'active'));
    const unsubActive = onSnapshot(
      qActive,
      (snap) => {
        const items = snap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<MarketListing, 'id'>) }))
          .filter((l) => l.endsAt > Date.now());
        items.sort((a, b) => a.endsAt - b.endsAt);
        setListings(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'listings')
    );

    const qMine = query(collection(db, 'listings'), where('sellerId', '==', profile.uid));
    const unsubMine = onSnapshot(
      qMine,
      (snap) => {
        const items = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<MarketListing, 'id'>),
        }));
        setMyListings(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'listings')
    );

    return () => {
      unsubActive();
      unsubMine();
    };
  }, [profile.uid]);

  // Auto-claim sold listings proceeds into seller's coins
  useEffect(() => {
    const unclaimed = myListings.filter(
      (l) => l.status === 'sold' && !l.sellerClaimed && !claimedListingsRef.current.has(l.id)
    );
    unclaimed.forEach(async (l) => {
      claimedListingsRef.current.add(l.id);
      try {
        await runTransaction(db, async (tx) => {
          const lRef = doc(db, 'listings', l.id);
          const pRef = doc(db, 'players', profile.uid);
          const lSnap = await tx.get(lRef);
          const pSnap = await tx.get(pRef);
          if (!lSnap.exists() || !pSnap.exists()) return;
          const ld = lSnap.data() as MarketListing;
          const pd = pSnap.data() as PlayerProfile;
          if (ld.status !== 'sold' || ld.sellerClaimed) return;
          tx.update(pRef, sanitizePlayerUpdate({
            ...pd,
            coins: pd.coins + ld.price,
            marketSales: (pd.marketSales || 0) + 1,
          }));
          tx.update(lRef, { sellerClaimed: true, updatedAt: serverTimestamp() });
        });
        playSfx('coin');
        onToast(`Vente encaissée : +${l.price} ● (${getCardById(l.cardId)?.name})`);
      } catch (err) {
        console.error(err);
      }
    });
  }, [myListings, profile.uid, onToast]);

  // Subscribe to trades
  useEffect(() => {
    const qRec = query(collection(db, 'trades'), where('toId', '==', profile.uid));
    const qSent = query(collection(db, 'trades'), where('fromId', '==', profile.uid));

    const unsubRec = onSnapshot(
      qRec,
      (snap) => {
        setReceivedTrades(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<TradeOffer, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'trades')
    );

    const unsubSent = onSnapshot(
      qSent,
      (snap) => {
        setSentTrades(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<TradeOffer, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'trades')
    );

    return () => {
      unsubRec();
      unsubSent();
    };
  }, [profile.uid]);

  // Auto-claim resolved sent trades (accepted -> receive getCards; declined/cancelled -> refund giveCards)
  useEffect(() => {
    const unclaimed = sentTrades.filter(
      (t) =>
        ['accepted', 'declined', 'cancelled'].includes(t.status) &&
        !t.fromClaimed &&
        !claimedTradesRef.current.has(t.id)
    );

    unclaimed.forEach(async (t) => {
      claimedTradesRef.current.add(t.id);
      try {
        await runTransaction(db, async (tx) => {
          const tRef = doc(db, 'trades', t.id);
          const pRef = doc(db, 'players', profile.uid);
          const tSnap = await tx.get(tRef);
          const pSnap = await tx.get(pRef);
          if (!tSnap.exists() || !pSnap.exists()) return;
          const td = tSnap.data() as TradeOffer;
          const pd = pSnap.data() as PlayerProfile;
          if (td.fromClaimed) return;

          const nextInv = { ...(pd.inv || {}) };
          const cardsToAdd = td.status === 'accepted' ? td.get : td.give;
          cardsToAdd.forEach((cid) => {
            const k = String(cid);
            nextInv[k] = (nextInv[k] || 0) + 1;
          });

          tx.update(
            pRef,
            sanitizePlayerUpdate({
              ...pd,
              inv: nextInv,
              tradesCompleted:
                (pd.tradesCompleted || 0) + (td.status === 'accepted' ? 1 : 0),
            })
          );
          tx.update(tRef, { fromClaimed: true, updatedAt: serverTimestamp() });
        });
        if (t.status === 'accepted') {
          playSfx('win');
          onToast(`Échange avec ${t.toName} finalisé ! Cartes ajoutées.`);
        }
      } catch (err) {
        console.error(err);
      }
    });
  }, [sentTrades, profile.uid, onToast]);

  const activeMyListings = myListings.filter(
    (l) => l.status === 'active' && l.endsAt > Date.now()
  );
  const pendingReceivedCount = receivedTrades.filter((t) => t.status === 'pending').length;

  const browseListings = useMemo(() => {
    return listings.filter((l) => {
      if (l.sellerId === profile.uid) return false;
      if (rarityFilter !== 'ALL') {
        const c = getCardById(l.cardId);
        if (!c || c.r !== rarityFilter) return false;
      }
      return true;
    });
  }, [listings, profile.uid, rarityFilter]);

  const handleBuyListing = async (l: MarketListing) => {
    if (profile.coins < l.price) {
      onToast('Pièces ● insuffisantes.');
      return;
    }
    try {
      await runTransaction(db, async (tx) => {
        const lRef = doc(db, 'listings', l.id);
        const pRef = doc(db, 'players', profile.uid);
        const lSnap = await tx.get(lRef);
        const pSnap = await tx.get(pRef);
        if (!lSnap.exists() || !pSnap.exists()) throw new Error('Vente introuvable');
        const ld = lSnap.data() as MarketListing;
        const pd = pSnap.data() as PlayerProfile;
        if (ld.status !== 'active') throw new Error('Déjà vendue ou annulée');
        if (ld.endsAt <= Date.now()) throw new Error('Offre expirée');
        if (pd.coins < ld.price) throw new Error('Pièces insuffisantes');

        const nextInv = { ...(pd.inv || {}) };
        nextInv[String(ld.cardId)] = (nextInv[String(ld.cardId)] || 0) + 1;

        tx.update(
          pRef,
          sanitizePlayerUpdate({
            ...pd,
            coins: pd.coins - ld.price,
            inv: nextInv,
          })
        );
        tx.update(lRef, {
          status: 'sold',
          buyerId: profile.uid,
          buyerName: profile.displayName,
          updatedAt: serverTimestamp(),
        });
      });
      playSfx('coin');
      onToast(`Achat réussi : ${getCardById(l.cardId)?.name} !`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Achat impossible');
    }
  };

  const handleCreateListing = async () => {
    const price = Math.floor(Number(sellPrice));
    if (!sellCardId) {
      onToast('Sélectionnez une carte à vendre.');
      return;
    }
    if (!(price >= 1)) {
      onToast('Entrez un prix valide (minimum 1 ●).');
      return;
    }
    if (activeMyListings.length >= MAX_MARKET_SLOTS) {
      onToast(`Maximum ${MAX_MARKET_SLOTS} ventes actives simultanées.`);
      return;
    }
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists()) throw new Error('Profil introuvable');
        const pd = pSnap.data() as PlayerProfile;
        const k = String(sellCardId);
        if ((pd.inv[k] || 0) < 1) throw new Error('Carte non disponible');
        const nextInv = { ...pd.inv, [k]: pd.inv[k] - 1 };

        const lRef = doc(collection(db, 'listings'));
        tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
        tx.set(lRef, {
          sellerId: profile.uid,
          sellerName: profile.displayName,
          sellerSite: profile.site,
          cardId: sellCardId,
          price,
          endsAt: Date.now() + sellDurationMin * 60 * 1000,
          status: 'active',
          buyerId: '',
          buyerName: '',
          sellerClaimed: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      setSellOpen(false);
      setSellCardId(null);
      setSellPrice('');
      playSfx('pack');
      onToast('Carte mise en vente sur le Marché !');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Erreur lors de la mise en vente');
    }
  };

  const handleCancelListing = async (l: MarketListing) => {
    try {
      await runTransaction(db, async (tx) => {
        const lRef = doc(db, 'listings', l.id);
        const pRef = doc(db, 'players', profile.uid);
        const lSnap = await tx.get(lRef);
        const pSnap = await tx.get(pRef);
        if (!lSnap.exists() || !pSnap.exists()) return;
        const ld = lSnap.data() as MarketListing;
        const pd = pSnap.data() as PlayerProfile;
        if (ld.status !== 'active') return;
        const k = String(ld.cardId);
        const nextInv = { ...pd.inv, [k]: (pd.inv[k] || 0) + 1 };
        tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
        tx.update(lRef, { status: 'cancelled', updatedAt: serverTimestamp() });
      });
      onToast('Annonce retirée et carte restituée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `listings/${l.id}`);
    }
  };

  // --- Trade Actions ---
  const handleSendTrade = async () => {
    if (!targetPlayer) {
      onToast('Sélectionnez un destinataire.');
      return;
    }
    if (giveCards.length === 0 || getCards.length === 0) {
      onToast('Choisissez au moins une carte à donner et une à recevoir.');
      return;
    }
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists()) throw new Error('Profil introuvable');
        const pd = pSnap.data() as PlayerProfile;
        const nextInv = { ...(pd.inv || {}) };
        for (const cid of giveCards) {
          const k = String(cid);
          if ((nextInv[k] || 0) < 1) {
            throw new Error(`Carte indisponible : ${getCardById(cid)?.name}`);
          }
          nextInv[k]--;
        }
        const tRef = doc(collection(db, 'trades'));
        tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
        tx.set(tRef, {
          fromId: profile.uid,
          fromName: profile.displayName,
          fromSite: profile.site,
          toId: targetPlayer.uid,
          toName: targetPlayer.displayName,
          toSite: targetPlayer.site,
          give: giveCards,
          get: getCards,
          status: 'pending',
          fromClaimed: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      setGiveCards([]);
      setGetCards([]);
      setTargetPlayer(null);
      setTradeTab('sent');
      playSfx('pack');
      onToast(`Offre envoyée à ${targetPlayer.displayName} !`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Erreur d’envoi');
    }
  };

  const handleRespondTrade = async (t: TradeOffer, accept: boolean) => {
    try {
      if (accept) {
        await runTransaction(db, async (tx) => {
          const tRef = doc(db, 'trades', t.id);
          const pRef = doc(db, 'players', profile.uid);
          const tSnap = await tx.get(tRef);
          const pSnap = await tx.get(pRef);
          if (!tSnap.exists() || !pSnap.exists()) throw new Error('Offre introuvable');
          const td = tSnap.data() as TradeOffer;
          const pd = pSnap.data() as PlayerProfile;
          if (td.status !== 'pending') throw new Error('Offre déjà traitée');

          const nextInv = { ...(pd.inv || {}) };
          for (const cid of td.get) {
            const k = String(cid);
            if ((nextInv[k] || 0) < 1) {
              throw new Error(`Vous n’avez plus ${getCardById(cid)?.name}`);
            }
            nextInv[k]--;
          }
          for (const cid of td.give) {
            const k = String(cid);
            nextInv[k] = (nextInv[k] || 0) + 1;
          }

          tx.update(
            pRef,
            sanitizePlayerUpdate({
              ...pd,
              inv: nextInv,
              tradesCompleted: (pd.tradesCompleted || 0) + 1,
            })
          );
          tx.update(tRef, { status: 'accepted', updatedAt: serverTimestamp() });
        });
        playSfx('win');
        onToast('Échange accepté ! Cartes ajoutées à votre collection.');
      } else {
        await updateDoc(doc(db, 'trades', t.id), {
          status: 'declined',
          updatedAt: serverTimestamp(),
        });
        onToast('Offre refusée.');
      }
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Erreur lors de la réponse');
    }
  };

  const handleCancelTrade = async (t: TradeOffer) => {
    try {
      await updateDoc(doc(db, 'trades', t.id), {
        status: 'cancelled',
        updatedAt: serverTimestamp(),
      });
      onToast('Offre annulée, vos cartes reviennent dans votre collection.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trades/${t.id}`);
    }
  };

  const ownedSellable = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);
  const otherPlayers = useMemo(() => {
    const q = playerQuery.trim().toLowerCase();
    return allPlayers
      .filter((p) => p.uid !== profile.uid)
      .filter((p) => !q || `${p.displayName} ${p.site}`.toLowerCase().includes(q))
      .slice(0, 12);
  }, [allPlayers, profile.uid, playerQuery]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
            Commerce Inter-Sites
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1">
            Achetez et vendez au Marché avec vos pièces ● ou négociez des échanges directs
          </p>
        </div>

        <div className="flex items-center p-1 rounded-xl bg-[var(--surface)] border border-[var(--line)] self-start">
          <button
            type="button"
            onClick={() => setSection('market')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
              section === 'market'
                ? 'bg-[#e2bb6b] text-[#1d1405]'
                : 'text-[var(--mut)] hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            Marché ({browseListings.length})
          </button>
          <button
            type="button"
            onClick={() => setSection('trades')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
              section === 'trades'
                ? 'bg-[#e2bb6b] text-[#1d1405]'
                : 'text-[var(--mut)] hover:text-white'
            }`}
          >
            <ArrowLeftRight className="w-4 h-4" />
            Échanges {pendingReceivedCount > 0 ? `(${pendingReceivedCount})` : ''}
          </button>
        </div>
      </div>

      {/* MARKET SECTION */}
      {section === 'market' && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setMarketTab('browse')}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
                  marketTab === 'browse'
                    ? 'bg-white/10 border-white/25 text-white'
                    : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
                }`}
              >
                En vente ({browseListings.length})
              </button>
              <button
                type="button"
                onClick={() => setMarketTab('mine')}
                className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
                  marketTab === 'mine'
                    ? 'bg-white/10 border-white/25 text-white'
                    : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
                }`}
              >
                Mes ventes ({activeMyListings.length} / {MAX_MARKET_SLOTS})
              </button>
            </div>

            <button
              type="button"
              disabled={activeMyListings.length >= MAX_MARKET_SLOTS}
              onClick={() => setSellOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] disabled:opacity-40 whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              Mettre une carte en vente
            </button>
          </div>

          {marketTab === 'browse' && (
            <>
              <div className="flex flex-wrap gap-1.5">
                {(['ALL', ...RARITY_ORDER] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRarityFilter(r)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold border ${
                      rarityFilter === r
                        ? 'bg-white/10 border-white/30 text-white'
                        : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
                    }`}
                  >
                    {r === 'ALL' ? 'Toutes' : r}
                  </button>
                ))}
              </div>

              {browseListings.length === 0 ? (
                <div className="p-10 rounded-2xl border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
                  Aucune carte en vente pour le moment. Revenez bientôt ou mettez vos doublons en vente !
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {browseListings.map((l) => {
                    const c = getCardById(l.cardId);
                    if (!c) return null;
                    const leftMin = Math.max(1, Math.ceil((l.endsAt - Date.now()) / 60000));
                    return (
                      <div
                        key={l.id}
                        className="p-3.5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center gap-4"
                      >
                        <div className="w-20 shrink-0">
                          <CardVisual card={c} compact />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-white text-sm truncate">{c.name}</div>
                          <div className="font-mono-num text-base font-extrabold text-[#e2bb6b] mt-0.5">
                            {l.price.toLocaleString('fr-FR')} ●
                          </div>
                          <div className="text-xs text-[var(--mut)] mt-1 truncate">
                            {l.sellerName} · {l.sellerSite} · {leftMin} min
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleBuyListing(l)}
                          disabled={profile.coins < l.price}
                          className="px-4 py-2 rounded-xl bg-[#e2bb6b] text-[#1d1405] text-xs font-bold disabled:opacity-40 shrink-0"
                        >
                          Acheter
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {marketTab === 'mine' && (
            <div className="space-y-3">
              {activeMyListings.length === 0 ? (
                <div className="p-10 rounded-2xl border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
                  Vous n’avez aucune annonce active.
                </div>
              ) : (
                activeMyListings.map((l) => {
                  const c = getCardById(l.cardId);
                  if (!c) return null;
                  return (
                    <div
                      key={l.id}
                      className="p-3.5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-16 shrink-0">
                          <CardVisual card={c} compact />
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold text-white text-sm truncate">{c.name}</div>
                          <div className="font-mono-num text-sm font-bold text-[#e2bb6b]">
                            {l.price.toLocaleString('fr-FR')} ●
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCancelListing(l)}
                        className="px-3.5 py-2 rounded-xl border border-rose-500/35 text-rose-400 text-xs font-bold"
                      >
                        Retirer
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      )}

      {/* TRADES SECTION */}
      {section === 'trades' && (
        <div className="space-y-5">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setTradeTab('received')}
              className={`px-4 py-2 rounded-xl text-xs font-bold border ${
                tradeTab === 'received'
                  ? 'bg-white/10 border-white/25 text-white'
                  : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
              }`}
            >
              Reçues ({pendingReceivedCount})
            </button>
            <button
              type="button"
              onClick={() => setTradeTab('sent')}
              className={`px-4 py-2 rounded-xl text-xs font-bold border ${
                tradeTab === 'sent'
                  ? 'bg-white/10 border-white/25 text-white'
                  : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
              }`}
            >
              Envoyées ({sentTrades.length})
            </button>
            <button
              type="button"
              onClick={() => setTradeTab('new')}
              className={`px-4 py-2 rounded-xl text-xs font-bold border ${
                tradeTab === 'new'
                  ? 'bg-[#e2bb6b] border-[#e2bb6b] text-[#1d1405]'
                  : 'bg-[var(--surface)] border-[var(--line)] text-white'
              }`}
            >
              + Nouvelle offre
            </button>
          </div>

          {tradeTab === 'received' && (
            <div className="space-y-3">
              {receivedTrades.length === 0 ? (
                <div className="p-10 rounded-2xl border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
                  Aucune offre d’échange reçue.
                </div>
              ) : (
                receivedTrades.map((t) => (
                  <div
                    key={t.id}
                    className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-3"
                  >
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-bold text-white">
                        De {t.fromName} · <span className="text-[var(--mut)] font-normal">{t.fromSite}</span>
                      </span>
                      <span className="text-xs font-semibold text-[var(--mut)]">
                        {t.status === 'pending'
                          ? 'En attente'
                          : t.status === 'accepted'
                          ? 'Acceptée'
                          : t.status === 'declined'
                          ? 'Refusée'
                          : 'Annulée'}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div>
                        <div className="text-[var(--mut)] mb-1.5">Vous recevez</div>
                        <div className="flex flex-wrap gap-2">
                          {t.give.map((cid, i) => {
                            const c = getCardById(cid);
                            return c ? (
                              <span key={`${cid}-${i}`} className="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-300 font-semibold">
                                {c.icon} {c.name} ({c.r})
                              </span>
                            ) : null;
                          })}
                        </div>
                      </div>
                      <div>
                        <div className="text-[var(--mut)] mb-1.5">Vous donnez</div>
                        <div className="flex flex-wrap gap-2">
                          {t.get.map((cid, i) => {
                            const c = getCardById(cid);
                            return c ? (
                              <span key={`${cid}-${i}`} className="px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-300 font-semibold">
                                {c.icon} {c.name} ({c.r})
                              </span>
                            ) : null;
                          })}
                        </div>
                      </div>
                    </div>

                    {t.status === 'pending' && (
                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => handleRespondTrade(t, false)}
                          className="px-4 py-2 rounded-xl border border-rose-500/35 text-rose-400 text-xs font-bold"
                        >
                          Refuser
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRespondTrade(t, true)}
                          className="px-4 py-2 rounded-xl bg-[#e2bb6b] text-[#1d1405] text-xs font-bold"
                        >
                          Accepter l’échange
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          )}

          {tradeTab === 'sent' && (
            <div className="space-y-3">
              {sentTrades.length === 0 ? (
                <div className="p-10 rounded-2xl border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
                  Aucune offre envoyée.
                </div>
              ) : (
                sentTrades.map((t) => (
                  <div
                    key={t.id}
                    className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="text-sm font-bold text-white">
                        À {t.toName} · <span className="text-[var(--mut)] font-normal">{t.toSite}</span>
                      </div>
                      <div className="text-xs text-[var(--mut)]">
                        Vous offrez {t.give.map((id) => getCardById(id)?.name).join(', ')} contre{' '}
                        {t.get.map((id) => getCardById(id)?.name).join(', ')}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-[var(--mut)]">
                        {t.status === 'pending'
                          ? 'En attente'
                          : t.status === 'accepted'
                          ? 'Acceptée'
                          : t.status === 'declined'
                          ? 'Refusée'
                          : 'Annulée'}
                      </span>
                      {t.status === 'pending' && (
                        <button
                          type="button"
                          onClick={() => handleCancelTrade(t)}
                          className="px-3 py-1.5 rounded-lg border border-rose-500/35 text-rose-400 text-xs font-bold"
                        >
                          Annuler
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {tradeTab === 'new' && (
            <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-5">
              <div>
                <label className="block text-xs font-bold text-[var(--mut)] mb-2">
                  1. Rechercher un élève (Labbé ou Marceau)
                </label>
                <input
                  type="search"
                  value={playerQuery}
                  onChange={(e) => setPlayerQuery(e.target.value)}
                  placeholder="Pseudo du joueur…"
                  className="w-full px-4 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2.5 max-h-40 overflow-y-auto">
                  {otherPlayers.map((p) => (
                    <button
                      key={p.uid}
                      type="button"
                      onClick={() => {
                        setTargetPlayer(p);
                        setGetCards([]);
                      }}
                      className={`p-2.5 rounded-xl border text-left text-xs transition-colors flex justify-between items-center ${
                        targetPlayer?.uid === p.uid
                          ? 'bg-[#e2bb6b]/15 border-[#e2bb6b] text-white'
                          : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)] hover:text-white'
                      }`}
                    >
                      <span className="font-bold text-white">{p.displayName}</span>
                      <span>{p.site} · {p.elo} ELO</span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-[var(--mut)] mb-2">
                  2. Cartes que vous proposez ({giveCards.length})
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                  {ownedSellable.map((c) => (
                    <CardVisual
                      key={c.id}
                      card={c}
                      compact
                      count={profile.inv[String(c.id)]}
                      selected={giveCards.includes(c.id)}
                      onClick={() =>
                        setGiveCards((prev) =>
                          prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id]
                        )
                      }
                    />
                  ))}
                </div>
              </div>

              {targetPlayer && (
                <div>
                  <div className="text-xs font-bold text-[var(--mut)] mb-2">
                    3. Cartes souhaitées chez {targetPlayer.displayName} ({getCards.length})
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                    {CARDS.filter((c) => (targetPlayer.inv?.[String(c.id)] || 0) > 0).map((c) => (
                      <CardVisual
                        key={c.id}
                        card={c}
                        compact
                        count={targetPlayer.inv[String(c.id)]}
                        selected={getCards.includes(c.id)}
                        onClick={() =>
                          setGetCards((prev) =>
                            prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id]
                          )
                        }
                      />
                    ))}
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={handleSendTrade}
                disabled={!targetPlayer || giveCards.length === 0 || getCards.length === 0}
                className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] disabled:opacity-40"
              >
                Envoyer l’offre d’échange
              </button>
            </div>
          )}
        </div>
      )}

      {/* Sell Sheet Modal */}
      {sellOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSellOpen(false)}
        >
          <div
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-[var(--surface)] border border-[var(--line)] p-5 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
                <Tag className="w-5 h-5 text-[#e2bb6b]" />
                Mettre une carte en vente
              </h2>
              <button
                type="button"
                onClick={() => setSellOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 text-white text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
              {ownedSellable.map((c) => (
                <CardVisual
                  key={c.id}
                  card={c}
                  compact
                  count={profile.inv[String(c.id)]}
                  selected={sellCardId === c.id}
                  onClick={() => {
                    setSellCardId(c.id);
                    setSellPrice(String(c.suggestedPrice));
                  }}
                />
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[var(--mut)] mb-1">Prix (●)</label>
                <input
                  type="number"
                  min={1}
                  value={sellPrice}
                  onChange={(e) => setSellPrice(e.target.value)}
                  placeholder="Ex. 120"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-xs text-[var(--mut)] mb-1">Durée</label>
                <select
                  value={sellDurationMin}
                  onChange={(e) => setSellDurationMin(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
                >
                  <option value={60}>1 heure</option>
                  <option value={360}>6 heures</option>
                  <option value={720}>12 heures</option>
                  <option value={1440}>24 heures</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleCreateListing}
              className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f]"
            >
              Confirmer la mise en vente
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
