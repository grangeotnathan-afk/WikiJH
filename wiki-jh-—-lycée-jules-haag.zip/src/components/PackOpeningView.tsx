import React, { useEffect, useMemo, useRef, useState } from 'react';
import { HelpCircle, Package, Timer, X } from 'lucide-react';
import {
  CARDS_PER_PACK,
  EXTRA_PACK_COST,
  MAX_PACKS,
  PACK_INTERVAL_MS,
  RARITY_META,
  drawBoosterPack,
  playSfx,
} from '../data/gameData';
import type { CardDef, PlayerProfile } from '../types/game';
import { CardVisual } from './CardVisual';

interface PackOpeningViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onToast: (msg: string) => void;
}

const TEETH = 22;
const AMP = 1.1;
const CUT_Y = 13;

function buildPackClips() {
  const zigTop: string[] = [];
  for (let i = 0; i < TEETH; i++) {
    zigTop.push(`${((i / TEETH) * 100).toFixed(2)}% 0%`);
    zigTop.push(`${(((i + 0.5) / TEETH) * 100).toFixed(2)}% ${AMP}%`);
  }
  zigTop.push('100% 0%');

  const zigBot: string[] = [];
  for (let i = TEETH; i > 0; i--) {
    zigBot.push(`${((i / TEETH) * 100).toFixed(2)}% 100%`);
    zigBot.push(`${(((i - 0.5) / TEETH) * 100).toFixed(2)}% ${100 - AMP}%`);
  }
  zigBot.push('0% 100%');

  const tear: [number, number][] = [];
  for (let i = 0; i <= 16; i++) {
    tear.push([(i / 16) * 100, CUT_Y + (((i * 37) % 7) - 3) * 0.32]);
  }
  const tearFwd = tear.map(([x, y]) => `${x.toFixed(2)}% ${y.toFixed(2)}%`);
  const poly = (pts: string[]) => `polygon(${pts.join(',')})`;

  return {
    all: poly([...zigTop, ...zigBot]),
    top: poly([...zigTop, ...[...tearFwd].reverse()]),
    main: poly([...tearFwd, ...zigBot]),
  };
}

const PackArt: React.FC<{ clipPath: string }> = ({ clipPath }) => (
  <div className="pk-art" style={{ clipPath }}>
    <div className="pk-crimp t" />
    <div className="pk-frame" />
    <div className="pk-photo p1" />
    <div className="pk-mid">
      <i>◆ ◆ ◆</i>
      <em>Wiki JH</em>
      <small>Booster · 5 cartes</small>
    </div>
    <div className="pk-photo p2" />
    <div className="pk-crimp b" />
    <div className="pk-shade" />
    <div className="pk-gloss" />
  </div>
);

export const PackOpeningView: React.FC<PackOpeningViewProps> = ({
  profile,
  onUpdateProfile,
  onToast,
}) => {
  const clips = useMemo(() => buildPackClips(), []);
  const packBtnRef = useRef<HTMLButtonElement | null>(null);
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);

  // Reveal Modal state
  const [revealPhase, setRevealPhase] = useState<'idle' | 'cut' | 'opening' | 'cards' | 'summary'>('idle');
  const [pulled, setPulled] = useState<CardDef[]>([]);
  const [cardIdx, setCardIdx] = useState(0);
  const [cutProg, setCutProg] = useState(0);
  const [cutDir, setCutDir] = useState(1);
  const [isDraggingCut, setIsDraggingCut] = useState(false);
  const [autoCut, setAutoCut] = useState(false);
  const dragRef = useRef<{ x: number; dir: number; moved: boolean; w: number } | null>(null);
  const pkRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const nextPackLeftMs =
    profile.packs >= MAX_PACKS
      ? 0
      : Math.max(0, PACK_INTERVAL_MS - (now - (profile.lastPackAt || now)));
  const nextM = Math.floor(nextPackLeftMs / 60000);
  const nextS = Math.floor((nextPackLeftMs % 60000) / 1000);

  const handleOpenPack = async () => {
    if (busy || revealPhase !== 'idle') return;
    if (profile.packs < 1) {
      onToast('Aucun paquet disponible pour le moment.');
      return;
    }
    setBusy(true);
    const list = drawBoosterPack(CARDS_PER_PACK);
    try {
      await onUpdateProfile((prev) => {
        const nextInv = { ...(prev.inv || {}) };
        list.forEach((c) => {
          const k = String(c.id);
          nextInv[k] = (nextInv[k] || 0) + 1;
        });
        return {
          ...prev,
          packs: Math.max(0, prev.packs - 1),
          lastPackAt: prev.packs >= MAX_PACKS ? Date.now() : prev.lastPackAt,
          opened: (prev.opened || 0) + 1,
          inv: nextInv,
        };
      });
      playSfx('pack');
      setPulled(list);
      setCardIdx(0);
      setCutProg(0);
      setCutDir(1);
      setIsDraggingCut(false);
      setAutoCut(false);
      setRevealPhase('cut');
    } catch {
      onToast('Impossible d’ouvrir le paquet.');
      setBusy(false);
    }
  };

  const handleBuyPack = async () => {
    if (profile.coins < EXTRA_PACK_COST) {
      onToast(`Il vous faut ${EXTRA_PACK_COST} ● pour acheter un booster.`);
      return;
    }
    await onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins - EXTRA_PACK_COST,
      packs: prev.packs + 1,
    }));
    playSfx('coin');
    onToast('+1 Booster ajouté à votre réserve !');
  };

  const triggerOpenAnim = () => {
    setRevealPhase('opening');
    if (navigator.vibrate) navigator.vibrate([20, 30, 40]);
    setTimeout(() => {
      setRevealPhase('cards');
      setCardIdx(0);
      const first = pulled[0];
      if (first?.r === 'EX') playSfx('exotic');
      else if (first && ['SR', 'UR', 'L'].includes(first.r)) playSfx('rare');
    }, 700);
  };

  const handleRevealAdvance = () => {
    if (revealPhase !== 'cards') return;
    if (cardIdx < pulled.length - 1) {
      const next = cardIdx + 1;
      setCardIdx(next);
      const card = pulled[next];
      if (card.r === 'EX') playSfx('exotic');
      else if (['SR', 'UR', 'L'].includes(card.r)) playSfx('rare');
    } else {
      setRevealPhase('summary');
    }
  };

  const closeReveal = () => {
    setRevealPhase('idle');
    dragRef.current = null;
    setBusy(false);
  };

  const currentCard = pulled[cardIdx];

  return (
    <div className="max-w-2xl mx-auto flex flex-col items-center text-center space-y-8 pt-2">
      {/* Wiki Masters Centered Hero Header */}
      <div className="space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[var(--txt)]">
          Ouvrir un paquet
        </h1>
        <p className="text-sm sm:text-base text-[var(--mut)]">
          Découvrez 5 nouvelles cartes Jules Haag
        </p>
        <button
          type="button"
          onClick={() => setHelpOpen(true)}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-600 dark:text-emerald-400 hover:underline pt-0.5"
        >
          Comment ça marche ?
        </button>
      </div>

      {/* Centered 3D Booster Pack with Warm Ambient Glow */}
      <div
        className="pack-wrap relative py-2"
        onPointerMove={(e) => {
          if (!packBtnRef.current) return;
          const r = packBtnRef.current.getBoundingClientRect();
          packBtnRef.current.style.setProperty(
            '--ry',
            `${((e.clientX - r.left) / r.width - 0.5) * 18}deg`
          );
          packBtnRef.current.style.setProperty(
            '--rx',
            `${-((e.clientY - r.top) / r.height - 0.5) * 18}deg`
          );
        }}
        onPointerLeave={() => {
          if (!packBtnRef.current) return;
          packBtnRef.current.style.setProperty('--rx', '0deg');
          packBtnRef.current.style.setProperty('--ry', '0deg');
        }}
      >
        <div
          aria-hidden="true"
          className="absolute -inset-6 rounded-full bg-amber-400/20 dark:bg-amber-300/15 blur-2xl pointer-events-none"
        />
        <button
          ref={packBtnRef}
          type="button"
          onClick={handleOpenPack}
          disabled={profile.packs < 1 || busy}
          aria-label="Ouvrir un paquet"
          className={`pack-btn relative z-10 ${profile.packs < 1 ? 'disabled' : ''}`}
        >
          <PackArt clipPath={clips.all} />
        </button>
      </div>

      {/* Centered Pack Counter Box (exact Wiki Masters card under pack) */}
      <div className="w-full max-w-xs space-y-3">
        <div className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-2">
          <div className="font-mono-num text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
            {profile.packs} <span className="text-base font-semibold text-[var(--mut)]">/ {MAX_PACKS}</span>
          </div>
          <div className="text-xs font-medium text-[var(--mut)]">
            {profile.packs >= MAX_PACKS ? (
              'paquets disponibles'
            ) : (
              <span className="inline-flex items-center gap-1">
                <Timer className="w-3.5 h-3.5 text-emerald-500" />
                Prochain dans{' '}
                <strong className="text-[var(--txt)] font-mono-num">
                  {nextM}:{String(nextS).padStart(2, '0')}
                </strong>
              </span>
            )}
          </div>
          <div className="w-full h-1.5 bg-[var(--surface-2)] rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-500 transition-all duration-500"
              style={{ width: `${Math.min(100, (profile.packs / MAX_PACKS) * 100)}%` }}
            />
          </div>
        </div>

        <button
          type="button"
          onClick={handleOpenPack}
          disabled={profile.packs < 1 || busy}
          className="w-full py-3.5 px-6 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none shadow-md transition-all"
        >
          Ouvrir un paquet
        </button>
      </div>

      {/* Secondary Booster Purchase Card */}
      <div className="w-full max-w-xs pt-2 text-left">
        <div className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="text-xs font-bold text-[var(--txt)] flex items-center gap-1.5">
              <Package className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              Booster supplémentaire
            </div>
            <div className="text-[11px] text-[var(--mut)] mt-0.5">
              5 cartes aléatoires
            </div>
          </div>
          <button
            type="button"
            onClick={handleBuyPack}
            disabled={profile.coins < EXTRA_PACK_COST}
            className="px-3.5 py-2 rounded-xl text-xs font-bold bg-[var(--surface-2)] hover:bg-emerald-600 hover:text-white text-[var(--txt)] disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 font-mono-num"
          >
            {EXTRA_PACK_COST} ●
          </button>
        </div>
      </div>

      {/* "Comment ça marche ?" Modal */}
      {helpOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 text-left"
          onClick={() => setHelpOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-[var(--txt)] flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-emerald-500" />
                Comment ça marche ?
              </h2>
              <button
                type="button"
                onClick={() => setHelpOpen(false)}
                className="w-8 h-8 rounded-full bg-[var(--surface-2)] text-[var(--txt)] flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <ul className="space-y-2.5 text-xs sm:text-sm text-[var(--mut)] leading-relaxed">
              <li>
                <strong className="text-[var(--txt)]">1. Boosters :</strong> vous recevez 1 paquet gratuit toutes les 10 minutes (jusqu’à 10 en réserve). Chaque paquet contient 5 cartes de Labbé et Marceau.
              </li>
              <li>
                <strong className="text-[var(--txt)]">2. Collection & Défausse :</strong> collectionnez les 15 cartes. Chaque carte défaussée rapporte <strong>1 ●</strong>.
              </li>
              <li>
                <strong className="text-[var(--txt)]">3. Marché & Enchères :</strong> mettez vos cartes aux enchères (à partir de 30 min) ou négociez des échanges directs avec les élèves.
              </li>
              <li>
                <strong className="text-[var(--txt)]">4. Batailles :</strong> accédez à <em>Bataille</em> via le menu <strong>Plus</strong> pour défier d’autres joueurs en duel classé ELO !
              </li>
            </ul>
            <div className="pt-2 border-t border-[var(--line)]">
              <div className="text-xs font-bold text-[var(--txt)] mb-2">Raretés disponibles</div>
              <div className="grid grid-cols-2 gap-1.5 text-xs text-[var(--mut)]">
                {(['C', 'PC', 'R', 'SR', 'UR', 'L', 'EX'] as const).map((r) => (
                  <div key={r} className="flex items-center gap-2">
                    <span className="font-extrabold w-6" style={{ color: RARITY_META[r].color }}>
                      {r}
                    </span>
                    <span>{RARITY_META[r].label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Tear-Open & Full-Screen Tap-Anywhere Card Reveal Overlay */}
      {revealPhase !== 'idle' && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/92 backdrop-blur-md flex flex-col items-center justify-center p-5 select-none touch-none cursor-pointer"
          onPointerDown={(e) => {
            if (revealPhase !== 'cut' || (e.target as HTMLElement).closest('[data-close]')) return;
            const w = pkRef.current?.getBoundingClientRect().width || 240;
            dragRef.current = { x: e.clientX, dir: 1, moved: false, w };
          }}
          onPointerMove={(e) => {
            if (!dragRef.current || revealPhase !== 'cut') return;
            const dx = e.clientX - dragRef.current.x;
            if (Math.abs(dx) > 6) {
              dragRef.current.moved = true;
              dragRef.current.dir = dx > 0 ? 1 : -1;
              setIsDraggingCut(true);
            }
            if (dragRef.current.moved) {
              setCutDir(dragRef.current.dir);
              setCutProg(Math.min(1, Math.abs(dx) / (dragRef.current.w * 0.8)));
            }
          }}
          onPointerUp={() => {
            if (!dragRef.current || revealPhase !== 'cut') return;
            const d = dragRef.current;
            dragRef.current = null;
            if (cutProg >= 0.55) {
              setCutProg(1);
              triggerOpenAnim();
            } else if (!d.moved) {
              setIsDraggingCut(true);
              setAutoCut(true);
              setCutDir(1);
              setCutProg(1);
              setTimeout(triggerOpenAnim, 250);
            } else {
              setIsDraggingCut(false);
              setCutProg(0);
            }
          }}
          onClick={(e) => {
            if (revealPhase === 'cards' && !(e.target as HTMLElement).closest('[data-close]')) {
              handleRevealAdvance();
            }
          }}
        >
          <button
            type="button"
            data-close
            onClick={(e) => {
              e.stopPropagation();
              closeReveal();
            }}
            className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-white/15 hover:bg-white/25 text-white font-bold flex items-center justify-center"
            aria-label="Fermer"
          >
            ✕
          </button>

          {(revealPhase === 'cut' || revealPhase === 'opening') && (
            <div className={`pk-stage flex flex-col items-center ${revealPhase === 'opening' ? 'opened' : ''}`}>
              <div ref={pkRef} className="pk-3d">
                <div className="pk-piece main">
                  <PackArt clipPath={clips.main} />
                </div>
                <div
                  className="pk-piece top"
                  style={{
                    transform:
                      revealPhase === 'cut' && cutProg > 0
                        ? `rotate(${cutProg * 3 * cutDir}deg) translateY(${-cutProg * 1.5}px)`
                        : undefined,
                  }}
                >
                  <PackArt clipPath={clips.top} />
                </div>
                <div
                  className={`cutline ${isDraggingCut ? 'drag' : ''} ${autoCut ? 'auto' : ''}`}
                  style={{
                    ['--p' as string]: cutProg,
                    ['--o' as string]: cutDir > 0 ? 'left' : 'right',
                    ['--k' as string]: cutDir > 0 ? cutProg * 100 : (1 - cutProg) * 100,
                  }}
                >
                  <i />
                  <b>✂</b>
                </div>
              </div>
              <p className="pk-hint mt-8 text-center font-display text-lg text-[#f7ebd1]">
                Glissez le long du pointillé pour déchirer
                <small className="block text-xs font-sans text-slate-300 mt-1">
                  ou touchez le paquet pour l’ouvrir
                </small>
              </p>
            </div>
          )}

          {revealPhase === 'cards' && currentCard && (
            <div className="flex flex-col items-center w-full max-w-xs text-center">
              <p
                className="font-display text-xl font-bold mb-4 px-3 py-1 rounded-lg bg-white/95 shadow"
                style={{ color: RARITY_META[currentCard.r].color }}
              >
                {currentCard.name} · {currentCard.sub}
              </p>
              <div className="w-64">
                <CardVisual card={currentCard} showStats />
              </div>
              <div className="flex gap-2 mt-5">
                {pulled.map((c, idx) => (
                  <span
                    key={`${c.id}-${idx}`}
                    className={`w-2.5 h-2.5 rounded-full transition-transform ${
                      idx === cardIdx ? 'bg-emerald-400 scale-125' : 'bg-white/30'
                    }`}
                  />
                ))}
              </div>
              <p
                className={`mt-4 text-xs font-semibold ${
                  currentCard.r === 'EX'
                    ? 'text-[#5eead4] tracking-widest'
                    : 'text-slate-200'
                }`}
              >
                {currentCard.r === 'EX'
                  ? '✦ CARTE EXOTIQUE · TOUCHEZ POUR CONTINUER ✦'
                  : cardIdx === pulled.length - 1
                  ? 'Touchez n’importe où pour voir le résumé'
                  : 'Touchez n’importe où pour passer à la carte suivante'}
              </p>
            </div>
          )}

          {revealPhase === 'summary' && (
            <div
              className="w-full max-w-xl text-center space-y-5 cursor-default"
              onClick={(e) => e.stopPropagation()}
            >
              <h2 className="font-display text-2xl font-bold text-white">
                Cartes obtenues dans ce paquet
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {pulled.map((c, idx) => (
                  <CardVisual key={`${c.id}-${idx}`} card={c} compact />
                ))}
              </div>
              <button
                type="button"
                onClick={closeReveal}
                className="px-7 py-3 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg"
              >
                Continuer
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
