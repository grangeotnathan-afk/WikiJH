import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Gift, Package, ShoppingBag, Sparkles, Timer } from 'lucide-react';
import {
  CARDS,
  CARDS_PER_PACK,
  DAILY_COINS,
  DAILY_COOLDOWN_MS,
  EXTRA_PACK_COST,
  MAX_PACKS,
  PACK_INTERVAL_MS,
  RARITY_META,
  drawBoosterPack,
  playSfx,
} from '../data/gameData';
import type { CardDef, NavTab, PlayerProfile } from '../types/game';
import { CardVisual } from './CardVisual';

interface PackOpeningViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onNavigate: (tab: NavTab) => void;
  onToast: (msg: string) => void;
}

const TEETH = 22;
const AMP = 1.1;
const CUT_Y = 13;

function buildPackClips() {
  const zigTop: string[] = [];
  for (let i = 0; i < TEETH; i++) {
    zigTop.push(`${((i / TEETH) * 100).toFixed(2)}% 0%`);
    zigTop.push(`${(((i + 0.5) / TEETH) * 100).toFixed(2)}% ${AMP}%`);
  }
  zigTop.push('100% 0%');

  const zigBot: string[] = [];
  for (let i = TEETH; i > 0; i--) {
    zigBot.push(`${((i / TEETH) * 100).toFixed(2)}% 100%`);
    zigBot.push(`${(((i - 0.5) / TEETH) * 100).toFixed(2)}% ${100 - AMP}%`);
  }
  zigBot.push('0% 100%');

  const tear: [number, number][] = [];
  for (let i = 0; i <= 16; i++) {
    tear.push([(i / 16) * 100, CUT_Y + (((i * 37) % 7) - 3) * 0.32]);
  }
  const tearFwd = tear.map(([x, y]) => `${x.toFixed(2)}% ${y.toFixed(2)}%`);
  const poly = (pts: string[]) => `polygon(${pts.join(',')})`;

  return {
    all: poly([...zigTop, ...zigBot]),
    top: poly([...zigTop, ...[...tearFwd].reverse()]),
    main: poly([...tearFwd, ...zigBot]),
  };
}

const PackArt: React.FC<{ clipPath: string }> = ({ clipPath }) => (
  <div className="pk-art" style={{ clipPath }}>
    <div className="pk-crimp t" />
    <div className="pk-frame" />
    <div className="pk-photo p1" />
    <div className="pk-mid">
      <i>◆ ◆ ◆</i>
      <em>Wiki JH</em>
      <small>Booster · 5 cartes</small>
    </div>
    <div className="pk-photo p2" />
    <div className="pk-crimp b" />
    <div className="pk-shade" />
    <div className="pk-gloss" />
  </div>
);

export const PackOpeningView: React.FC<PackOpeningViewProps> = ({
  profile,
  onUpdateProfile,
  onNavigate,
  onToast,
}) => {
  const clips = useMemo(() => buildPackClips(), []);
  const packBtnRef = useRef<HTMLButtonElement | null>(null);
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);

  // Reveal Modal state
  const [revealPhase, setRevealPhase] = useState<'idle' | 'cut' | 'opening' | 'cards' | 'summary'>('idle');
  const [pulled, setPulled] = useState<CardDef[]>([]);
  const [cardIdx, setCardIdx] = useState(0);
  const [cutProg, setCutProg] = useState(0);
  const [cutDir, setCutDir] = useState(1);
  const [isDraggingCut, setIsDraggingCut] = useState(false);
  const [autoCut, setAutoCut] = useState(false);
  const dragRef = useRef<{ x: number; dir: number; moved: boolean; w: number } | null>(null);
  const pkRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const ownedUnique = Object.values(profile.inv || {}).filter((n) => n > 0).length;
  const dailyAvailable = now - (profile.lastDailyAt || 0) >= DAILY_COOLDOWN_MS;
  const dailyLeftMs = Math.max(0, DAILY_COOLDOWN_MS - (now - (profile.lastDailyAt || 0)));

  const nextPackLeftMs =
    profile.packs >= MAX_PACKS
      ? 0
      : Math.max(0, PACK_INTERVAL_MS - (now - (profile.lastPackAt || now)));
  const nextM = Math.floor(nextPackLeftMs / 60000);
  const nextS = Math.floor((nextPackLeftMs % 60000) / 1000);

  const handleOpenPack = async () => {
    if (busy || revealPhase !== 'idle') return;
    if (profile.packs < 1) {
      onToast('Aucun paquet disponible pour le moment.');
      return;
    }
    setBusy(true);
    const list = drawBoosterPack(CARDS_PER_PACK);
    try {
      await onUpdateProfile((prev) => {
        const nextInv = { ...(prev.inv || {}) };
        list.forEach((c) => {
          const k = String(c.id);
          nextInv[k] = (nextInv[k] || 0) + 1;
        });
        return {
          ...prev,
          packs: Math.max(0, prev.packs - 1),
          lastPackAt: prev.packs >= MAX_PACKS ? Date.now() : prev.lastPackAt,
          opened: (prev.opened || 0) + 1,
          inv: nextInv,
        };
      });
      playSfx('pack');
      setPulled(list);
      setCardIdx(0);
      setCutProg(0);
      setCutDir(1);
      setIsDraggingCut(false);
      setAutoCut(false);
      setRevealPhase('cut');
    } catch {
      onToast('Impossible d’ouvrir le paquet.');
      setBusy(false);
    }
  };

  const handleBuyPack = async () => {
    if (profile.coins < EXTRA_PACK_COST) {
      onToast(`Il vous faut ${EXTRA_PACK_COST} ● pour acheter un booster.`);
      return;
    }
    await onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins - EXTRA_PACK_COST,
      packs: prev.packs + 1,
    }));
    playSfx('coin');
    onToast('+1 Booster ajouté à votre réserve !');
  };

  const handleClaimDaily = async () => {
    if (!dailyAvailable) return;
    await onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins + DAILY_COINS,
      packs: prev.packs + 1,
      lastDailyAt: Date.now(),
    }));
    playSfx('win');
    onToast(`Bonus quotidien : +${DAILY_COINS} ● et +1 Booster !`);
  };

  const triggerOpenAnim = () => {
    setRevealPhase('opening');
    if (navigator.vibrate) navigator.vibrate([20, 30, 40]);
    setTimeout(() => {
      setRevealPhase('cards');
      setCardIdx(0);
      const first = pulled[0];
      if (first?.r === 'EX') playSfx('exotic');
      else if (first && ['SR', 'UR', 'L'].includes(first.r)) playSfx('rare');
    }, 700);
  };

  const handleRevealAdvance = () => {
    if (revealPhase !== 'cards') return;
    if (cardIdx < pulled.length - 1) {
      const next = cardIdx + 1;
      setCardIdx(next);
      const card = pulled[next];
      if (card.r === 'EX') playSfx('exotic');
      else if (['SR', 'UR', 'L'].includes(card.r)) playSfx('rare');
    } else {
      setRevealPhase('summary');
    }
  };

  const closeReveal = () => {
    setRevealPhase('idle');
    dragRef.current = null;
    setBusy(false);
  };

  const currentCard = pulled[cardIdx];

  return (
    <div className="space-y-8">
      {/* Main Interactive Booster Stage */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        <div className="lg:col-span-7 flex flex-col items-center text-center py-4 sm:py-6">
          <div className="mb-4">
            <div className="flex items-baseline justify-center gap-2">
              <span className="font-display text-5xl sm:text-6xl font-bold tracking-tight bg-gradient-to-b from-[#fff6dc] to-[#d9b872] bg-clip-text text-transparent font-mono-num">
                {profile.packs}
              </span>
              <span className="text-xl text-[var(--mut)] font-mono-num">/ {MAX_PACKS}</span>
            </div>
            <p className="text-sm text-[var(--mut)] mt-1">
              {profile.packs >= MAX_PACKS ? (
                'Réserve de boosters au maximum'
              ) : (
                <span className="inline-flex items-center gap-1.5">
                  <Timer className="w-3.5 h-3.5 text-[var(--acc)]" />
                  Prochain paquet dans{' '}
                  <strong className="text-[var(--acc)] font-mono-num">
                    {nextM}:{String(nextS).padStart(2, '0')}
                  </strong>
                </span>
              )}
            </p>
            <div className="w-56 h-1.5 bg-white/5 rounded-full overflow-hidden mx-auto mt-3">
              <div
                className="h-full bg-gradient-to-r from-[#c8952d] to-[#f6dfaa] transition-all duration-500"
                style={{ width: `${Math.min(100, (profile.packs / MAX_PACKS) * 100)}%` }}
              />
            </div>
          </div>

          <div
            className="pack-wrap my-3"
            onPointerMove={(e) => {
              if (!packBtnRef.current) return;
              const r = packBtnRef.current.getBoundingClientRect();
              packBtnRef.current.style.setProperty(
                '--ry',
                `${((e.clientX - r.left) / r.width - 0.5) * 18}deg`
              );
              packBtnRef.current.style.setProperty(
                '--rx',
                `${-((e.clientY - r.top) / r.height - 0.5) * 18}deg`
              );
            }}
            onPointerLeave={() => {
              if (!packBtnRef.current) return;
              packBtnRef.current.style.setProperty('--rx', '0deg');
              packBtnRef.current.style.setProperty('--ry', '0deg');
            }}
          >
            <button
              ref={packBtnRef}
              type="button"
              onClick={handleOpenPack}
              disabled={profile.packs < 1 || busy}
              aria-label="Ouvrir un paquet"
              className={`pack-btn ${profile.packs < 1 ? 'disabled' : ''}`}
            >
              <PackArt clipPath={clips.all} />
            </button>
          </div>

          <button
            type="button"
            onClick={handleOpenPack}
            disabled={profile.packs < 1 || busy}
            className="mt-3 px-7 py-3.5 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] shadow-[0_10px_28px_-10px_rgba(226,187,107,0.7)] hover:brightness-110 active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none transition-all whitespace-nowrap"
          >
            Ouvrir un booster (5 cartes)
          </button>
        </div>

        {/* Side Action Column: Campus Economy & Quick Actions */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="font-display text-lg font-bold text-white">
                  Bonus & Boutique Boosters
                </h2>
                <p className="text-xs text-[var(--mut)] mt-0.5">
                  Monnaie virtuelle sans argent réel · Utilisable au Marché et en Boutique
                </p>
              </div>
              <Gift className="w-5 h-5 text-[var(--acc)] shrink-0" />
            </div>

            <div className="pt-3 border-t border-[var(--line)] flex items-center justify-between gap-4">
              <div>
                <div className="text-sm font-semibold text-white">Présence Quotidienne</div>
                <div className="text-xs text-[var(--mut)]">
                  +{DAILY_COINS} ● et +1 booster gratuit chaque jour
                </div>
              </div>
              <button
                type="button"
                onClick={handleClaimDaily}
                disabled={!dailyAvailable}
                className="px-4 py-2 rounded-lg text-xs font-bold bg-[#e2bb6b]/15 text-[#e2bb6b] border border-[#e2bb6b]/35 hover:bg-[#e2bb6b]/25 disabled:opacity-45 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 font-mono-num"
              >
                {dailyAvailable
                  ? 'Réclamer'
                  : `${Math.floor(dailyLeftMs / 3600000)}h ${Math.floor(
                      (dailyLeftMs % 3600000) / 60000
                    )}m`}
              </button>
            </div>

            <div className="pt-3 border-t border-[var(--line)] flex items-center justify-between gap-4">
              <div>
                <div className="text-sm font-semibold text-white">Booster Supplémentaire</div>
                <div className="text-xs text-[var(--mut)]">
                  5 cartes aléatoires · Chances Légendaire & Exotique
                </div>
              </div>
              <button
                type="button"
                onClick={handleBuyPack}
                disabled={profile.coins < EXTRA_PACK_COST}
                className="px-4 py-2 rounded-lg text-xs font-bold bg-white/5 text-white border border-[var(--line)] hover:bg-white/10 disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 font-mono-num"
              >
                {EXTRA_PACK_COST} ●
              </button>
            </div>
          </div>

          {/* Progression & Navigation Shortcuts */}
          <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[var(--mut)]">Collection Jules Haag</span>
              <span className="font-mono-num font-bold text-white">
                {ownedUnique} / {CARDS.length} cartes
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full bg-emerald-400 transition-all duration-500"
                style={{ width: `${(ownedUnique / CARDS.length) * 100}%` }}
              />
            </div>
            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => onNavigate('arena')}
                className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-white transition-colors"
              >
                <Sparkles className="w-4 h-4 text-[var(--acc)]" />
                Entrer en Arène
              </button>
              <button
                type="button"
                onClick={() => onNavigate('commerce')}
                className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-white transition-colors"
              >
                <ShoppingBag className="w-4 h-4 text-sky-400" />
                Marché & Échanges
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Drop Rates Transparency Strip */}
      <section className="pt-4 border-t border-[var(--line)]">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--mut)]">
          <span className="font-medium text-white/80 flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-[var(--acc)]" />
            Raretés Wiki JH
          </span>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            {(['C', 'PC', 'R', 'SR', 'UR', 'L', 'EX'] as const).map((r) => (
              <span key={r} className="inline-flex items-center gap-1.5">
                <span
                  className="font-bold"
                  style={{ color: RARITY_META[r].color }}
                >
                  {r}
                </span>
                <span>{RARITY_META[r].label}</span>
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Tear-Open & Card Reveal Overlay */}
      {revealPhase !== 'idle' && (
        <div
          className="fixed inset-0 z-50 bg-[radial-gradient(70%_50%_at_50%_40%,rgba(26,31,46,0.97),rgba(5,6,10,0.99))] flex flex-col items-center justify-center p-5 select-none touch-none"
          onPointerDown={(e) => {
            if (revealPhase !== 'cut' || (e.target as HTMLElement).closest('[data-close]')) return;
            const w = pkRef.current?.getBoundingClientRect().width || 240;
            dragRef.current = { x: e.clientX, dir: 1, moved: false, w };
          }}
          onPointerMove={(e) => {
            if (!dragRef.current || revealPhase !== 'cut') return;
            const dx = e.clientX - dragRef.current.x;
            if (Math.abs(dx) > 6) {
              dragRef.current.moved = true;
              dragRef.current.dir = dx > 0 ? 1 : -1;
              setIsDraggingCut(true);
            }
            if (dragRef.current.moved) {
              setCutDir(dragRef.current.dir);
              setCutProg(Math.min(1, Math.abs(dx) / (dragRef.current.w * 0.8)));
            }
          }}
          onPointerUp={() => {
            if (!dragRef.current || revealPhase !== 'cut') return;
            const d = dragRef.current;
            dragRef.current = null;
            if (cutProg >= 0.55) {
              setCutProg(1);
              triggerOpenAnim();
            } else if (!d.moved) {
              setIsDraggingCut(true);
              setAutoCut(true);
              setCutDir(1);
              setCutProg(1);
              setTimeout(triggerOpenAnim, 250);
            } else {
              setIsDraggingCut(false);
              setCutProg(0);
            }
          }}
          onClick={(e) => {
            if (revealPhase === 'cards' && !(e.target as HTMLElement).closest('[data-close]')) {
              handleRevealAdvance();
            }
          }}
        >
          <button
            type="button"
            data-close
            onClick={closeReveal}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white font-bold flex items-center justify-center"
            aria-label="Fermer"
          >
            ✕
          </button>

          {(revealPhase === 'cut' || revealPhase === 'opening') && (
            <div className={`pk-stage flex flex-col items-center ${revealPhase === 'opening' ? 'opened' : ''}`}>
              <div ref={pkRef} className="pk-3d">
                <div className="pk-piece main">
                  <PackArt clipPath={clips.main} />
                </div>
                <div
                  className="pk-piece top"
                  style={{
                    transform:
                      revealPhase === 'cut' && cutProg > 0
                        ? `rotate(${cutProg * 3 * cutDir}deg) translateY(${-cutProg * 1.5}px)`
                        : undefined,
                  }}
                >
                  <PackArt clipPath={clips.top} />
                </div>
                <div
                  className={`cutline ${isDraggingCut ? 'drag' : ''} ${autoCut ? 'auto' : ''}`}
                  style={{
                    ['--p' as string]: cutProg,
                    ['--o' as string]: cutDir > 0 ? 'left' : 'right',
                    ['--k' as string]: cutDir > 0 ? cutProg * 100 : (1 - cutProg) * 100,
                  }}
                >
                  <i />
                  <b>✂</b>
                </div>
              </div>
              <p className="pk-hint mt-8 text-center font-display text-lg text-[#e9dcc0]">
                Glissez le long du pointillé pour déchirer
                <small className="block text-xs font-sans text-[var(--mut)] mt-1">
                  ou touchez le paquet pour l’ouvrir
                </small>
              </p>
            </div>
          )}

          {revealPhase === 'cards' && currentCard && (
            <div className="flex flex-col items-center w-full max-w-xs text-center">
              <p
                className="font-display text-xl font-bold mb-4"
                style={{ color: RARITY_META[currentCard.r].color }}
              >
                {currentCard.name} · {currentCard.sub}
              </p>
              <div className="w-64">
                <CardVisual card={currentCard} showStats />
              </div>
              <div className="flex gap-2 mt-5">
                {pulled.map((c, idx) => (
                  <span
                    key={`${c.id}-${idx}`}
                    className={`w-2 h-2 rounded-full transition-transform ${
                      idx === cardIdx ? 'bg-[#e2bb6b] scale-125' : 'bg-white/25'
                    }`}
                  />
                ))}
              </div>
              <p
                className={`mt-4 text-xs ${
                  currentCard.r === 'EX'
                    ? 'text-[#2ff3e0] font-extrabold tracking-widest'
                    : 'text-[var(--mut)]'
                }`}
              >
                {currentCard.r === 'EX'
                  ? '✦ CARTE EXOTIQUE ✦'
                  : cardIdx === pulled.length - 1
                  ? 'Touchez pour voir le résumé'
                  : 'Touchez n’importe où pour la carte suivante'}
              </p>
            </div>
          )}

          {revealPhase === 'summary' && (
            <div className="w-full max-w-xl text-center space-y-5">
              <h2 className="font-display text-2xl font-bold text-white">
                Cartes obtenues dans ce booster
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {pulled.map((c, idx) => (
                  <CardVisual key={`${c.id}-${idx}`} card={c} compact />
                ))}
              </div>
              <button
                type="button"
                onClick={closeReveal}
                className="px-7 py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f]"
              >
                Continuer
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
