import React, { useMemo, useState } from 'react';
import { Award, Search, Trophy } from 'lucide-react';
import {
  CARDS,
  computeCollectionScore,
  getCardById,
  getCosmetic,
} from '../data/gameData';
import type { PlayerProfile, Site } from '../types/game';

interface LeaderboardViewProps {
  profile: PlayerProfile;
  allPlayers: PlayerProfile[];
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  profile,
  allPlayers,
}) => {
  const [sortBy, setSortBy] = useState<'elo' | 'collection' | 'wins'>('elo');
  const [siteFilter, setSiteFilter] = useState<'ALL' | Site>('ALL');
  const [search, setSearch] = useState('');
  const [inspectPlayer, setInspectPlayer] = useState<PlayerProfile | null>(null);

  const siteStats = useMemo(() => {
    const labbe = allPlayers.filter((p) => p.site === 'Labbé');
    const marceau = allPlayers.filter((p) => p.site === 'Marceau');
    const sumPoints = (arr: PlayerProfile[]) =>
      arr.reduce(
        (acc, p) =>
          acc + (p.elo - 1000) + p.wins * 35 + Math.round(computeCollectionScore(p.inv || {}) / 5),
        0
      );
    const labbePts = Math.max(0, sumPoints(labbe));
    const marceauPts = Math.max(0, sumPoints(marceau));
    const total = Math.max(1, labbePts + marceauPts);

    return {
      labbeCount: labbe.length,
      marceauCount: marceau.length,
      labbeWins: labbe.reduce((s, p) => s + (p.wins || 0), 0),
      marceauWins: marceau.reduce((s, p) => s + (p.wins || 0), 0),
      labbePts,
      marceauPts,
      labbePct: Math.round((labbePts / total) * 100),
    };
  }, [allPlayers]);

  const rankedPlayers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...allPlayers]
      .filter((p) => siteFilter === 'ALL' || p.site === siteFilter)
      .filter((p) => !q || `${p.displayName} ${p.classe}`.toLowerCase().includes(q))
      .sort((a, b) => {
        if (sortBy === 'elo') return (b.elo || 1000) - (a.elo || 1000);
        if (sortBy === 'wins') return (b.wins || 0) - (a.wins || 0);
        return computeCollectionScore(b.inv || {}) - computeCollectionScore(a.inv || {});
      });
  }, [allPlayers, siteFilter, search, sortBy]);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-[var(--txt)]">
            Classement Global Temps Réel
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1">
            {allPlayers.length} joueur(s) classé(s) sur les deux campus de Besançon
          </p>
        </div>
      </div>

      {/* Inter-Site War Live Scoreboard */}
      <section className="p-6 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-5">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <h2 className="font-display text-lg font-bold text-[var(--txt)] flex items-center gap-2">
            <Trophy className="w-5 h-5 text-[var(--acc)]" />
            Coupe Inter-Sites : Labbé vs Marceau
          </h2>
          <span className="text-xs font-medium text-[var(--mut)]">Mise à jour en direct</span>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="font-bold text-blue-600">Site Labbé · Général & Technologique</div>
            <div className="font-mono-num text-2xl font-extrabold text-[var(--txt)] mt-0.5">
              {siteStats.labbePts.toLocaleString('fr-FR')} pts
            </div>
            <div className="text-xs text-[var(--mut)] font-mono-num mt-0.5">
              {siteStats.labbeCount} élève(s) · {siteStats.labbeWins} victoire(s)
            </div>
          </div>
          <div className="text-right">
            <div className="font-bold text-emerald-600">Site Marceau · Lycée Professionnel</div>
            <div className="font-mono-num text-2xl font-extrabold text-[var(--txt)] mt-0.5">
              {siteStats.marceauPts.toLocaleString('fr-FR')} pts
            </div>
            <div className="text-xs text-[var(--mut)] font-mono-num mt-0.5">
              {siteStats.marceauCount} élève(s) · {siteStats.marceauWins} victoire(s)
            </div>
          </div>
        </div>

        <div className="h-3 rounded-full overflow-hidden bg-emerald-500/80 flex">
          <div
            className="h-full bg-blue-600 transition-all duration-700"
            style={{ width: `${siteStats.labbePct}%` }}
          />
        </div>
      </section>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3 justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-[var(--mut)] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un élève ou une classe…"
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-sm text-[var(--txt)] shadow-sm"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          <div className="flex p-1 rounded-xl bg-[var(--surface)] border border-[var(--line)] shadow-sm">
            {([
              ['elo', 'ELO'],
              ['collection', 'Collection'],
              ['wins', 'Victoires'],
            ] as const).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setSortBy(key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  sortBy === key
                    ? 'bg-gradient-to-r from-[#d99b26] to-[#f4d47c] text-[#1d1405]'
                    : 'text-[var(--mut)] hover:text-[var(--txt)]'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex p-1 rounded-xl bg-[var(--surface)] border border-[var(--line)] shadow-sm">
            {(['ALL', 'Labbé', 'Marceau'] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSiteFilter(s)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  siteFilter === s
                    ? 'bg-slate-900 text-white dark:bg-[#e2bb6b] dark:text-[#1d1405]'
                    : 'text-[var(--mut)] hover:text-[var(--txt)]'
                }`}
              >
                {s === 'ALL' ? 'Tous' : s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Rankings Table */}
      <div className="rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm overflow-hidden">
        <div className="divide-y divide-[var(--line)]">
          {rankedPlayers.map((p, idx) => {
            const isMe = p.uid === profile.uid;
            const av = getCosmetic(p.avatarId);
            const fr = getCosmetic(p.frameId);
            const title = getCosmetic(p.titleId);
            const colScore = computeCollectionScore(p.inv || {});
            const unique = Object.values(p.inv || {}).filter((n) => n > 0).length;

            return (
              <button
                key={p.uid}
                type="button"
                onClick={() => setInspectPlayer(p)}
                className={`w-full text-left px-5 py-4 flex items-center justify-between gap-4 hover:bg-[var(--surface-2)]/60 transition-colors ${
                  isMe ? 'bg-amber-50/80 dark:bg-amber-950/35' : ''
                }`}
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <span
                    className={`w-8 text-center font-mono-num font-extrabold text-sm shrink-0 ${
                      idx === 0
                        ? 'text-amber-600'
                        : idx === 1
                        ? 'text-slate-500'
                        : idx === 2
                        ? 'text-orange-600'
                        : 'text-[var(--mut)]'
                    }`}
                  >
                    #{idx + 1}
                  </span>

                  <div
                    className={`w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-base font-bold text-white shrink-0 ${
                      fr?.previewClass || ''
                    }`}
                  >
                    {av?.symbol || '◆'}
                  </div>

                  <div className="min-w-0">
                    <div className="font-bold text-sm text-[var(--txt)] truncate flex items-center gap-2">
                      <span>{p.displayName}</span>
                      {isMe && <span className="text-[11px] font-bold text-[var(--acc)]">(Vous)</span>}
                    </div>
                    <div className="text-xs text-[var(--mut)] truncate">
                      {p.site}{p.classe ? ` · ${p.classe}` : ''} · {title?.name || 'Élève'} · {unique}/{CARDS.length} cartes
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-5 shrink-0 font-mono-num text-right">
                  <div className="hidden sm:block">
                    <div className="text-xs font-bold text-[var(--txt)]">{p.wins}V / {p.losses}D</div>
                    <div className="text-[11px] text-[var(--mut)]">Score {colScore}</div>
                  </div>
                  <div>
                    <div className="text-sm font-extrabold text-[var(--acc)]">{p.elo} ELO</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Inspect Player Profile Modal */}
      {inspectPlayer && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/55 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setInspectPlayer(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className={`p-5 bg-gradient-to-br ${
                getCosmetic(inspectPlayer.bannerId)?.previewClass || 'from-slate-800 to-slate-900'
              } border-b border-[var(--line)] flex items-center justify-between`}
            >
              <div className="flex items-center gap-3.5">
                <div
                  className={`w-14 h-14 rounded-full bg-black/45 flex items-center justify-center text-2xl text-white ${
                    getCosmetic(inspectPlayer.frameId)?.previewClass || ''
                  }`}
                >
                  {getCosmetic(inspectPlayer.avatarId)?.symbol || '◆'}
                </div>
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    {inspectPlayer.displayName}
                  </h3>
                  <p className="text-xs text-white/85">
                    {inspectPlayer.site} · {inspectPlayer.classe || 'Lycée Jules Haag'}
                  </p>
                  <p className="text-xs text-[#f6dfaa] font-semibold mt-0.5">
                    {getCosmetic(inspectPlayer.titleId)?.name}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInspectPlayer(null)}
                className="w-8 h-8 rounded-full bg-black/40 text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4">
              {inspectPlayer.bio && (
                <p className="text-xs text-[var(--mut)] italic">« {inspectPlayer.bio} »</p>
              )}

              <div className="grid grid-cols-3 gap-3 text-center font-mono-num">
                <div className="p-3 rounded-xl bg-[var(--surface-2)]">
                  <div className="text-base font-extrabold text-[var(--acc)]">{inspectPlayer.elo}</div>
                  <div className="text-[11px] text-[var(--mut)]">ELO</div>
                </div>
                <div className="p-3 rounded-xl bg-[var(--surface-2)]">
                  <div className="text-base font-extrabold text-[var(--txt)]">
                    {inspectPlayer.wins}V / {inspectPlayer.losses}D
                  </div>
                  <div className="text-[11px] text-[var(--mut)]">Bilan</div>
                </div>
                <div className="p-3 rounded-xl bg-[var(--surface-2)]">
                  <div className="text-base font-extrabold text-emerald-600">
                    {Object.values(inspectPlayer.inv || {}).filter((n) => n > 0).length}/{CARDS.length}
                  </div>
                  <div className="text-[11px] text-[var(--mut)]">Cartes</div>
                </div>
              </div>

              {getCardById(inspectPlayer.showcaseCardId) && (
                <div className="pt-2 border-t border-[var(--line)] flex items-center justify-between text-xs">
                  <span className="text-[var(--mut)] flex items-center gap-1.5">
                    <Award className="w-4 h-4 text-[var(--acc)]" />
                    Carte favorite
                  </span>
                  <span className="font-bold text-[var(--txt)]">
                    {getCardById(inspectPlayer.showcaseCardId)?.icon}{' '}
                    {getCardById(inspectPlayer.showcaseCardId)?.name}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
