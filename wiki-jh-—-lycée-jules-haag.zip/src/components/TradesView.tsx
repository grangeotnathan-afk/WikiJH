import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import { ArrowLeftRight } from 'lucide-react';
import { CARDS, getCardById, playSfx } from '../data/gameData';
import { db, handleFirestoreError, sanitizePlayerUpdate } from '../firebase/client';
import { OperationType, type PlayerProfile, type TradeOffer } from '../types/game';
import { CardVisual } from './CardVisual';

interface TradesViewProps {
  profile: PlayerProfile;
  allPlayers: PlayerProfile[];
  onToast: (msg: string) => void;
}

export const TradesView: React.FC<TradesViewProps> = ({
  profile,
  allPlayers,
  onToast,
}) => {
  const [tradeTab, setTradeTab] = useState<'received' | 'sent' | 'new'>('received');
  const [receivedTrades, setReceivedTrades] = useState<TradeOffer[]>([]);
  const [sentTrades, setSentTrades] = useState<TradeOffer[]>([]);
  const [playerQuery, setPlayerQuery] = useState('');
  const [targetPlayer, setTargetPlayer] = useState<PlayerProfile | null>(null);
  const [giveCards, setGiveCards] = useState<number[]>([]);
  const [getCards, setGetCards] = useState<number[]>([]);

  const claimedTradesRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const qRec = query(collection(db, 'trades'), where('toId', '==', profile.uid));
    const qSent = query(collection(db, 'trades'), where('fromId', '==', profile.uid));

    const unsubRec = onSnapshot(
      qRec,
      (snap) => {
        setReceivedTrades(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<TradeOffer, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'trades')
    );

    const unsubSent = onSnapshot(
      qSent,
      (snap) => {
        setSentTrades(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<TradeOffer, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'trades')
    );

    return () => {
      unsubRec();
      unsubSent();
    };
  }, [profile.uid]);

  // Auto-claim resolved sent trades
  useEffect(() => {
    const unclaimed = sentTrades.filter(
      (t) =>
        ['accepted', 'declined', 'cancelled'].includes(t.status) &&
        !t.fromClaimed &&
        !claimedTradesRef.current.has(t.id)
    );

    unclaimed.forEach(async (t) => {
      claimedTradesRef.current.add(t.id);
      try {
        await runTransaction(db, async (tx) => {
          const tRef = doc(db, 'trades', t.id);
          const pRef = doc(db, 'players', profile.uid);
          const tSnap = await tx.get(tRef);
          const pSnap = await tx.get(pRef);
          if (!tSnap.exists() || !pSnap.exists()) return;
          const td = tSnap.data() as TradeOffer;
          const pd = pSnap.data() as PlayerProfile;
          if (td.fromClaimed) return;

          const nextInv = { ...(pd.inv || {}) };
          const cardsToAdd = td.status === 'accepted' ? td.get : td.give;
          cardsToAdd.forEach((cid) => {
            const k = String(cid);
            nextInv[k] = (nextInv[k] || 0) + 1;
          });

          tx.update(
            pRef,
            sanitizePlayerUpdate({
              ...pd,
              inv: nextInv,
              tradesCompleted:
                (pd.tradesCompleted || 0) + (td.status === 'accepted' ? 1 : 0),
            })
          );
          tx.update(tRef, { fromClaimed: true, updatedAt: serverTimestamp() });
        });
        if (t.status === 'accepted') {
          playSfx('win');
          onToast(`Échange avec ${t.toName} finalisé ! Cartes ajoutées.`);
        }
      } catch (err) {
        console.error(err);
      }
    });
  }, [sentTrades, profile.uid, onToast]);

  const pendingReceivedCount = receivedTrades.filter((t) => t.status === 'pending').length;
  const ownedTradeable = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);
  const otherPlayers = useMemo(() => {
    const q = playerQuery.trim().toLowerCase();
    return allPlayers
      .filter((p) => p.uid !== profile.uid)
      .filter((p) => !q || `${p.displayName} ${p.site}`.toLowerCase().includes(q))
      .slice(0, 12);
  }, [allPlayers, profile.uid, playerQuery]);

  const handleSendTrade = async () => {
    if (!targetPlayer) {
      onToast('Sélectionnez un destinataire.');
      return;
    }
    if (giveCards.length === 0 || getCards.length === 0) {
      onToast('Choisissez au moins une carte à donner et une à recevoir.');
      return;
    }
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists()) throw new Error('Profil introuvable');
        const pd = pSnap.data() as PlayerProfile;
        const nextInv = { ...(pd.inv || {}) };
        for (const cid of giveCards) {
          const k = String(cid);
          if ((nextInv[k] || 0) < 1) {
            throw new Error(`Carte indisponible : ${getCardById(cid)?.name}`);
          }
          nextInv[k]--;
        }
        const tRef = doc(collection(db, 'trades'));
        tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
        tx.set(tRef, {
          fromId: profile.uid,
          fromName: profile.displayName,
          fromSite: profile.site,
          toId: targetPlayer.uid,
          toName: targetPlayer.displayName,
          toSite: targetPlayer.site,
          give: giveCards,
          get: getCards,
          status: 'pending',
          fromClaimed: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      setGiveCards([]);
      setGetCards([]);
      setTargetPlayer(null);
      setTradeTab('sent');
      playSfx('pack');
      onToast(`Offre envoyée à ${targetPlayer.displayName} !`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Erreur d’envoi');
    }
  };

  const handleRespondTrade = async (t: TradeOffer, accept: boolean) => {
    try {
      if (accept) {
        await runTransaction(db, async (tx) => {
          const tRef = doc(db, 'trades', t.id);
          const pRef = doc(db, 'players', profile.uid);
          const tSnap = await tx.get(tRef);
          const pSnap = await tx.get(pRef);
          if (!tSnap.exists() || !pSnap.exists()) throw new Error('Offre introuvable');
          const td = tSnap.data() as TradeOffer;
          const pd = pSnap.data() as PlayerProfile;
          if (td.status !== 'pending') throw new Error('Offre déjà traitée');

          const nextInv = { ...(pd.inv || {}) };
          for (const cid of td.get) {
            const k = String(cid);
            if ((nextInv[k] || 0) < 1) {
              throw new Error(`Vous n’avez plus ${getCardById(cid)?.name}`);
            }
            nextInv[k]--;
          }
          for (const cid of td.give) {
            const k = String(cid);
            nextInv[k] = (nextInv[k] || 0) + 1;
          }

          tx.update(
            pRef,
            sanitizePlayerUpdate({
              ...pd,
              inv: nextInv,
              tradesCompleted: (pd.tradesCompleted || 0) + 1,
            })
          );
          tx.update(tRef, { status: 'accepted', updatedAt: serverTimestamp() });
        });
        playSfx('win');
        onToast('Échange accepté ! Cartes ajoutées à votre collection.');
      } else {
        await updateDoc(doc(db, 'trades', t.id), {
          status: 'declined',
          updatedAt: serverTimestamp(),
        });
        onToast('Offre refusée.');
      }
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Erreur lors de la réponse');
    }
  };

  const handleCancelTrade = async (t: TradeOffer) => {
    try {
      await updateDoc(doc(db, 'trades', t.id), {
        status: 'cancelled',
        updatedAt: serverTimestamp(),
      });
      onToast('Offre annulée, vos cartes reviennent dans votre collection.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `trades/${t.id}`);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div>
        <h1 className="font-display text-3xl font-bold text-[var(--txt)] flex items-center gap-2.5">
          <ArrowLeftRight className="w-7 h-7 text-emerald-500" />
          Échanges entre Joueurs
        </h1>
        <p className="text-sm text-[var(--mut)] mt-1">
          Proposez des échanges directs de cartes avec les élèves des sites Labbé et Marceau
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setTradeTab('received')}
          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
            tradeTab === 'received'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          Reçues ({pendingReceivedCount})
        </button>
        <button
          type="button"
          onClick={() => setTradeTab('sent')}
          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
            tradeTab === 'sent'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          Envoyées ({sentTrades.length})
        </button>
        <button
          type="button"
          onClick={() => setTradeTab('new')}
          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
            tradeTab === 'new'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--txt)] hover:border-emerald-500'
          }`}
        >
          + Nouvelle offre
        </button>
      </div>

      {tradeTab === 'received' && (
        <div className="space-y-3">
          {receivedTrades.length === 0 ? (
            <div className="p-12 rounded-2xl bg-[var(--surface)] border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
              Aucune offre d’échange reçue.
            </div>
          ) : (
            receivedTrades.map((t) => (
              <div
                key={t.id}
                className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between text-sm">
                  <span className="font-bold text-[var(--txt)]">
                    De {t.fromName} · <span className="text-[var(--mut)] font-normal">{t.fromSite}</span>
                  </span>
                  <span className="text-xs font-semibold text-[var(--mut)]">
                    {t.status === 'pending'
                      ? 'En attente'
                      : t.status === 'accepted'
                      ? 'Acceptée'
                      : t.status === 'declined'
                      ? 'Refusée'
                      : 'Annulée'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <div className="text-[var(--mut)] mb-1.5">Vous recevez</div>
                    <div className="flex flex-wrap gap-2">
                      {t.give.map((cid, i) => {
                        const c = getCardById(cid);
                        return c ? (
                          <span key={`${cid}-${i}`} className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 font-semibold">
                            {c.name} ({c.r})
                          </span>
                        ) : null;
                      })}
                    </div>
                  </div>
                  <div>
                    <div className="text-[var(--mut)] mb-1.5">Vous donnez</div>
                    <div className="flex flex-wrap gap-2">
                      {t.get.map((cid, i) => {
                        const c = getCardById(cid);
                        return c ? (
                          <span key={`${cid}-${i}`} className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-semibold">
                            {c.name} ({c.r})
                          </span>
                        ) : null;
                      })}
                    </div>
                  </div>
                </div>

                {t.status === 'pending' && (
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => handleRespondTrade(t, false)}
                      className="px-4 py-2 rounded-xl border border-rose-300 text-rose-700 text-xs font-bold"
                    >
                      Refuser
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRespondTrade(t, true)}
                      className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold"
                    >
                      Accepter l’échange
                    </button>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {tradeTab === 'sent' && (
        <div className="space-y-3">
          {sentTrades.length === 0 ? (
            <div className="p-12 rounded-2xl bg-[var(--surface)] border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
              Aucune offre envoyée.
            </div>
          ) : (
            sentTrades.map((t) => (
              <div
                key={t.id}
                className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="text-sm font-bold text-[var(--txt)]">
                    À {t.toName} · <span className="text-[var(--mut)] font-normal">{t.toSite}</span>
                  </div>
                  <div className="text-xs text-[var(--mut)]">
                    Vous offrez {t.give.map((id) => getCardById(id)?.name).join(', ')} contre{' '}
                    {t.get.map((id) => getCardById(id)?.name).join(', ')}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-[var(--mut)]">
                    {t.status === 'pending'
                      ? 'En attente'
                      : t.status === 'accepted'
                      ? 'Acceptée'
                      : t.status === 'declined'
                      ? 'Refusée'
                      : 'Annulée'}
                  </span>
                  {t.status === 'pending' && (
                    <button
                      type="button"
                      onClick={() => handleCancelTrade(t)}
                      className="px-3 py-1.5 rounded-lg border border-rose-300 text-rose-700 text-xs font-bold"
                    >
                      Annuler
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tradeTab === 'new' && (
        <div className="p-6 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-5">
          <div>
            <label className="block text-xs font-bold text-[var(--mut)] mb-2">
              1. Rechercher un élève (Labbé ou Marceau)
            </label>
            <input
              type="search"
              value={playerQuery}
              onChange={(e) => setPlayerQuery(e.target.value)}
              placeholder="Pseudo du joueur…"
              className="w-full px-4 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)]"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2.5 max-h-40 overflow-y-auto">
              {otherPlayers.map((p) => (
                <button
                  key={p.uid}
                  type="button"
                  onClick={() => {
                    setTargetPlayer(p);
                    setGetCards([]);
                  }}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-colors flex justify-between items-center ${
                    targetPlayer?.uid === p.uid
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-[var(--txt)]'
                      : 'bg-[var(--surface-2)]/60 border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
                  }`}
                >
                  <span className="font-bold text-[var(--txt)]">{p.displayName}</span>
                  <span>{p.site} · {p.elo} ELO</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-bold text-[var(--mut)] mb-2">
              2. Cartes que vous proposez ({giveCards.length})
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
              {ownedTradeable.map((c) => (
                <CardVisual
                  key={c.id}
                  card={c}
                  compact
                  count={profile.inv[String(c.id)]}
                  selected={giveCards.includes(c.id)}
                  onClick={() =>
                    setGiveCards((prev) =>
                      prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id]
                    )
                  }
                />
              ))}
            </div>
          </div>

          {targetPlayer && (
            <div>
              <div className="text-xs font-bold text-[var(--mut)] mb-2">
                3. Cartes souhaitées chez {targetPlayer.displayName} ({getCards.length})
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                {CARDS.filter((c) => (targetPlayer.inv?.[String(c.id)] || 0) > 0).map((c) => (
                  <CardVisual
                    key={c.id}
                    card={c}
                    compact
                    count={targetPlayer.inv[String(c.id)]}
                    selected={getCards.includes(c.id)}
                    onClick={() =>
                      setGetCards((prev) =>
                        prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id]
                      )
                    }
                  />
                ))}
              </div>
            </div>
          )}

          <button
            type="button"
            onClick={handleSendTrade}
            disabled={!targetPlayer || giveCards.length === 0 || getCards.length === 0}
            className="w-full py-3 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40"
          >
            Envoyer l’offre d’échange
          </button>
        </div>
      )}
    </div>
  );
};
