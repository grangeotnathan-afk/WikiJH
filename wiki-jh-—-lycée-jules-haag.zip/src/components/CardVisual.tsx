import React, { useState } from 'react';
import { Trash2 } from 'lucide-react';
import type { CardDef } from '../types/game';
import { DISCARD_COINS, RARITY_META } from '../data/gameData';

interface CardVisualProps {
  card: CardDef;
  count?: number;
  locked?: boolean;
  compact?: boolean;
  selected?: boolean;
  showStats?: boolean;
  hideIcon?: boolean;
  onClick?: () => void;
  className?: string;
}

export const CardVisual: React.FC<CardVisualProps> = ({
  card,
  count,
  locked = false,
  compact = false,
  selected = false,
  showStats = false,
  hideIcon = true,
  onClick,
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  const classes = [
    'jh-card text-left w-full select-none block',
    locked ? 'locked' : '',
    !locked && (card.r === 'UR' || card.r === 'L') ? 'sheen' : '',
    !locked && card.r === 'EX' ? 'ex' : '',
    selected ? 'ring-2 ring-[var(--acc)] ring-offset-2 ring-offset-[var(--bg)] scale-[1.02]' : '',
    onClick ? 'cursor-pointer' : '',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const content = (
    <>
      <div className="relative aspect-[1/0.92] overflow-hidden bg-slate-800 flex items-center justify-center">
        {!locked && !imgFailed ? (
          <img
            src={card.img}
            alt={card.name}
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="absolute inset-0 w-full h-full object-cover opacity-95"
          />
        ) : null}
        <div
          className="absolute inset-0"
          style={{
            background: locked
              ? 'linear-gradient(180deg, rgba(15,23,42,0.72), rgba(15,23,42,0.92))'
              : hideIcon
              ? 'linear-gradient(180deg, rgba(10,14,22,0.03) 50%, rgba(10,14,22,0.35) 100%)'
              : 'linear-gradient(180deg, rgba(10,14,22,0.06) 40%, rgba(10,14,22,0.62) 100%)',
          }}
        />
        {(locked || !hideIcon) && (
          <span
            className={`relative z-10 font-bold text-white drop-shadow-[0_4px_14px_rgba(0,0,0,0.65)] ${
              compact ? 'text-2xl' : 'text-4xl'
            }`}
          >
            {locked ? '?' : card.icon}
          </span>
        )}

        <span
          className="absolute top-2 left-2 z-20 px-1.5 py-0.5 rounded text-[11px] font-extrabold tracking-tight text-white shadow-sm"
          style={{ backgroundColor: RARITY_META[card.r].color }}
        >
          {card.r}
        </span>

        {typeof count === 'number' && count > 1 && !locked && (
          <span className="absolute top-2 right-2 z-20 px-1.5 py-0.5 rounded bg-slate-900/85 text-white font-mono-num text-[11px] font-bold">
            ×{count}
          </span>
        )}
      </div>

      <div className={compact ? 'p-2' : 'p-2.5 sm:p-3'}>
        <h4 className={`font-bold leading-tight truncate text-slate-950 ${compact ? 'text-xs' : 'text-sm'}`}>
          {locked ? 'Carte inconnue' : card.name}
        </h4>
        <div className="flex items-center gap-1.5 text-[11px] text-slate-800/85 mt-0.5 truncate">
          <span>{locked ? 'Non découverte' : card.sub}</span>
          {!locked && !compact && (
            <>
              <span aria-hidden="true">·</span>
              <span>{card.campus}</span>
            </>
          )}
        </div>

        {showStats && !locked && (
          <div className="mt-2 pt-1.5 border-t border-black/15 flex items-center justify-between text-[11px] font-mono-num font-bold text-slate-900">
            <span>ATQ {card.atk}</span>
            <span>DEF {card.def}</span>
            <span>VIT {card.spd}</span>
          </div>
        )}
      </div>
    </>
  );

  // Render a plain <div> when non-interactive so taps/clicks bubble cleanly to parent overlays
  if (!onClick) {
    return (
      <div data-r={card.r} className={classes}>
        {content}
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={onClick}
      data-r={card.r}
      className={classes}
    >
      {content}
    </button>
  );
};

interface CardDetailModalProps {
  card: CardDef | null;
  ownedCount: number;
  hideIcon?: boolean;
  onDiscard?: (card: CardDef) => void;
  onClose: () => void;
}

export const CardDetailModal: React.FC<CardDetailModalProps> = ({
  card,
  ownedCount,
  hideIcon = true,
  onDiscard,
  onClose,
}) => {
  const [tilt, setTilt] = useState({ rx: 0, ry: 0, px: 120 });

  if (!card) return null;

  const handleMove = (clientX: number, clientY: number, el: HTMLDivElement) => {
    const r = el.getBoundingClientRect();
    const x = (clientX - r.left) / r.width;
    const y = (clientY - r.top) / r.height;
    setTilt({
      ry: (x - 0.5) * 24,
      rx: (0.5 - y) * 24,
      px: 120 - x * 180,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm flex flex-col items-center gap-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="w-72"
          style={{ perspective: '900px' }}
          onMouseMove={(e) => handleMove(e.clientX, e.clientY, e.currentTarget)}
          onMouseLeave={() => setTilt({ rx: 0, ry: 0, px: 120 })}
        >
          <div
            data-r={card.r}
            className={`jh-card tilt w-full transition-transform duration-150 ease-out ${
              card.r === 'EX' ? 'ex' : ''
            }`}
            style={{
              transform: `rotateY(${tilt.ry}deg) rotateX(${tilt.rx}deg)`,
              ['--px' as string]: `${tilt.px}%`,
            }}
          >
            <div className="relative aspect-[1/0.95] overflow-hidden bg-slate-900 flex items-center justify-center">
              <img
                src={card.img}
                alt={card.name}
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover opacity-95"
              />
              <div
                className="absolute inset-0"
                style={{
                  background: hideIcon
                    ? 'linear-gradient(180deg, rgba(10,14,22,0.03) 50%, rgba(10,14,22,0.35) 100%)'
                    : 'linear-gradient(180deg, rgba(10,14,22,0.06) 40%, rgba(10,14,22,0.65) 100%)',
                }}
              />
              {!hideIcon && (
                <span className="relative z-10 text-7xl text-white drop-shadow-[0_6px_24px_rgba(0,0,0,0.7)]">
                  {card.icon}
                </span>
              )}
              <span
                className="absolute top-3 left-3 z-20 px-2 py-0.5 rounded text-xs font-extrabold text-white"
                style={{ backgroundColor: RARITY_META[card.r].color }}
              >
                {card.r}
              </span>
              {ownedCount > 0 && (
                <span className="absolute top-3 right-3 z-20 px-2 py-0.5 rounded bg-slate-900/85 text-white font-mono-num text-xs font-bold">
                  ×{ownedCount}
                </span>
              )}
            </div>
            <div className="p-4">
              <h3 className="font-display text-xl font-bold text-slate-950">
                {card.name}
              </h3>
              <p className="text-xs text-slate-800/85 mt-0.5">
                {card.sub} · Campus {card.campus}
              </p>
              <p className="text-xs text-slate-900/90 mt-2.5 leading-relaxed">
                {card.lore}
              </p>
              <div className="mt-3 pt-2.5 border-t border-black/15 grid grid-cols-3 gap-2 text-center font-mono-num text-xs font-bold text-slate-950">
                <div>
                  <span className="block text-[10px] opacity-65">ATQ</span>
                  {card.atk}
                </div>
                <div>
                  <span className="block text-[10px] opacity-65">DEF</span>
                  {card.def}
                </div>
                <div>
                  <span className="block text-[10px] opacity-65">VIT</span>
                  {card.spd}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2.5 w-full">
          {onDiscard && ownedCount > 0 && (
            <button
              type="button"
              onClick={() => onDiscard(card)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-xs sm:text-sm font-bold text-white shadow-md transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              Défausser (+{DISCARD_COINS} ●)
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-xs sm:text-sm font-semibold text-slate-900 shadow-md transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
