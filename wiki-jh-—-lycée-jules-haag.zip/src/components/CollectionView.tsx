import React, { useMemo, useState } from 'react';
import { Recycle, Search } from 'lucide-react';
import {
  CARDS,
  RARITY_META,
  RARITY_ORDER,
  computeCollectionScore,
  playSfx,
} from '../data/gameData';
import type { CardCampus, CardDef, PlayerProfile, Rarity } from '../types/game';
import { CardDetailModal, CardVisual } from './CardVisual';

interface CollectionViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onToast: (msg: string) => void;
}

export const CollectionView: React.FC<CollectionViewProps> = ({
  profile,
  onUpdateProfile,
  onToast,
}) => {
  const [search, setSearch] = useState('');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'ALL'>('ALL');
  const [campusFilter, setCampusFilter] = useState<CardCampus | 'ALL'>('ALL');
  const [showMissing, setShowMissing] = useState(true);
  const [inspectCard, setInspectCard] = useState<CardDef | null>(null);

  const inv = profile.inv || {};
  const ownedCount = CARDS.filter((c) => (inv[String(c.id)] || 0) > 0).length;
  const collectionScore = computeCollectionScore(inv);

  const duplicatesInfo = useMemo(() => {
    let extraCount = 0;
    let totalCoins = 0;
    for (const c of CARDS) {
      const qty = inv[String(c.id)] || 0;
      if (qty > 1) {
        const extra = qty - 1;
        extraCount += extra;
        totalCoins += extra * c.recycleCoins;
      }
    }
    return { extraCount, totalCoins };
  }, [inv]);

  const filteredCards = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...CARDS]
      .sort((a, b) => RARITY_ORDER.indexOf(a.r) - RARITY_ORDER.indexOf(b.r))
      .filter((c) => {
        const qty = inv[String(c.id)] || 0;
        if (!showMissing && qty <= 0) return false;
        if (rarityFilter !== 'ALL' && c.r !== rarityFilter) return false;
        if (campusFilter !== 'ALL' && c.campus !== campusFilter) return false;
        if (q && !`${c.name} ${c.sub} ${c.campus}`.toLowerCase().includes(q)) return false;
        return true;
      });
  }, [inv, search, rarityFilter, campusFilter, showMissing]);

  const handleRecycleAll = async () => {
    if (duplicatesInfo.extraCount <= 0) {
      onToast('Aucun doublon à recycler.');
      return;
    }
    const gained = duplicatesInfo.totalCoins;
    const recycled = duplicatesInfo.extraCount;
    await onUpdateProfile((prev) => {
      const nextInv = { ...(prev.inv || {}) };
      for (const c of CARDS) {
        const k = String(c.id);
        if ((nextInv[k] || 0) > 1) {
          nextInv[k] = 1;
        }
      }
      return {
        ...prev,
        inv: nextInv,
        coins: prev.coins + gained,
      };
    });
    playSfx('coin');
    onToast(`${recycled} doublon(s) recyclé(s) : +${gained} ●`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
            Collection Jules Haag
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1 font-mono-num">
            {ownedCount} / {CARDS.length} cartes découvertes · Score {collectionScore.toLocaleString('fr-FR')} pts
          </p>
        </div>

        <button
          type="button"
          onClick={handleRecycleAll}
          disabled={duplicatesInfo.extraCount <= 0}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] hover:border-[#e2bb6b]/45 text-xs font-bold text-white disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap shrink-0 font-mono-num"
        >
          <Recycle className="w-4 h-4 text-[#e2bb6b]" />
          Recycler {duplicatesInfo.extraCount} doublon{duplicatesInfo.extraCount > 1 ? 's' : ''} (+{duplicatesInfo.totalCoins} ●)
        </button>
      </div>

      {/* Filters Toolbar */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[var(--mut)] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher une carte ou un site…"
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-sm text-white placeholder:text-[var(--mut)] focus:outline-none focus:border-[#e2bb6b]/60"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center p-1 rounded-xl bg-[var(--surface)] border border-[var(--line)]">
            {(['ALL', 'Labbé', 'Marceau', 'Jules Haag'] as const).map((campus) => (
              <button
                key={campus}
                type="button"
                onClick={() => setCampusFilter(campus)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  campusFilter === campus
                    ? 'bg-white/10 text-white'
                    : 'text-[var(--mut)] hover:text-white'
                }`}
              >
                {campus === 'ALL' ? 'Tous sites' : campus}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setShowMissing((v) => !v)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap ${
              showMissing
                ? 'bg-white/10 border-white/20 text-white'
                : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
            }`}
          >
            {showMissing ? 'Inclure non découvertes' : 'Possédées uniquement'}
          </button>
        </div>
      </div>

      {/* Rarity Segmented Filter */}
      <div className="flex flex-wrap gap-1.5">
        <button
          type="button"
          onClick={() => setRarityFilter('ALL')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
            rarityFilter === 'ALL'
              ? 'bg-white/10 border-white/30 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-white'
          }`}
        >
          Toutes raretés
        </button>
        {RARITY_ORDER.map((r) => (
          <button
            key={r}
            type="button"
            onClick={() => setRarityFilter(r)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
              rarityFilter === r
                ? 'bg-white/10 border-white/35 text-white'
                : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-white'
            }`}
            style={
              rarityFilter === r
                ? { borderColor: RARITY_META[r].color, color: RARITY_META[r].color }
                : undefined
            }
          >
            {r}
          </button>
        ))}
      </div>

      {/* Card Grid */}
      {filteredCards.length === 0 ? (
        <div className="p-10 rounded-2xl border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
          Aucune carte ne correspond à vos filtres. Ouvrez un booster pour agrandir votre collection !
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {filteredCards.map((c) => {
            const qty = inv[String(c.id)] || 0;
            const locked = qty <= 0;
            return (
              <CardVisual
                key={c.id}
                card={c}
                count={qty}
                locked={locked}
                showStats={!locked}
                onClick={locked ? undefined : () => setInspectCard(c)}
              />
            );
          })}
        </div>
      )}

      <CardDetailModal
        card={inspectCard}
        ownedCount={inspectCard ? inv[String(inspectCard.id)] || 0 : 0}
        onClose={() => setInspectCard(null)}
      />
    </div>
  );
};
