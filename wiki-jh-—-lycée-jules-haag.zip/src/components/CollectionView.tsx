import React, { useMemo, useState } from 'react';
import { Search, Trash2 } from 'lucide-react';
import {
  CARDS,
  DISCARD_COINS,
  RARITY_META,
  RARITY_ORDER,
  computeCollectionScore,
  playSfx,
} from '../data/gameData';
import type { CardCampus, CardDef, PlayerProfile, Rarity } from '../types/game';
import { CardDetailModal, CardVisual } from './CardVisual';

interface CollectionViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onToast: (msg: string) => void;
}

export const CollectionView: React.FC<CollectionViewProps> = ({
  profile,
  onUpdateProfile,
  onToast,
}) => {
  const [search, setSearch] = useState('');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'ALL'>('ALL');
  const [campusFilter, setCampusFilter] = useState<CardCampus | 'ALL'>('ALL');
  const [discardMode, setDiscardMode] = useState(false);
  const [inspectCard, setInspectCard] = useState<CardDef | null>(null);

  const inv = profile.inv || {};
  const ownedCount = CARDS.filter((c) => (inv[String(c.id)] || 0) > 0).length;
  const collectionScore = computeCollectionScore(inv);

  const duplicatesCount = useMemo(() => {
    let extraCount = 0;
    for (const c of CARDS) {
      const qty = inv[String(c.id)] || 0;
      if (qty > 1) extraCount += qty - 1;
    }
    return extraCount;
  }, [inv]);

  // Only show discovered/owned cards (qty > 0)
  const filteredCards = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...CARDS]
      .sort((a, b) => RARITY_ORDER.indexOf(a.r) - RARITY_ORDER.indexOf(b.r))
      .filter((c) => {
        const qty = inv[String(c.id)] || 0;
        if (qty <= 0) return false;
        if (rarityFilter !== 'ALL' && c.r !== rarityFilter) return false;
        if (campusFilter !== 'ALL' && c.campus !== campusFilter) return false;
        if (q && !`${c.name} ${c.sub} ${c.campus}`.toLowerCase().includes(q)) return false;
        return true;
      });
  }, [inv, search, rarityFilter, campusFilter]);

  const handleDiscardSingle = async (card: CardDef) => {
    const k = String(card.id);
    const currentQty = inv[k] || 0;
    if (currentQty <= 0) {
      onToast('Vous ne possédez plus cette carte.');
      return;
    }
    await onUpdateProfile((prev) => {
      const nextInv = { ...(prev.inv || {}) };
      const q = nextInv[k] || 0;
      if (q <= 0) return prev;
      if (q === 1) {
        delete nextInv[k];
      } else {
        nextInv[k] = q - 1;
      }
      return {
        ...prev,
        inv: nextInv,
        coins: prev.coins + DISCARD_COINS,
      };
    });
    playSfx('coin');
    onToast(`Carte défaussée : ${card.name} (+${DISCARD_COINS} ●)`);
    if (currentQty <= 1 && inspectCard?.id === card.id) {
      setInspectCard(null);
    }
  };

  const handleDiscardAllDuplicates = async () => {
    if (duplicatesCount <= 0) {
      onToast('Aucun doublon à défausser.');
      return;
    }
    const gained = duplicatesCount * DISCARD_COINS;
    const count = duplicatesCount;
    await onUpdateProfile((prev) => {
      const nextInv = { ...(prev.inv || {}) };
      for (const c of CARDS) {
        const k = String(c.id);
        if ((nextInv[k] || 0) > 1) {
          nextInv[k] = 1;
        }
      }
      return {
        ...prev,
        inv: nextInv,
        coins: prev.coins + gained,
      };
    });
    playSfx('coin');
    onToast(`${count} doublon(s) défaussé(s) : +${gained} ●`);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-[var(--txt)]">
            Collection Jules Haag
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1 font-mono-num">
            {ownedCount} / {CARDS.length} cartes trouvées · Score {collectionScore.toLocaleString('fr-FR')} pts
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={() => setDiscardMode((v) => !v)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-bold transition-colors whitespace-nowrap ${
              discardMode
                ? 'bg-rose-600 border-rose-600 text-white shadow-sm'
                : 'bg-[var(--surface)] border-[var(--line)] text-[var(--txt)] hover:border-rose-300'
            }`}
          >
            <Trash2 className="w-4 h-4" />
            {discardMode ? 'Mode Défausse actif (+1 ● / clic)' : 'Défausser des cartes (+1 ●)'}
          </button>

          <button
            type="button"
            onClick={handleDiscardAllDuplicates}
            disabled={duplicatesCount <= 0}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] hover:border-[var(--acc)] text-xs font-bold text-[var(--txt)] disabled:opacity-40 disabled:pointer-events-none transition-colors whitespace-nowrap font-mono-num"
          >
            Défausser {duplicatesCount} doublon{duplicatesCount > 1 ? 's' : ''} (+{duplicatesCount * DISCARD_COINS} ●)
          </button>
        </div>
      </div>

      {discardMode && (
        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 text-xs sm:text-sm text-rose-900 dark:text-rose-200 flex items-center justify-between gap-3">
          <span>
            <strong>Mode Défausse actif :</strong> cliquez sur n’importe quelle carte possédée pour en défausser 1 exemplaire contre <strong>+{DISCARD_COINS} ●</strong>.
          </span>
          <button
            type="button"
            onClick={() => setDiscardMode(false)}
            className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold shrink-0"
          >
            Terminer
          </button>
        </div>
      )}

      {/* Filters Toolbar */}
      <div className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-[var(--mut)] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher une carte trouvée…"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)] placeholder:text-[var(--mut)] focus:outline-none focus:border-[var(--acc)]"
            />
          </div>

          <div className="flex items-center p-1 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] self-start md:self-auto">
            {(['ALL', 'Labbé', 'Marceau', 'Jules Haag'] as const).map((campus) => (
              <button
                key={campus}
                type="button"
                onClick={() => setCampusFilter(campus)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                  campusFilter === campus
                    ? 'bg-[var(--surface)] text-[var(--txt)] shadow-sm'
                    : 'text-[var(--mut)] hover:text-[var(--txt)]'
                }`}
              >
                {campus === 'ALL' ? 'Tous sites' : campus}
              </button>
            ))}
          </div>
        </div>

        {/* Rarity Segmented Filter */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          <button
            type="button"
            onClick={() => setRarityFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
              rarityFilter === 'ALL'
                ? 'bg-emerald-600 border-emerald-600 text-white'
                : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
            }`}
          >
            Toutes raretés
          </button>
          {RARITY_ORDER.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRarityFilter(r)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                rarityFilter === r
                  ? 'bg-[var(--surface)] shadow-sm'
                  : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
              }`}
              style={
                rarityFilter === r
                  ? { borderColor: RARITY_META[r].color, color: RARITY_META[r].color }
                  : undefined
              }
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Card Grid (Discovered Cards Only) */}
      {filteredCards.length === 0 ? (
        <div className="p-12 rounded-2xl bg-[var(--surface)] border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
          {ownedCount === 0
            ? 'Vous n’avez pas encore de carte dans votre collection. Ouvrez un paquet pour commencer !'
            : 'Aucune carte trouvée ne correspond à vos filtres actuels.'}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
          {filteredCards.map((c) => {
            const qty = inv[String(c.id)] || 0;
            return (
              <div key={c.id} className="relative">
                <CardVisual
                  card={c}
                  count={qty}
                  showStats
                  hideIcon
                  onClick={() => (discardMode ? handleDiscardSingle(c) : setInspectCard(c))}
                />
                {discardMode && (
                  <span className="pointer-events-none absolute bottom-2.5 right-2.5 z-20 px-2 py-0.5 rounded-md bg-rose-600 text-white text-[10px] font-bold shadow">
                    -1 carte · +1 ●
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}

      <CardDetailModal
        card={inspectCard}
        ownedCount={inspectCard ? inv[String(inspectCard.id)] || 0 : 0}
        hideIcon
        onDiscard={handleDiscardSingle}
        onClose={() => setInspectCard(null)}
      />
    </div>
  );
};
