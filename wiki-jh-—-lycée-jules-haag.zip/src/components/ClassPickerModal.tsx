import React, { useMemo, useState } from 'react';
import { GraduationCap, Search, X } from 'lucide-react';
import { CAMPUS_FILIERES } from '../data/gameData';
import type { Site } from '../types/game';

interface ClassPickerModalProps {
  isOpen: boolean;
  selectedClass: string;
  initialSiteFilter?: 'ALL' | Site;
  onSelect: (classe: string, site?: Site) => void;
  onClose: () => void;
}

export const ClassPickerModal: React.FC<ClassPickerModalProps> = ({
  isOpen,
  selectedClass,
  initialSiteFilter = 'ALL',
  onSelect,
  onClose,
}) => {
  const [siteTab, setSiteTab] = useState<'ALL' | Site>(initialSiteFilter);
  const [query, setQuery] = useState('');

  const filteredGroups = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CAMPUS_FILIERES.filter((g) => siteTab === 'ALL' || g.site === siteTab)
      .map((g) => ({
        ...g,
        classes: g.classes.filter(
          (c) =>
            !q ||
            c.toLowerCase().includes(q) ||
            g.trackLabel.toLowerCase().includes(q)
        ),
      }))
      .filter((g) => g.classes.length > 0);
  }, [siteTab, query]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[70] bg-slate-900/55 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[88vh] flex flex-col rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-5 border-b border-[var(--line)] flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <GraduationCap className="w-5 h-5 text-[var(--acc)]" />
            <div>
              <h2 className="font-display text-xl font-bold text-[var(--txt)]">
                Choisir votre classe & filière
              </h2>
              <p className="text-xs text-[var(--mut)]">
                Lycée Jules Haag · Besançon (Sites Labbé & Marceau)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer"
            className="w-9 h-9 rounded-full bg-[var(--surface-2)] hover:bg-slate-200 text-[var(--txt)] flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 border-b border-[var(--line)] bg-[var(--bg)] flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-[var(--mut)] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filtrer une classe ou filière (ex. STI2D, MELEC, BTS)…"
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-sm text-[var(--txt)] placeholder:text-[var(--mut)] focus:outline-none focus:border-[var(--acc)]"
            />
          </div>
          <div className="flex p-1 rounded-xl bg-[var(--surface)] border border-[var(--line)] self-start">
            {([
              ['ALL', 'Tous sites'],
              ['Labbé', 'Site Labbé'],
              ['Marceau', 'Site Marceau'],
            ] as const).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setSiteTab(key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors whitespace-nowrap ${
                  siteTab === key
                    ? 'bg-slate-900 text-white dark:bg-[#e2bb6b] dark:text-[#1d1405]'
                    : 'text-[var(--mut)] hover:text-[var(--txt)]'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="p-5 overflow-y-auto space-y-6">
          {filteredGroups.length === 0 ? (
            <p className="text-sm text-[var(--mut)] text-center py-8">
              Aucune classe ne correspond à votre recherche.
            </p>
          ) : (
            filteredGroups.map((group) => (
              <div key={group.trackLabel} className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[var(--mut)]">
                    {group.trackLabel}
                  </h3>
                  <span
                    className={`text-[11px] font-bold ${
                      group.site === 'Labbé' ? 'text-blue-600' : 'text-emerald-600'
                    }`}
                  >
                    {group.site}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {group.classes.map((cls) => {
                    const isSelected = selectedClass === cls;
                    const suggestSite =
                      group.trackLabel.includes('Équipe') ? undefined : group.site;
                    return (
                      <button
                        key={cls}
                        type="button"
                        onClick={() => {
                          onSelect(cls, suggestSite);
                          onClose();
                        }}
                        className={`px-3.5 py-2.5 rounded-xl border text-left text-sm font-semibold transition-all ${
                          isSelected
                            ? 'bg-amber-50 dark:bg-amber-950/50 border-[var(--acc)] text-amber-950 dark:text-amber-100 ring-1 ring-[var(--acc)]'
                            : 'bg-[var(--surface-2)]/60 border-[var(--line)] text-[var(--txt)] hover:bg-[var(--surface-2)]'
                        }`}
                      >
                        {cls}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
