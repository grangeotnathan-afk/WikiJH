import React, { useState } from 'react';
import { Award, Check, LogOut, Palette, Sparkles, Volume2, VolumeX } from 'lucide-react';
import {
  ACHIEVEMENTS,
  CARDS,
  COSMETICS,
  getCardById,
  getCosmetic,
  isSfxMuted,
  playSfx,
  setSfxMuted,
} from '../data/gameData';
import type { PlayerProfile, Site } from '../types/game';

interface ProfileViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onSignOut: () => void;
  onToast: (msg: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  onUpdateProfile,
  onSignOut,
  onToast,
}) => {
  const [subTab, setSubTab] = useState<'customize' | 'achievements' | 'shop'>('customize');
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [site, setSite] = useState<Site>(profile.site);
  const [classe, setClasse] = useState(profile.classe);
  const [bio, setBio] = useState(profile.bio);
  const [muted, setMuted] = useState(isSfxMuted());

  const unlocked = profile.unlockedCosmetics || [];
  const claimed = profile.claimedAchievements || [];

  const handleSaveIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = displayName.trim().slice(0, 32);
    if (!clean) {
      onToast('Le pseudo ne peut pas être vide.');
      return;
    }
    await onUpdateProfile((prev) => ({
      ...prev,
      displayName: clean,
      site,
      classe: classe.trim().slice(0, 32),
      bio: bio.trim().slice(0, 140),
    }));
    onToast('Profil mis à jour !');
  };

  const handleEquipCosmetic = async (id: string, type: 'avatar' | 'frame' | 'banner' | 'title') => {
    if (!unlocked.includes(id)) return;
    await onUpdateProfile((prev) => ({
      ...prev,
      avatarId: type === 'avatar' ? id : prev.avatarId,
      frameId: type === 'frame' ? id : prev.frameId,
      bannerId: type === 'banner' ? id : prev.bannerId,
      titleId: type === 'title' ? id : prev.titleId,
    }));
    onToast('Style équipé !');
  };

  const handleBuyCosmetic = async (id: string, price: number) => {
    if (unlocked.includes(id)) return;
    if (profile.coins < price) {
      onToast(`Il vous faut ${price} ● pour débloquer cet élément.`);
      return;
    }
    const item = getCosmetic(id);
    await onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins - price,
      unlockedCosmetics: [...(prev.unlockedCosmetics || []), id],
      avatarId: item?.type === 'avatar' ? id : prev.avatarId,
      frameId: item?.type === 'frame' ? id : prev.frameId,
      bannerId: item?.type === 'banner' ? id : prev.bannerId,
      titleId: item?.type === 'title' ? id : prev.titleId,
    }));
    playSfx('coin');
    onToast(`${item?.name} débloqué et équipé !`);
  };

  const handleClaimAchievement = async (achId: string, rewardCoins: number, rewardCosmeticId?: string) => {
    if (claimed.includes(achId)) return;
    await onUpdateProfile((prev) => {
      const nextCosmetics = [...(prev.unlockedCosmetics || [])];
      if (rewardCosmeticId && !nextCosmetics.includes(rewardCosmeticId)) {
        nextCosmetics.push(rewardCosmeticId);
      }
      return {
        ...prev,
        coins: prev.coins + rewardCoins,
        claimedAchievements: [...(prev.claimedAchievements || []), achId],
        unlockedCosmetics: nextCosmetics,
      };
    });
    playSfx('win');
    onToast(`Succès réclamé : +${rewardCoins} ● !`);
  };

  const toggleSound = () => {
    const next = !muted;
    setMuted(next);
    setSfxMuted(next);
    onToast(next ? 'Effets sonores coupés' : 'Effets sonores activés');
  };

  const claimableCount = ACHIEVEMENTS.filter(
    (a) => !claimed.includes(a.id) && a.progress(profile) >= a.target
  ).length;

  const ownedCards = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);

  return (
    <div className="space-y-6">
      {/* Live Banner Preview */}
      <section
        className={`p-6 rounded-2xl border border-[var(--line)] bg-gradient-to-br ${
          getCosmetic(profile.bannerId)?.previewClass || 'from-[#171d29] to-[#0f131b]'
        } flex flex-col sm:flex-row sm:items-center justify-between gap-5`}
      >
        <div className="flex items-center gap-4">
          <div
            className={`w-16 h-16 rounded-full bg-black/45 flex items-center justify-center text-3xl text-white shrink-0 ${
              getCosmetic(profile.frameId)?.previewClass || ''
            }`}
          >
            {getCosmetic(profile.avatarId)?.symbol || '◆'}
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-white">
              {profile.displayName}
            </h1>
            <p className="text-xs text-white/80">
              {profile.site} · {profile.classe || 'Lycée Jules Haag'}
            </p>
            <p className="text-xs font-bold text-[#e2bb6b] mt-1">
              {getCosmetic(profile.titleId)?.name}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={toggleSound}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-black/35 hover:bg-black/50 border border-white/10 text-xs font-semibold text-white"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            {muted ? 'Son coupé' : 'Son actif'}
          </button>
          <button
            type="button"
            onClick={onSignOut}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-black/35 hover:bg-rose-500/20 border border-white/10 text-xs font-semibold text-rose-300"
          >
            <LogOut className="w-4 h-4" />
            Déconnexion
          </button>
        </div>
      </section>

      {/* Sub-navigation */}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setSubTab('customize')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border ${
            subTab === 'customize'
              ? 'bg-[#e2bb6b] border-[#e2bb6b] text-[#1d1405]'
              : 'bg-[var(--surface)] border-[var(--line)] text-white'
          }`}
        >
          <Palette className="w-4 h-4" />
          Personnalisation
        </button>
        <button
          type="button"
          onClick={() => setSubTab('achievements')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border ${
            subTab === 'achievements'
              ? 'bg-[#e2bb6b] border-[#e2bb6b] text-[#1d1405]'
              : 'bg-[var(--surface)] border-[var(--line)] text-white'
          }`}
        >
          <Award className="w-4 h-4" />
          Succès ({claimed.length}/{ACHIEVEMENTS.length})
          {claimableCount > 0 && (
            <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-slate-950 font-mono-num text-[10px]">
              +{claimableCount}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={() => setSubTab('shop')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border ${
            subTab === 'shop'
              ? 'bg-[#e2bb6b] border-[#e2bb6b] text-[#1d1405]'
              : 'bg-[var(--surface)] border-[var(--line)] text-white'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Boutique Cosmétique
        </button>
      </div>

      {/* CUSTOMIZATION TAB */}
      {subTab === 'customize' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSaveIdentity}
            className="lg:col-span-5 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-4"
          >
            <h2 className="font-display text-lg font-bold text-white">Identité du Lycée</h2>

            <div>
              <label className="block text-xs text-[var(--mut)] mb-1">Pseudo</label>
              <input
                type="text"
                maxLength={32}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-[var(--mut)] mb-1">Site de rattachement</label>
              <div className="grid grid-cols-2 gap-2.5">
                {(['Labbé', 'Marceau'] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSite(s)}
                    className={`py-2.5 rounded-xl border text-xs font-bold transition-colors ${
                      site === s
                        ? s === 'Labbé'
                          ? 'bg-blue-500/20 border-blue-400 text-white'
                          : 'bg-emerald-500/20 border-emerald-400 text-white'
                        : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)]'
                    }`}
                  >
                    Site {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-[var(--mut)] mb-1">Classe / Filière</label>
              <input
                type="text"
                maxLength={32}
                value={classe}
                onChange={(e) => setClasse(e.target.value)}
                placeholder="Ex. Terminale STI2D, BTS Microtechnique…"
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-[var(--mut)] mb-1">Devise / Bio</label>
              <textarea
                rows={2}
                maxLength={140}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f]"
            >
              Enregistrer l’identité
            </button>
          </form>

          <div className="lg:col-span-7 p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-5">
            <h2 className="font-display text-lg font-bold text-white">
              Cosmétiques & Carte Favorite
            </h2>

            {(['avatar', 'frame', 'banner', 'title'] as const).map((type) => {
              const label =
                type === 'avatar'
                  ? 'Emblème'
                  : type === 'frame'
                  ? 'Cadre'
                  : type === 'banner'
                  ? 'Bannière'
                  : 'Titre';
              const items = COSMETICS.filter((c) => c.type === type && unlocked.includes(c.id));
              const activeId =
                type === 'avatar'
                  ? profile.avatarId
                  : type === 'frame'
                  ? profile.frameId
                  : type === 'banner'
                  ? profile.bannerId
                  : profile.titleId;

              return (
                <div key={type} className="space-y-2">
                  <div className="text-xs font-bold text-[var(--mut)]">{label}</div>
                  <div className="flex flex-wrap gap-2">
                    {items.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleEquipCosmetic(item.id, type)}
                        className={`px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors ${
                          activeId === item.id
                            ? 'bg-[#e2bb6b]/15 border-[#e2bb6b] text-white'
                            : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)] hover:text-white'
                        }`}
                      >
                        {item.symbol ? `${item.symbol} ` : ''}
                        {item.name}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}

            <div className="space-y-2 pt-2 border-t border-[var(--line)]">
              <div className="text-xs font-bold text-[var(--mut)]">
                Carte exposée sur votre fiche publique
              </div>
              <select
                value={profile.showcaseCardId}
                onChange={async (e) => {
                  const id = Number(e.target.value);
                  await onUpdateProfile((prev) => ({ ...prev, showcaseCardId: id }));
                  onToast(`Carte exposée : ${getCardById(id)?.name}`);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
              >
                {ownedCards.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.icon} {c.name} ({c.r})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* ACHIEVEMENTS TAB */}
      {subTab === 'achievements' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ACHIEVEMENTS.map((ach) => {
            const current = Math.min(ach.target, ach.progress(profile));
            const isClaimed = claimed.includes(ach.id);
            const canClaim = !isClaimed && current >= ach.target;
            const rewardCosmetic = ach.rewardCosmeticId ? getCosmetic(ach.rewardCosmeticId) : null;

            return (
              <div
                key={ach.id}
                className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex flex-col justify-between gap-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-xs text-[var(--mut)]">{ach.category}</div>
                    <h3 className="font-bold text-white text-base mt-0.5">{ach.title}</h3>
                    <p className="text-xs text-[var(--mut)] mt-1">{ach.description}</p>
                  </div>
                  <div className="text-right shrink-0 font-mono-num">
                    <div className="text-sm font-extrabold text-[#e2bb6b]">
                      +{ach.rewardCoins} ●
                    </div>
                    {rewardCosmetic && (
                      <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">
                        + {rewardCosmetic.name}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-mono-num text-[var(--mut)]">
                    <span>Progression</span>
                    <span>
                      {current} / {ach.target}
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <div
                      className="h-full bg-[#e2bb6b] transition-all duration-300"
                      style={{ width: `${Math.min(100, (current / ach.target) * 100)}%` }}
                    />
                  </div>
                </div>

                {isClaimed ? (
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                    <Check className="w-4 h-4" />
                    Récompense récupérée
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={!canClaim}
                    onClick={() =>
                      handleClaimAchievement(ach.id, ach.rewardCoins, ach.rewardCosmeticId)
                    }
                    className="w-full py-2 rounded-xl text-xs font-bold bg-[#e2bb6b] text-[#1d1405] disabled:bg-white/5 disabled:text-[var(--mut)] transition-colors"
                  >
                    {canClaim ? 'Réclamer la récompense' : 'En cours'}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* COSMETIC SHOP TAB */}
      {subTab === 'shop' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {COSMETICS.filter((c) => c.price > 0).map((item) => {
            const isOwned = unlocked.includes(item.id);
            return (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-[var(--mut)] capitalize">{item.type}</span>
                    {item.symbol && <span className="text-xl">{item.symbol}</span>}
                  </div>
                  <h3 className="font-bold text-white text-base mt-1">{item.name}</h3>
                  <p className="text-xs text-[var(--mut)] mt-1">{item.description}</p>
                </div>

                {isOwned ? (
                  <button
                    type="button"
                    onClick={() => handleEquipCosmetic(item.id, item.type)}
                    className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white"
                  >
                    Débloqué · Équiper
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={profile.coins < item.price}
                    onClick={() => handleBuyCosmetic(item.id, item.price)}
                    className="w-full py-2.5 rounded-xl bg-[#e2bb6b] text-[#1d1405] text-xs font-bold font-mono-num disabled:opacity-40"
                  >
                    Débloquer · {item.price} ●
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
