import React, { useEffect, useState } from 'react';
import {
  Award,
  Check,
  ChevronDown,
  LogOut,
  Moon,
  Palette,
  Settings,
  Sparkles,
  Sun,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {
  ACHIEVEMENTS,
  CARDS,
  COSMETICS,
  getCardById,
  getCosmetic,
  isSfxMuted,
  playSfx,
  setSfxMuted,
} from '../data/gameData';
import type { PlayerProfile, Site } from '../types/game';
import { ClassPickerModal } from './ClassPickerModal';

export type AppTheme = 'light' | 'dark';
export type ProfileSubTab = 'customize' | 'achievements' | 'shop' | 'settings';

interface ProfileViewProps {
  profile: PlayerProfile;
  theme: AppTheme;
  initialSubTab?: ProfileSubTab;
  subTabSignal?: number;
  onChangeTheme: (next: AppTheme) => void;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onSignOut: () => void;
  onToast: (msg: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  theme,
  initialSubTab = 'customize',
  subTabSignal = 0,
  onChangeTheme,
  onUpdateProfile,
  onSignOut,
  onToast,
}) => {
  const [subTab, setSubTab] = useState<ProfileSubTab>(initialSubTab);
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [site, setSite] = useState<Site>(profile.site);
  const [classe, setClasse] = useState(profile.classe);
  const [bio, setBio] = useState(profile.bio);
  const [muted, setMuted] = useState(isSfxMuted());
  const [classPickerOpen, setClassPickerOpen] = useState(false);

  useEffect(() => {
    setSubTab(initialSubTab);
  }, [initialSubTab, subTabSignal]);

  const unlocked = profile.unlockedCosmetics || [];
  const claimed = profile.claimedAchievements || [];

  const handleSaveIdentity = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = displayName.trim().slice(0, 32);
    if (!clean) {
      onToast('Le pseudo ne peut pas être vide.');
      return;
    }
    if (!classe.trim()) {
      onToast('Veuillez choisir votre classe / filière.');
      setClassPickerOpen(true);
      return;
    }
    await onUpdateProfile((prev) => ({
      ...prev,
      displayName: clean,
      site,
      classe: classe.trim().slice(0, 32),
      bio: bio.trim().slice(0, 140),
    }));
    onToast('Profil mis à jour !');
  };

  const handleEquipCosmetic = async (id: string, type: 'avatar' | 'frame' | 'banner' | 'title') => {
    if (!unlocked.includes(id)) return;
    await onUpdateProfile((prev) => ({
      ...prev,
      avatarId: type === 'avatar' ? id : prev.avatarId,
      frameId: type === 'frame' ? id : prev.frameId,
      bannerId: type === 'banner' ? id : prev.bannerId,
      titleId: type === 'title' ? id : prev.titleId,
    }));
    onToast('Style équipé !');
  };

  const handleBuyCosmetic = async (id: string, price: number) => {
    if (unlocked.includes(id)) return;
    if (profile.coins < price) {
      onToast(`Il vous faut ${price} ● pour débloquer cet élément.`);
      return;
    }
    const item = getCosmetic(id);
    await onUpdateProfile((prev) => ({
      ...prev,
      coins: prev.coins - price,
      unlockedCosmetics: [...(prev.unlockedCosmetics || []), id],
      avatarId: item?.type === 'avatar' ? id : prev.avatarId,
      frameId: item?.type === 'frame' ? id : prev.frameId,
      bannerId: item?.type === 'banner' ? id : prev.bannerId,
      titleId: item?.type === 'title' ? id : prev.titleId,
    }));
    playSfx('coin');
    onToast(`${item?.name} débloqué et équipé !`);
  };

  const handleClaimAchievement = async (
    achId: string,
    rewardCoins: number,
    rewardCosmeticId?: string
  ) => {
    if (claimed.includes(achId)) return;
    await onUpdateProfile((prev) => {
      const nextCosmetics = [...(prev.unlockedCosmetics || [])];
      if (rewardCosmeticId && !nextCosmetics.includes(rewardCosmeticId)) {
        nextCosmetics.push(rewardCosmeticId);
      }
      return {
        ...prev,
        coins: prev.coins + rewardCoins,
        claimedAchievements: [...(prev.claimedAchievements || []), achId],
        unlockedCosmetics: nextCosmetics,
      };
    });
    playSfx('win');
    onToast(`Succès réclamé : +${rewardCoins} ● !`);
  };

  const toggleSound = () => {
    const next = !muted;
    setMuted(next);
    setSfxMuted(next);
    onToast(next ? 'Effets sonores coupés' : 'Effets sonores activés');
  };

  const claimableCount = ACHIEVEMENTS.filter(
    (a) => !claimed.includes(a.id) && a.progress(profile) >= a.target
  ).length;

  const ownedCards = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Live Banner Preview */}
      <section
        className={`p-6 rounded-2xl border border-[var(--line)] shadow-sm bg-gradient-to-br ${
          getCosmetic(profile.bannerId)?.previewClass || 'from-slate-800 to-slate-900'
        } flex flex-col sm:flex-row sm:items-center justify-between gap-5`}
      >
        <div className="flex items-center gap-4">
          <div
            className={`w-16 h-16 rounded-full bg-black/45 flex items-center justify-center text-3xl text-white shrink-0 ${
              getCosmetic(profile.frameId)?.previewClass || ''
            }`}
          >
            {getCosmetic(profile.avatarId)?.symbol || '◆'}
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-white">
              {profile.displayName}
            </h1>
            <p className="text-xs text-white/85">
              {profile.site} · {profile.classe || 'Lycée Jules Haag'}
            </p>
            <p className="text-xs font-bold text-[#f6dfaa] mt-1">
              {getCosmetic(profile.titleId)?.name}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={toggleSound}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/20 text-xs font-semibold text-white"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            {muted ? 'Son coupé' : 'Son actif'}
          </button>
          <button
            type="button"
            onClick={onSignOut}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/35 border border-rose-300/30 text-xs font-semibold text-rose-100"
          >
            <LogOut className="w-4 h-4" />
            Déconnexion
          </button>
        </div>
      </section>

      {/* Sub-navigation */}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setSubTab('customize')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border shadow-sm transition-colors ${
            subTab === 'customize'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          <Palette className="w-4 h-4" />
          Personnalisation
        </button>
        <button
          type="button"
          onClick={() => setSubTab('achievements')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border shadow-sm transition-colors ${
            subTab === 'achievements'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          <Award className="w-4 h-4" />
          Succès ({claimed.length}/{ACHIEVEMENTS.length})
          {claimableCount > 0 && (
            <span className="px-1.5 py-0.5 rounded bg-emerald-500 text-white font-mono-num text-[10px]">
              +{claimableCount}
            </span>
          )}
        </button>
        <button
          type="button"
          onClick={() => setSubTab('shop')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border shadow-sm transition-colors ${
            subTab === 'shop'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Boutique
        </button>
        <button
          type="button"
          onClick={() => setSubTab('settings')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border shadow-sm transition-colors ${
            subTab === 'settings'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          <Settings className="w-4 h-4" />
          Paramètres
        </button>
      </div>

      {/* Theme Quick Switcher (shown on Profil & Paramètres) */}
      {(subTab === 'settings' || subTab === 'customize') && (
        <section className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-bold text-[var(--txt)]">
              Apparence de l’application
            </h2>
            <p className="text-xs text-[var(--mut)] mt-0.5">
              Choisissez entre le thème clair ou le thème sombre selon votre préférence
            </p>
          </div>

          <div className="inline-flex p-1 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] self-start sm:self-auto">
            <button
              type="button"
              onClick={() => {
                onChangeTheme('light');
                onToast('Thème clair activé');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                theme === 'light'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-[var(--mut)] hover:text-[var(--txt)]'
              }`}
            >
              <Sun className="w-4 h-4 text-amber-500" />
              Thème Clair
            </button>
            <button
              type="button"
              onClick={() => {
                onChangeTheme('dark');
                onToast('Thème sombre activé');
              }}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                theme === 'dark'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-[var(--mut)] hover:text-[var(--txt)]'
              }`}
            >
              <Moon className="w-4 h-4" />
              Thème Sombre
            </button>
          </div>
        </section>
      )}

      {/* CUSTOMIZATION TAB */}
      {subTab === 'customize' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <form
            onSubmit={handleSaveIdentity}
            className="lg:col-span-5 p-6 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-4"
          >
            <h2 className="font-display text-lg font-bold text-[var(--txt)]">Identité du Lycée</h2>

            <div>
              <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Pseudo</label>
              <input
                type="text"
                maxLength={32}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[var(--mut)] mb-1">
                Site de rattachement
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                {(['Labbé', 'Marceau'] as const).map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSite(s)}
                    className={`py-2.5 rounded-xl border text-xs font-bold transition-colors ${
                      site === s
                        ? s === 'Labbé'
                          ? 'bg-blue-50 border-blue-500 text-blue-900 dark:bg-blue-950/60 dark:text-blue-200'
                          : 'bg-emerald-50 border-emerald-500 text-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-200'
                        : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)]'
                    }`}
                  >
                    Site {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[var(--mut)] mb-1">
                Classe / Filière
              </label>
              <button
                type="button"
                onClick={() => setClassPickerOpen(true)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] hover:border-[var(--acc)] text-sm text-left flex items-center justify-between transition-colors"
              >
                <span className={classe ? 'font-semibold text-[var(--txt)]' : 'text-[var(--mut)]'}>
                  {classe || 'Sélectionner une filière et une classe…'}
                </span>
                <ChevronDown className="w-4 h-4 text-[var(--mut)] shrink-0" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[var(--mut)] mb-1">Devise / Bio</label>
              <textarea
                rows={2}
                maxLength={140}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)] resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#d99b26] to-[#f4d47c] hover:brightness-105 transition-all"
            >
              Enregistrer l’identité
            </button>
          </form>

          <div className="lg:col-span-7 p-6 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm space-y-5">
            <h2 className="font-display text-lg font-bold text-[var(--txt)]">
              Cosmétiques & Carte Favorite
            </h2>

            {(['avatar', 'frame', 'banner', 'title'] as const).map((type) => {
              const label =
                type === 'avatar'
                  ? 'Emblème'
                  : type === 'frame'
                  ? 'Cadre'
                  : type === 'banner'
                  ? 'Bannière'
                  : 'Titre';
              const items = COSMETICS.filter((c) => c.type === type && unlocked.includes(c.id));
              const activeId =
                type === 'avatar'
                  ? profile.avatarId
                  : type === 'frame'
                  ? profile.frameId
                  : type === 'banner'
                  ? profile.bannerId
                  : profile.titleId;

              return (
                <div key={type} className="space-y-2">
                  <div className="text-xs font-bold text-[var(--mut)]">{label}</div>
                  <div className="flex flex-wrap gap-2">
                    {items.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleEquipCosmetic(item.id, type)}
                        className={`px-3.5 py-2 rounded-xl border text-xs font-semibold transition-colors ${
                          activeId === item.id
                            ? 'bg-amber-50 dark:bg-amber-950/50 border-[var(--acc)] text-[var(--txt)] font-bold'
                            : 'bg-[var(--surface-2)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
                        }`}
                      >
                        {item.symbol ? `${item.symbol} ` : ''}
                        {item.name}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}

            <div className="space-y-2 pt-3 border-t border-[var(--line)]">
              <div className="text-xs font-bold text-[var(--mut)]">
                Carte exposée sur votre fiche publique
              </div>
              <select
                value={profile.showcaseCardId}
                onChange={async (e) => {
                  const id = Number(e.target.value);
                  await onUpdateProfile((prev) => ({ ...prev, showcaseCardId: id }));
                  onToast(`Carte exposée : ${getCardById(id)?.name}`);
                }}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)]"
              >
                {ownedCards.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.icon} {c.name} ({c.r})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* ACHIEVEMENTS TAB */}
      {subTab === 'achievements' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ACHIEVEMENTS.map((ach) => {
            const current = Math.min(ach.target, ach.progress(profile));
            const isClaimed = claimed.includes(ach.id);
            const canClaim = !isClaimed && current >= ach.target;
            const rewardCosmetic = ach.rewardCosmeticId ? getCosmetic(ach.rewardCosmeticId) : null;

            return (
              <div
                key={ach.id}
                className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col justify-between gap-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-xs font-semibold text-[var(--mut)]">{ach.category}</div>
                    <h3 className="font-bold text-[var(--txt)] text-base mt-0.5">{ach.title}</h3>
                    <p className="text-xs text-[var(--mut)] mt-1">{ach.description}</p>
                  </div>
                  <div className="text-right shrink-0 font-mono-num">
                    <div className="text-sm font-extrabold text-[var(--acc)]">
                      +{ach.rewardCoins} ●
                    </div>
                    {rewardCosmetic && (
                      <div className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold mt-0.5">
                        + {rewardCosmetic.name}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-mono-num text-[var(--mut)]">
                    <span>Progression</span>
                    <span>
                      {current} / {ach.target}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-[var(--surface-2)] overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#d99b26] to-[#f4d47c] transition-all duration-300"
                      style={{ width: `${Math.min(100, (current / ach.target) * 100)}%` }}
                    />
                  </div>
                </div>

                {isClaimed ? (
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400">
                    <Check className="w-4 h-4" />
                    Récompense récupérée
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={!canClaim}
                    onClick={() =>
                      handleClaimAchievement(ach.id, ach.rewardCoins, ach.rewardCosmeticId)
                    }
                    className="w-full py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-[#d99b26] to-[#f4d47c] text-[#1d1405] disabled:bg-[var(--surface-2)] disabled:from-transparent disabled:to-transparent disabled:text-[var(--mut)] transition-colors"
                  >
                    {canClaim ? 'Réclamer la récompense' : 'En cours'}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* COSMETIC SHOP TAB */}
      {subTab === 'shop' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {COSMETICS.filter((c) => c.price > 0).map((item) => {
            const isOwned = unlocked.includes(item.id);
            return (
              <div
                key={item.id}
                className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-[var(--mut)] capitalize">
                      {item.type}
                    </span>
                    {item.symbol && <span className="text-xl">{item.symbol}</span>}
                  </div>
                  <h3 className="font-bold text-[var(--txt)] text-base mt-1">{item.name}</h3>
                  <p className="text-xs text-[var(--mut)] mt-1">{item.description}</p>
                </div>

                {isOwned ? (
                  <button
                    type="button"
                    onClick={() => handleEquipCosmetic(item.id, item.type)}
                    className="w-full py-2.5 rounded-xl bg-[var(--surface-2)] hover:opacity-90 border border-[var(--line)] text-xs font-bold text-[var(--txt)]"
                  >
                    Débloqué · Équiper
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled={profile.coins < item.price}
                    onClick={() => handleBuyCosmetic(item.id, item.price)}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#d99b26] to-[#f4d47c] text-[#1d1405] text-xs font-bold font-mono-num disabled:opacity-40"
                  >
                    Débloquer · {item.price} ●
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* SETTINGS TAB */}
      {subTab === 'settings' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-[var(--txt)]">Effets sonores</h3>
              <p className="text-xs text-[var(--mut)] mt-0.5">
                Sons d’ouverture de paquets, pièces et duels
              </p>
            </div>
            <button
              type="button"
              onClick={toggleSound}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-xs font-bold text-[var(--txt)] shrink-0"
            >
              {muted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4 text-emerald-500" />}
              {muted ? 'Son coupé' : 'Son actif'}
            </button>
          </div>

          <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-[var(--txt)]">Session Google</h3>
              <p className="text-xs text-[var(--mut)] mt-0.5">
                Connecté en tant que {profile.displayName}
              </p>
            </div>
            <button
              type="button"
              onClick={onSignOut}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800/60 text-xs font-bold text-rose-700 dark:text-rose-300 shrink-0"
            >
              <LogOut className="w-4 h-4" />
              Déconnexion
            </button>
          </div>
        </div>
      )}

      <ClassPickerModal
        isOpen={classPickerOpen}
        initialSiteFilter={site}
        selectedClass={classe}
        onSelect={(cls, suggestedSite) => {
          setClasse(cls);
          if (suggestedSite) setSite(suggestedSite);
          setClassPickerOpen(false);
        }}
        onClose={() => setClassPickerOpen(false)}
      />
    </div>
  );
};
