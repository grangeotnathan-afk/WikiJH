import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  where,
} from 'firebase/firestore';
import { Clock, Gavel, Plus, Tag } from 'lucide-react';
import {
  CARDS,
  MAX_MARKET_SLOTS,
  RARITY_ORDER,
  getCardById,
  playSfx,
} from '../data/gameData';
import { db, handleFirestoreError, sanitizePlayerUpdate } from '../firebase/client';
import {
  OperationType,
  type BidRefund,
  type MarketListing,
  type PlayerProfile,
  type Rarity,
} from '../types/game';
import { CardVisual } from './CardVisual';

interface MarketViewProps {
  profile: PlayerProfile;
  onToast: (msg: string) => void;
}

function formatRemaining(ms: number): string {
  if (ms <= 0) return 'Terminée';
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`;
  return `${m}m ${String(s).padStart(2, '0')}s`;
}

export const MarketView: React.FC<MarketViewProps> = ({ profile, onToast }) => {
  const [marketTab, setMarketTab] = useState<'browse' | 'mine'>('browse');
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'ALL'>('ALL');
  const [listings, setListings] = useState<MarketListing[]>([]);
  const [myListings, setMyListings] = useState<MarketListing[]>([]);
  const [myBidListings, setMyBidListings] = useState<MarketListing[]>([]);
  const [bidInputs, setBidInputs] = useState<Record<string, string>>({});
  const [now, setNow] = useState(Date.now());

  const [sellOpen, setSellOpen] = useState(false);
  const [sellCardId, setSellCardId] = useState<number | null>(null);
  const [sellPrice, setSellPrice] = useState('');
  const [sellDurationMin, setSellDurationMin] = useState(30);

  const claimedListingsRef = useRef<Set<string>>(new Set());
  const claimedWinsRef = useRef<Set<string>>(new Set());
  const claimedRefundsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const qActive = query(collection(db, 'listings'), where('status', '==', 'active'));
    const unsubActive = onSnapshot(
      qActive,
      (snap) => {
        const items = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<MarketListing, 'id'>),
        }));
        items.sort((a, b) => a.endsAt - b.endsAt);
        setListings(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'listings')
    );

    const qMine = query(collection(db, 'listings'), where('sellerId', '==', profile.uid));
    const unsubMine = onSnapshot(
      qMine,
      (snap) => {
        setMyListings(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<MarketListing, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'listings')
    );

    const qLeading = query(collection(db, 'listings'), where('bidderId', '==', profile.uid));
    const unsubLeading = onSnapshot(
      qLeading,
      (snap) => {
        setMyBidListings(
          snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<MarketListing, 'id'>) }))
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'listings')
    );

    return () => {
      unsubActive();
      unsubMine();
      unsubLeading();
    };
  }, [profile.uid]);

  // Auto-refund coins when outbid
  useEffect(() => {
    const qRefunds = query(
      collection(db, 'bidRefunds'),
      where('userId', '==', profile.uid)
    );
    const unsubRefunds = onSnapshot(
      qRefunds,
      (snap) => {
        snap.docs.forEach(async (d) => {
          const r = { id: d.id, ...(d.data() as Omit<BidRefund, 'id'>) };
          if (r.claimed || claimedRefundsRef.current.has(r.id)) return;
          claimedRefundsRef.current.add(r.id);
          try {
            await runTransaction(db, async (tx) => {
              const rRef = doc(db, 'bidRefunds', r.id);
              const pRef = doc(db, 'players', profile.uid);
              const rSnap = await tx.get(rRef);
              const pSnap = await tx.get(pRef);
              if (!rSnap.exists() || !pSnap.exists()) return;
              const rd = rSnap.data() as BidRefund;
              const pd = pSnap.data() as PlayerProfile;
              if (rd.claimed) return;
              tx.update(pRef, sanitizePlayerUpdate({ ...pd, coins: pd.coins + rd.amount }));
              tx.update(rRef, { claimed: true, updatedAt: serverTimestamp() });
            });
            playSfx('coin');
            onToast(
              `Surenchéri sur ${getCardById(r.cardId)?.name || 'une carte'} : +${r.amount} ● remboursés`
            );
          } catch (err) {
            console.error(err);
          }
        });
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'bidRefunds')
    );

    return () => unsubRefunds();
  }, [profile.uid, onToast]);

  // Auto-claim sold auction proceeds for seller
  useEffect(() => {
    const claimable = myListings.filter(
      (l) =>
        !l.sellerClaimed &&
        !claimedListingsRef.current.has(l.id) &&
        ((l.status === 'sold' && l.bidderId) ||
          (l.status === 'active' && l.endsAt <= now && Boolean(l.bidderId)))
    );

    claimable.forEach(async (l) => {
      claimedListingsRef.current.add(l.id);
      try {
        await runTransaction(db, async (tx) => {
          const lRef = doc(db, 'listings', l.id);
          const pRef = doc(db, 'players', profile.uid);
          const lSnap = await tx.get(lRef);
          const pSnap = await tx.get(pRef);
          if (!lSnap.exists() || !pSnap.exists()) return;
          const ld = lSnap.data() as MarketListing;
          const pd = pSnap.data() as PlayerProfile;
          if (ld.sellerClaimed || !ld.bidderId) return;
          const finalAmount = ld.currentBid > 0 ? ld.currentBid : ld.price;
          tx.update(
            pRef,
            sanitizePlayerUpdate({
              ...pd,
              coins: pd.coins + finalAmount,
              marketSales: (pd.marketSales || 0) + 1,
            })
          );
          tx.update(lRef, {
            status: 'sold',
            buyerId: ld.bidderId,
            buyerName: ld.bidderName,
            sellerClaimed: true,
            updatedAt: serverTimestamp(),
          });
        });
        playSfx('coin');
        onToast(
          `Enchère remportée par ${l.bidderName} : +${l.currentBid || l.price} ● encaissés !`
        );
      } catch (err) {
        console.error(err);
      }
    });
  }, [myListings, now, profile.uid, onToast]);

  // Auto-claim won auction cards for winning bidder
  useEffect(() => {
    const wonReady = myBidListings.filter(
      (l) =>
        l.bidderId === profile.uid &&
        !l.winnerClaimed &&
        l.endsAt <= now &&
        l.status !== 'cancelled' &&
        !claimedWinsRef.current.has(l.id)
    );

    wonReady.forEach(async (l) => {
      claimedWinsRef.current.add(l.id);
      try {
        await runTransaction(db, async (tx) => {
          const lRef = doc(db, 'listings', l.id);
          const pRef = doc(db, 'players', profile.uid);
          const lSnap = await tx.get(lRef);
          const pSnap = await tx.get(pRef);
          if (!lSnap.exists() || !pSnap.exists()) return;
          const ld = lSnap.data() as MarketListing;
          const pd = pSnap.data() as PlayerProfile;
          if (ld.winnerClaimed || ld.bidderId !== profile.uid || ld.endsAt > Date.now()) {
            return;
          }
          const nextInv = { ...(pd.inv || {}) };
          nextInv[String(ld.cardId)] = (nextInv[String(ld.cardId)] || 0) + 1;
          tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
          tx.update(lRef, {
            status: 'sold',
            buyerId: ld.bidderId,
            buyerName: ld.bidderName,
            winnerClaimed: true,
            updatedAt: serverTimestamp(),
          });
        });
        playSfx('win');
        onToast(`Enchère gagnée : ${getCardById(l.cardId)?.name} ajoutée à votre collection !`);
      } catch (err) {
        console.error(err);
      }
    });
  }, [myBidListings, now, profile.uid, onToast]);

  const activeMyListings = myListings.filter((l) => l.status === 'active');

  const browseListings = useMemo(() => {
    return listings.filter((l) => {
      if (l.endsAt <= now) return false;
      if (l.sellerId === profile.uid) return false;
      if (rarityFilter !== 'ALL') {
        const c = getCardById(l.cardId);
        if (!c || c.r !== rarityFilter) return false;
      }
      return true;
    });
  }, [listings, now, profile.uid, rarityFilter]);

  const handlePlaceBid = async (l: MarketListing) => {
    const minBid = l.bidderId ? l.currentBid + 1 : l.price;
    const raw = bidInputs[l.id];
    const bidAmount = raw ? Math.floor(Number(raw)) : minBid;
    if (!(bidAmount >= minBid)) {
      onToast(`L’enchère minimum est de ${minBid} ●.`);
      return;
    }

    const alreadyLeading = l.bidderId === profile.uid;
    const additionalCost = alreadyLeading ? bidAmount - l.currentBid : bidAmount;
    if (profile.coins < additionalCost) {
      onToast(`Pièces insuffisantes (il vous faut ${additionalCost} ● disponibles).`);
      return;
    }

    try {
      await runTransaction(db, async (tx) => {
        const lRef = doc(db, 'listings', l.id);
        const pRef = doc(db, 'players', profile.uid);
        const lSnap = await tx.get(lRef);
        const pSnap = await tx.get(pRef);
        if (!lSnap.exists() || !pSnap.exists()) throw new Error('Enchère introuvable');

        const ld = lSnap.data() as MarketListing;
        const pd = pSnap.data() as PlayerProfile;

        if (ld.status !== 'active' || ld.endsAt <= Date.now()) {
          throw new Error('Cette enchère est terminée');
        }
        if (ld.sellerId === profile.uid) {
          throw new Error('Vous ne pouvez pas enchérir sur votre propre carte');
        }
        const neededMin = ld.bidderId ? ld.currentBid + 1 : ld.price;
        if (bidAmount < neededMin) {
          throw new Error(`Enchère dépassée ! Nouveau minimum : ${neededMin} ●`);
        }

        const isSameLeader = ld.bidderId === profile.uid;
        const deltaCoins = isSameLeader ? bidAmount - ld.currentBid : bidAmount;
        if (pd.coins < deltaCoins) {
          throw new Error('Pièces ● insuffisantes');
        }

        tx.update(pRef, sanitizePlayerUpdate({ ...pd, coins: pd.coins - deltaCoins }));

        if (ld.bidderId && ld.bidderId !== profile.uid) {
          const refundId = `${l.id}_${ld.bidCount}`;
          tx.set(doc(db, 'bidRefunds', refundId), {
            listingId: l.id,
            userId: ld.bidderId,
            cardId: ld.cardId,
            amount: ld.currentBid,
            claimed: false,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        tx.update(lRef, {
          currentBid: bidAmount,
          bidderId: profile.uid,
          bidderName: profile.displayName,
          bidderSite: profile.site,
          bidCount: (ld.bidCount || 0) + 1,
          updatedAt: serverTimestamp(),
        });
      });

      playSfx('coin');
      setBidInputs((prev) => ({ ...prev, [l.id]: '' }));
      onToast(`Vous menez l’enchère à ${bidAmount} ● !`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Enchère impossible');
    }
  };

  const handleCreateListing = async () => {
    const price = Math.floor(Number(sellPrice));
    if (!sellCardId) {
      onToast('Sélectionnez une carte à mettre aux enchères.');
      return;
    }
    if (!(price >= 1)) {
      onToast('Entrez un prix de départ valide (minimum 1 ●).');
      return;
    }
    if (activeMyListings.length >= MAX_MARKET_SLOTS) {
      onToast(`Maximum ${MAX_MARKET_SLOTS} ventes actives simultanées.`);
      return;
    }
    try {
      await runTransaction(db, async (tx) => {
        const pRef = doc(db, 'players', profile.uid);
        const pSnap = await tx.get(pRef);
        if (!pSnap.exists()) throw new Error('Profil introuvable');
        const pd = pSnap.data() as PlayerProfile;
        const k = String(sellCardId);
        if ((pd.inv[k] || 0) < 1) throw new Error('Carte non disponible');
        const nextInv = { ...pd.inv, [k]: pd.inv[k] - 1 };

        const lRef = doc(collection(db, 'listings'));
        tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
        tx.set(lRef, {
          sellerId: profile.uid,
          sellerName: profile.displayName,
          sellerSite: profile.site,
          cardId: sellCardId,
          price,
          currentBid: 0,
          bidderId: '',
          bidderName: '',
          bidderSite: '',
          bidCount: 0,
          endsAt: Date.now() + sellDurationMin * 60 * 1000,
          status: 'active',
          buyerId: '',
          buyerName: '',
          sellerClaimed: false,
          winnerClaimed: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
      setSellOpen(false);
      setSellCardId(null);
      setSellPrice('');
      playSfx('pack');
      onToast('Carte mise aux enchères !');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Erreur lors de la mise aux enchères');
    }
  };

  const handleCancelListing = async (l: MarketListing) => {
    if (l.bidderId) {
      onToast('Impossible de retirer une enchère qui a déjà reçu une offre.');
      return;
    }
    try {
      await runTransaction(db, async (tx) => {
        const lRef = doc(db, 'listings', l.id);
        const pRef = doc(db, 'players', profile.uid);
        const lSnap = await tx.get(lRef);
        const pSnap = await tx.get(pRef);
        if (!lSnap.exists() || !pSnap.exists()) return;
        const ld = lSnap.data() as MarketListing;
        const pd = pSnap.data() as PlayerProfile;
        if (ld.status !== 'active' || ld.bidderId) return;
        const k = String(ld.cardId);
        const nextInv = { ...pd.inv, [k]: (pd.inv[k] || 0) + 1 };
        tx.update(pRef, sanitizePlayerUpdate({ ...pd, inv: nextInv }));
        tx.update(lRef, { status: 'cancelled', updatedAt: serverTimestamp() });
      });
      onToast('Enchère annulée et carte restituée.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `listings/${l.id}`);
    }
  };

  const ownedSellable = CARDS.filter((c) => (profile.inv[String(c.id)] || 0) > 0);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-[var(--txt)] flex items-center gap-2.5">
            <Gavel className="w-7 h-7 text-emerald-500" />
            Marché des Enchères
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1">
            Enchérissez en direct sur les cartes des sites Labbé et Marceau et suivez qui mène vos ventes
          </p>
        </div>

        <button
          type="button"
          disabled={activeMyListings.length >= MAX_MARKET_SLOTS || ownedSellable.length === 0}
          onClick={() => setSellOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-white bg-emerald-600 hover:bg-emerald-500 shadow-sm disabled:opacity-40 whitespace-nowrap self-start"
        >
          <Plus className="w-4 h-4" />
          Mettre aux enchères
        </button>
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setMarketTab('browse')}
          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
            marketTab === 'browse'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          Enchères en cours ({browseListings.length})
        </button>
        <button
          type="button"
          onClick={() => setMarketTab('mine')}
          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
            marketTab === 'mine'
              ? 'bg-emerald-600 border-emerald-600 text-white'
              : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-[var(--txt)]'
          }`}
        >
          Mes ventes ({activeMyListings.length} / {MAX_MARKET_SLOTS})
        </button>
      </div>

      {marketTab === 'browse' && (
        <div className="space-y-5">
          <div className="flex flex-wrap gap-1.5">
            {(['ALL', ...RARITY_ORDER] as const).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRarityFilter(r)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border ${
                  rarityFilter === r
                    ? 'bg-emerald-600 border-emerald-600 text-white'
                    : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
                }`}
              >
                {r === 'ALL' ? 'Toutes' : r}
              </button>
            ))}
          </div>

          {browseListings.length === 0 ? (
            <div className="p-12 rounded-2xl bg-[var(--surface)] border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
              Aucune enchère en cours pour le moment. Mettez une carte aux enchères pour démarrer !
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {browseListings.map((l) => {
                const c = getCardById(l.cardId);
                if (!c) return null;
                const hasBid = Boolean(l.bidderId);
                const minNext = hasBid ? l.currentBid + 1 : l.price;
                const isLeading = l.bidderId === profile.uid;
                const timeText = formatRemaining(l.endsAt - now);

                return (
                  <div
                    key={l.id}
                    className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col gap-3"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-20 shrink-0">
                        <CardVisual card={c} compact />
                      </div>
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center justify-between gap-2">
                          <div className="font-bold text-[var(--txt)] text-base truncate">
                            {c.name}
                          </div>
                          <span className="inline-flex items-center gap-1 text-xs font-mono-num font-semibold text-[var(--mut)] shrink-0">
                            <Clock className="w-3.5 h-3.5 text-emerald-500" />
                            {timeText}
                          </span>
                        </div>

                        <div className="text-xs text-[var(--mut)]">
                          Vendeur : {l.sellerName} · {l.sellerSite}
                        </div>

                        <div className="pt-1 flex items-baseline gap-2">
                          <span className="font-mono-num text-lg font-extrabold text-[var(--acc)]">
                            {(hasBid ? l.currentBid : l.price).toLocaleString('fr-FR')} ●
                          </span>
                          <span className="text-xs text-[var(--mut)]">
                            {hasBid
                              ? `Enchère actuelle (${l.bidCount} offre${l.bidCount > 1 ? 's' : ''})`
                              : 'Prix de départ'}
                          </span>
                        </div>

                        <div
                          className={`text-xs font-semibold ${
                            isLeading
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : hasBid
                              ? 'text-blue-700 dark:text-blue-400'
                              : 'text-[var(--mut)]'
                          }`}
                        >
                          {isLeading
                            ? `Vous menez cette enchère à ${l.currentBid} ●`
                            : hasBid
                            ? `Menée par ${l.bidderName} (${l.bidderSite}) à ${l.currentBid} ●`
                            : 'Aucune enchère placée pour l’instant'}
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-[var(--line)] flex items-center gap-2">
                      <input
                        type="number"
                        min={minNext}
                        value={bidInputs[l.id] ?? ''}
                        onChange={(e) =>
                          setBidInputs((prev) => ({ ...prev, [l.id]: e.target.value }))
                        }
                        placeholder={`Min ${minNext} ●`}
                        className="w-32 px-3 py-2 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-xs font-mono-num font-bold text-[var(--txt)]"
                      />
                      <button
                        type="button"
                        onClick={() => handlePlaceBid(l)}
                        className="flex-1 py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all whitespace-nowrap"
                      >
                        {isLeading
                          ? 'Surenchérir'
                          : `Enchérir (${bidInputs[l.id] || minNext} ●)`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {marketTab === 'mine' && (
        <div className="space-y-3">
          {activeMyListings.length === 0 ? (
            <div className="p-12 rounded-2xl bg-[var(--surface)] border border-dashed border-[var(--line)] text-center text-sm text-[var(--mut)]">
              Vous n’avez aucune vente aux enchères en cours.
            </div>
          ) : (
            activeMyListings.map((l) => {
              const c = getCardById(l.cardId);
              if (!c) return null;
              const hasBid = Boolean(l.bidderId);
              const ended = l.endsAt <= now;
              return (
                <div
                  key={l.id}
                  className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-16 shrink-0">
                      <CardVisual card={c} compact />
                    </div>
                    <div className="min-w-0 space-y-1">
                      <div className="font-bold text-[var(--txt)] text-base truncate">
                        {c.name}
                      </div>
                      <div className="text-xs text-[var(--mut)] font-mono-num">
                        Départ : {l.price} ● · Temps restant :{' '}
                        <strong className="text-[var(--txt)]">
                          {formatRemaining(l.endsAt - now)}
                        </strong>
                      </div>
                      {hasBid ? (
                        <div className="text-sm font-bold text-emerald-700 dark:text-emerald-400">
                          En tête : {l.bidderName} ({l.bidderSite}) mène à{' '}
                          <span className="font-mono-num">{l.currentBid} ●</span> ({l.bidCount} enchère{l.bidCount > 1 ? 's' : ''})
                        </div>
                      ) : (
                        <div className="text-xs font-semibold text-[var(--mut)]">
                          En attente du premier enchérisseur
                        </div>
                      )}
                    </div>
                  </div>

                  {!hasBid && (
                    <button
                      type="button"
                      onClick={() => handleCancelListing(l)}
                      className="px-4 py-2 rounded-xl border border-rose-300 text-rose-700 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold shrink-0"
                    >
                      {ended ? 'Récupérer la carte' : 'Retirer'}
                    </button>
                  )}
                  {hasBid && ended && (
                    <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 shrink-0">
                      Encaissement en cours…
                    </span>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Auction Sell Sheet Modal */}
      {sellOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/55 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSellOpen(false)}
        >
          <div
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-bold text-[var(--txt)] flex items-center gap-2">
                <Tag className="w-5 h-5 text-emerald-500" />
                Mettre une carte aux enchères
              </h2>
              <button
                type="button"
                onClick={() => setSellOpen(false)}
                className="w-8 h-8 rounded-full bg-[var(--surface-2)] text-[var(--txt)] text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
              {ownedSellable.map((c) => (
                <CardVisual
                  key={c.id}
                  card={c}
                  compact
                  count={profile.inv[String(c.id)]}
                  selected={sellCardId === c.id}
                  onClick={() => {
                    setSellCardId(c.id);
                    setSellPrice(String(c.suggestedPrice));
                  }}
                />
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">
                  Prix de départ (●)
                </label>
                <input
                  type="number"
                  min={1}
                  value={sellPrice}
                  onChange={(e) => setSellPrice(e.target.value)}
                  placeholder="Ex. 120"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)] font-mono-num"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[var(--mut)] mb-1">
                  Durée de l’enchère
                </label>
                <select
                  value={sellDurationMin}
                  onChange={(e) => setSellDurationMin(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)]"
                >
                  <option value={30}>30 minutes</option>
                  <option value={60}>1 heure</option>
                  <option value={360}>6 heures</option>
                  <option value={720}>12 heures</option>
                  <option value={1440}>24 heures</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleCreateListing}
              className="w-full py-3 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500"
            >
              Lancer la vente aux enchères
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
