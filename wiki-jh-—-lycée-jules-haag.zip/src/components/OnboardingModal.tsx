import React, { useState } from 'react';
import { LABBE_IMG, MARCEAU_IMG } from '../data/gameData';
import type { Site } from '../types/game';

interface OnboardingModalProps {
  defaultName: string;
  defaultSite: Site;
  onComplete: (data: { displayName: string; site: Site; classe: string }) => Promise<void>;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  defaultName,
  defaultSite,
  onComplete,
}) => {
  const [displayName, setDisplayName] = useState(defaultName);
  const [site, setSite] = useState<Site>(defaultSite);
  const [classe, setClasse] = useState('Terminale');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || saving) return;
    setSaving(true);
    try {
      await onComplete({
        displayName: displayName.trim().slice(0, 32),
        site,
        classe: classe.trim().slice(0, 32),
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-lg rounded-2xl bg-[var(--surface)] border border-[var(--line)] p-6 space-y-5"
      >
        <div>
          <h2 className="font-display text-2xl font-bold text-white">
            Bienvenue sur Wiki JH
          </h2>
          <p className="text-sm text-[var(--mut)] mt-1">
            Choisissez votre campus de rattachement pour défendre ses couleurs dans l’Arène et le Classement.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {([
            { id: 'Labbé' as const, img: LABBE_IMG, desc: 'Lycée Général & Technologique · Rue Labbé' },
            { id: 'Marceau' as const, img: MARCEAU_IMG, desc: 'Lycée Professionnel · Rue Marceau' },
          ]).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSite(item.id)}
              className={`rounded-xl overflow-hidden border text-left transition-all ${
                site === item.id
                  ? 'border-[#e2bb6b] ring-2 ring-[#e2bb6b]/40'
                  : 'border-[var(--line)] opacity-75 hover:opacity-100'
              }`}
            >
              <div className="h-24 relative bg-slate-900">
                <img
                  src={item.img}
                  alt={`Site ${item.id}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
                <span className="absolute bottom-2 left-2.5 font-display text-base font-bold text-white">
                  Site {item.id}
                </span>
              </div>
              <div className="p-2.5 bg-[var(--surface-2)] text-[11px] text-[var(--mut)]">
                {item.desc}
              </div>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-[var(--mut)] mb-1">Pseudo joueur</label>
            <input
              type="text"
              required
              maxLength={32}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-[var(--mut)] mb-1">Classe / Filière</label>
            <input
              type="text"
              maxLength={32}
              value={classe}
              onChange={(e) => setClasse(e.target.value)}
              placeholder="Ex. Terminale, BTS…"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-white"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] disabled:opacity-50"
        >
          {saving ? 'Création du profil…' : 'Commencer avec 10 boosters & 150 ●'}
        </button>
      </form>
    </div>
  );
};
