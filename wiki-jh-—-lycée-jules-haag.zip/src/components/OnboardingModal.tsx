import React, { useState } from 'react';
import { ChevronDown, GraduationCap } from 'lucide-react';
import { LABBE_IMG, MARCEAU_IMG } from '../data/gameData';
import type { Site } from '../types/game';
import { ClassPickerModal } from './ClassPickerModal';

interface OnboardingModalProps {
  defaultName: string;
  defaultSite: Site;
  onComplete: (data: { displayName: string; site: Site; classe: string }) => Promise<void>;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  defaultName,
  defaultSite,
  onComplete,
}) => {
  const [displayName, setDisplayName] = useState(defaultName);
  const [site, setSite] = useState<Site>(defaultSite);
  const [classe, setClasse] = useState(
    defaultSite === 'Marceau' ? 'Term. Pro Microtechniques' : 'Terminale Générale'
  );
  const [pickerOpen, setPickerOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || !classe.trim() || saving) return;
    setSaving(true);
    try {
      await onComplete({
        displayName: displayName.trim().slice(0, 32),
        site,
        classe: classe.trim().slice(0, 32),
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/55 backdrop-blur-md flex items-center justify-center p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-lg rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl p-6 space-y-5"
      >
        <div>
          <h2 className="font-display text-2xl font-bold text-[var(--txt)]">
            Bienvenue sur Wiki JH
          </h2>
          <p className="text-sm text-[var(--mut)] mt-1">
            Choisissez votre campus, votre filière et votre classe pour représenter vos couleurs.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {([
            { id: 'Labbé' as const, img: LABBE_IMG, desc: 'Lycée Général & Technologique · Rue Labbé' },
            { id: 'Marceau' as const, img: MARCEAU_IMG, desc: 'Lycée Professionnel · Rue Marceau' },
          ]).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSite(item.id)}
              className={`rounded-xl overflow-hidden border text-left transition-all ${
                site === item.id
                  ? 'border-[var(--acc)] ring-2 ring-amber-400/50'
                  : 'border-[var(--line)] opacity-80 hover:opacity-100'
              }`}
            >
              <div className="h-24 relative bg-slate-200">
                <img
                  src={item.img}
                  alt={`Site ${item.id}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent" />
                <span className="absolute bottom-2 left-2.5 font-display text-base font-bold text-white">
                  Site {item.id}
                </span>
              </div>
              <div className="p-2.5 bg-[var(--surface-2)] text-[11px] text-[var(--mut)] font-medium">
                {item.desc}
              </div>
            </button>
          ))}
        </div>

        <div className="space-y-3">
          <div>
            <label className="block text-xs font-semibold text-[var(--mut)] mb-1">
              Pseudo joueur
            </label>
            <input
              type="text"
              required
              maxLength={32}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] text-sm text-[var(--txt)] focus:outline-none focus:border-[var(--acc)]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[var(--mut)] mb-1">
              Classe & Filière
            </label>
            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] hover:border-[var(--acc)] text-sm text-[var(--txt)] flex items-center justify-between gap-2 transition-colors"
            >
              <span className="inline-flex items-center gap-2 font-semibold truncate">
                <GraduationCap className="w-4 h-4 text-[var(--acc)] shrink-0" />
                <span className="truncate">{classe || 'Sélectionner ma classe et filière…'}</span>
              </span>
              <span className="inline-flex items-center gap-1 text-xs font-bold text-[var(--acc)] shrink-0">
                Choisir
                <ChevronDown className="w-4 h-4" />
              </span>
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#d99b26] to-[#f4d47c] hover:brightness-105 disabled:opacity-50 transition-all"
        >
          {saving ? 'Création du profil…' : 'Commencer avec 10 boosters · 0 ●'}
        </button>
      </form>

      <ClassPickerModal
        isOpen={pickerOpen}
        selectedClass={classe}
        initialSiteFilter="ALL"
        onSelect={(pickedClass, suggestedSite) => {
          setClasse(pickedClass);
          if (suggestedSite) setSite(suggestedSite);
        }}
        onClose={() => setPickerOpen(false)}
      />
    </div>
  );
};
