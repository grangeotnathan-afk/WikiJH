import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Bot,
  Flag,
  Loader2,
  Plus,
  Shield,
  Swords,
  Users,
  Zap,
} from 'lucide-react';
import {
  CARDS,
  RARITY_META,
  RARITY_ORDER,
  STANCE_LABELS,
  computeEloDelta,
  getCardById,
  getCosmetic,
  playSfx,
  resolveBattleRound,
} from '../data/gameData';
import { db, handleFirestoreError, sanitizePlayerUpdate } from '../firebase/client';
import {
  OperationType,
  type BattleDoc,
  type BattleQueueEntry,
  type CardDef,
  type PlayerProfile,
  type RoundSummary,
  type Site,
  type Stance,
} from '../types/game';
import { CardVisual } from './CardVisual';

interface ArenaViewProps {
  profile: PlayerProfile;
  onUpdateProfile: (updater: (prev: PlayerProfile) => PlayerProfile) => Promise<void>;
  onToast: (msg: string) => void;
}

export const ArenaView: React.FC<ArenaViewProps> = ({
  profile,
  onUpdateProfile,
  onToast,
}) => {
  const inv = profile.inv || {};
  const ownedCards = useMemo(
    () =>
      [...CARDS]
        .filter((c) => (inv[String(c.id)] || 0) > 0)
        .sort((a, b) => b.atk + b.def + b.spd - (a.atk + a.def + a.spd)),
    [inv]
  );

  // 3-card deck selection
  const [deck, setDeck] = useState<number[]>(() =>
    ownedCards.slice(0, 3).map((c) => c.id)
  );

  useEffect(() => {
    setDeck((prev) => {
      const valid = prev.filter((id) => (inv[String(id)] || 0) > 0);
      if (valid.length === 3) return valid;
      const fill = [...valid];
      for (const c of ownedCards) {
        if (fill.length >= 3) break;
        if (!fill.includes(c.id)) fill.push(c.id);
      }
      return fill;
    });
  }, [ownedCards, inv]);

  // Real-time queue, open challenges, and active PvP battle
  const [queueEntry, setQueueEntry] = useState<BattleQueueEntry | null>(null);
  const [waitingQueue, setWaitingQueue] = useState<BattleQueueEntry[]>([]);
  const [openBattles, setOpenBattles] = useState<BattleDoc[]>([]);
  const [activeBattle, setActiveBattle] = useState<BattleDoc | null>(null);
  const [selectedCard, setSelectedCard] = useState<number | null>(null);
  const [selectedStance, setSelectedStance] = useState<Exclude<Stance, 'none'>>('assault');
  const [submittingMove, setSubmittingMove] = useState(false);
  const [turnRemaining, setTurnRemaining] = useState(25);
  const claimingBattleRef = useRef<Set<string>>(new Set());

  // Solo Training Bot Battle state (explicitly labeled Solo Practice)
  const [botBattle, setBotBattle] = useState<{
    botName: string;
    botSite: Site;
    botDeck: number[];
    round: number;
    pScore: number;
    bScore: number;
    usedPlayer: number[];
    usedBot: number[];
    history: RoundSummary[];
    finished: boolean;
  } | null>(null);

  // Listen to open battles + player's active battles
  useEffect(() => {
    const qOpen = query(collection(db, 'battles'), where('status', '==', 'open'));
    const unsubOpen = onSnapshot(
      qOpen,
      (snap) => {
        const list: BattleDoc[] = [];
        snap.forEach((d) => list.push({ id: d.id, ...(d.data() as Omit<BattleDoc, 'id'>) }));
        setOpenBattles(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'battles')
    );

    const qP1 = query(collection(db, 'battles'), where('p1Id', '==', profile.uid));
    const qP2 = query(collection(db, 'battles'), where('p2Id', '==', profile.uid));

    let p1List: BattleDoc[] = [];
    let p2List: BattleDoc[] = [];

    const syncMyBattle = () => {
      const merged = [...p1List, ...p2List];
      const current =
        merged.find((b) => b.status === 'active') ||
        merged.find((b) => b.status === 'open') ||
        merged.find(
          (b) =>
            b.status === 'finished' &&
            ((b.p1Id === profile.uid && !b.p1Claimed) ||
              (b.p2Id === profile.uid && !b.p2Claimed))
        ) ||
        null;
      setActiveBattle(current);
    };

    const unsubP1 = onSnapshot(
      qP1,
      (snap) => {
        p1List = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<BattleDoc, 'id'>) }));
        syncMyBattle();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'battles')
    );

    const unsubP2 = onSnapshot(
      qP2,
      (snap) => {
        p2List = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<BattleDoc, 'id'>) }));
        syncMyBattle();
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'battles')
    );

    return () => {
      unsubOpen();
      unsubP1();
      unsubP2();
    };
  }, [profile.uid]);

  // Listen to matchmaking queue
  useEffect(() => {
    const qWait = query(collection(db, 'battleQueue'), where('status', '==', 'waiting'));
    const unsubWait = onSnapshot(
      qWait,
      (snap) => {
        const list: BattleQueueEntry[] = [];
        snap.forEach((d) => list.push(d.data() as BattleQueueEntry));
        setWaitingQueue(list.filter((w) => w.uid !== profile.uid));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'battleQueue')
    );

    const unsubSelf = onSnapshot(
      doc(db, 'battleQueue', profile.uid),
      async (snap) => {
        if (!snap.exists()) {
          setQueueEntry(null);
          return;
        }
        const entry = snap.data() as BattleQueueEntry;
        setQueueEntry(entry);
        if (entry.status === 'matched' && entry.battleId) {
          try {
            await deleteDoc(doc(db, 'battleQueue', profile.uid));
          } catch {
            // Best effort cleanup
          }
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `battleQueue/${profile.uid}`)
    );

    return () => {
      unsubWait();
      unsubSelf();
    };
  }, [profile.uid]);

  // Turn countdown & auto-resolve when both moves submitted
  useEffect(() => {
    if (!activeBattle || activeBattle.status !== 'active') return;
    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - activeBattle.turnStartedAt) / 1000);
      setTurnRemaining(Math.max(0, 25 - elapsed));
    }, 500);

    const bothMoved =
      activeBattle.p1Move?.stance !== 'none' && activeBattle.p2Move?.stance !== 'none';

    if (bothMoved) {
      const resolveRound = async () => {
        const bRef = doc(db, 'battles', activeBattle.id);
        try {
          await runTransaction(db, async (tx) => {
            const snap = await tx.get(bRef);
            if (!snap.exists()) return;
            const b = snap.data() as Omit<BattleDoc, 'id'>;
            if (b.status !== 'active') return;
            if (b.p1Move.stance === 'none' || b.p2Move.stance === 'none') return;

            const summary = resolveBattleRound(
              b.round,
              b.p1Move,
              b.p2Move,
              b.p1Site,
              (b.p2Site || 'Marceau') as Site
            );
            const nextP1Score = b.p1Score + (summary.winner === 'p1' ? 1 : 0);
            const nextP2Score = b.p2Score + (summary.winner === 'p2' ? 1 : 0);
            const nextHistory = [...(b.roundHistory || []), summary];

            const matchDone =
              nextP1Score >= 2 || nextP2Score >= 2 || b.round >= 3;

            let winnerId = '';
            if (matchDone) {
              if (nextP1Score > nextP2Score) winnerId = b.p1Id;
              else if (nextP2Score > nextP1Score) winnerId = b.p2Id;
              else {
                const p1Total = nextHistory.reduce((s, r) => s + r.p1Power, 0);
                const p2Total = nextHistory.reduce((s, r) => s + r.p2Power, 0);
                winnerId = p1Total >= p2Total ? b.p1Id : b.p2Id;
              }
            }

            tx.update(bRef, {
              round: matchDone ? b.round : b.round + 1,
              p1Score: nextP1Score,
              p2Score: nextP2Score,
              p1Move: { cardId: 0, stance: 'none' },
              p2Move: { cardId: 0, stance: 'none' },
              roundHistory: nextHistory,
              status: matchDone ? 'finished' : 'active',
              winnerId,
              turnStartedAt: Date.now(),
              updatedAt: serverTimestamp(),
            });
          });
          playSfx('hit');
          setSelectedCard(null);
        } catch (err) {
          console.error('Round resolution race handled safely:', err);
        }
      };
      resolveRound();
    }

    return () => clearInterval(interval);
  }, [activeBattle]);

  // Auto-claim finished PvP battle rewards
  useEffect(() => {
    if (!activeBattle || activeBattle.status !== 'finished') return;
    const isP1 = activeBattle.p1Id === profile.uid;
    const alreadyClaimed = isP1 ? activeBattle.p1Claimed : activeBattle.p2Claimed;
    if (alreadyClaimed || claimingBattleRef.current.has(activeBattle.id)) return;

    claimingBattleRef.current.add(activeBattle.id);
    const claimRewards = async () => {
      try {
        const won = activeBattle.winnerId === profile.uid;
        const oppElo = isP1 ? activeBattle.p2Elo : activeBattle.p1Elo;
        const { winDelta, lossDelta } = computeEloDelta(
          won ? profile.elo : oppElo,
          won ? oppElo : profile.elo
        );
        const eloChange =
          activeBattle.mode === 'ranked' ? (won ? winDelta : -lossDelta) : 0;
        const coinReward = won ? 65 : 20;

        await runTransaction(db, async (tx) => {
          const bRef = doc(db, 'battles', activeBattle.id);
          const pRef = doc(db, 'players', profile.uid);
          const bSnap = await tx.get(bRef);
          const pSnap = await tx.get(pRef);
          if (!bSnap.exists() || !pSnap.exists()) return;
          const bData = bSnap.data() as BattleDoc;
          const pData = pSnap.data() as PlayerProfile;
          if ((isP1 && bData.p1Claimed) || (!isP1 && bData.p2Claimed)) return;

          const nextStreak = won ? (pData.streak || 0) + 1 : 0;
          const updatedPlayer: PlayerProfile = {
            ...pData,
            coins: (pData.coins || 0) + coinReward,
            elo: Math.max(100, (pData.elo || 1000) + eloChange),
            wins: (pData.wins || 0) + (won ? 1 : 0),
            losses: (pData.losses || 0) + (won ? 0 : 1),
            streak: nextStreak,
            bestStreak: Math.max(pData.bestStreak || 0, nextStreak),
          };
          tx.update(pRef, sanitizePlayerUpdate(updatedPlayer));
          tx.update(bRef, {
            [isP1 ? 'p1Claimed' : 'p2Claimed']: true,
            updatedAt: serverTimestamp(),
          });
        });

        playSfx(won ? 'win' : 'hit');
        onToast(
          won
            ? `Victoire ! +${coinReward} ●${eloChange ? ` · +${eloChange} ELO` : ''}`
            : `Défaite · +${coinReward} ●${eloChange ? ` · ${eloChange} ELO` : ''}`
        );
      } catch (err) {
        console.error(err);
      }
    };
    claimRewards();
  }, [activeBattle, profile.uid, profile.elo, onToast]);

  const toggleDeckCard = (cardId: number) => {
    setDeck((prev) => {
      if (prev.includes(cardId)) return prev.filter((id) => id !== cardId);
      if (prev.length >= 3) return [...prev.slice(1), cardId];
      return [...prev, cardId];
    });
  };

  const handleFindRankedMatch = async () => {
    if (deck.length !== 3) {
      onToast('Sélectionnez exactement 3 cartes dans votre deck.');
      return;
    }

    // Check if an opponent is waiting in queue
    const opponent = waitingQueue.find((w) => w.uid !== profile.uid);
    if (opponent) {
      try {
        const battleRef = doc(collection(db, 'battles'));
        await runTransaction(db, async (tx) => {
          const qRef = doc(db, 'battleQueue', opponent.uid);
          const qSnap = await tx.get(qRef);
          if (!qSnap.exists()) throw new Error('Adversaire déjà parti');
          const qData = qSnap.data() as BattleQueueEntry;
          if (qData.status !== 'waiting') throw new Error('Adversaire déjà apparié');

          tx.set(battleRef, {
            p1Id: qData.uid,
            p1Name: qData.displayName,
            p1Site: qData.site,
            p1Elo: qData.elo,
            p1Avatar: qData.avatarId,
            p1Frame: qData.frameId,
            p1Deck: qData.deck,
            p2Id: profile.uid,
            p2Name: profile.displayName,
            p2Site: profile.site,
            p2Elo: profile.elo,
            p2Avatar: profile.avatarId,
            p2Frame: profile.frameId,
            p2Deck: deck,
            mode: 'ranked',
            status: 'active',
            round: 1,
            p1Score: 0,
            p2Score: 0,
            p1Move: { cardId: 0, stance: 'none' },
            p2Move: { cardId: 0, stance: 'none' },
            roundHistory: [],
            winnerId: '',
            p1Claimed: false,
            p2Claimed: false,
            turnStartedAt: Date.now(),
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });

          tx.update(qRef, {
            status: 'matched',
            battleId: battleRef.id,
            matchedWith: profile.uid,
            updatedAt: serverTimestamp(),
          });
        });
        playSfx('pack');
        onToast(`Adversaire trouvé : ${opponent.displayName} !`);
        return;
      } catch {
        // Fallback to enqueueing self
      }
    }

    // Enter waiting queue
    try {
      await setDoc(doc(db, 'battleQueue', profile.uid), {
        uid: profile.uid,
        displayName: profile.displayName,
        site: profile.site,
        elo: profile.elo,
        avatarId: profile.avatarId,
        frameId: profile.frameId,
        deck,
        status: 'waiting',
        battleId: '',
        matchedWith: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      onToast('Recherche d’un adversaire classé…');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `battleQueue/${profile.uid}`);
    }
  };

  const handleLeaveQueue = async () => {
    try {
      await deleteDoc(doc(db, 'battleQueue', profile.uid));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `battleQueue/${profile.uid}`);
    }
  };

  const handleCreateOpenChallenge = async (mode: 'ranked' | 'friendly') => {
    if (deck.length !== 3) {
      onToast('Sélectionnez 3 cartes pour créer un salon.');
      return;
    }
    try {
      const ref = doc(collection(db, 'battles'));
      await setDoc(ref, {
        p1Id: profile.uid,
        p1Name: profile.displayName,
        p1Site: profile.site,
        p1Elo: profile.elo,
        p1Avatar: profile.avatarId,
        p1Frame: profile.frameId,
        p1Deck: deck,
        p2Id: '',
        p2Name: '',
        p2Site: '',
        p2Elo: 0,
        p2Avatar: '',
        p2Frame: '',
        p2Deck: [],
        mode,
        status: 'open',
        round: 1,
        p1Score: 0,
        p2Score: 0,
        p1Move: { cardId: 0, stance: 'none' },
        p2Move: { cardId: 0, stance: 'none' },
        roundHistory: [],
        winnerId: '',
        p1Claimed: false,
        p2Claimed: false,
        turnStartedAt: Date.now(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      onToast('Salon de duel créé ! En attente d’un élève.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'battles');
    }
  };

  const handleJoinOpenBattle = async (b: BattleDoc) => {
    if (deck.length !== 3) {
      onToast('Sélectionnez 3 cartes dans votre deck avant de rejoindre.');
      return;
    }
    try {
      await updateDoc(doc(db, 'battles', b.id), {
        p2Id: profile.uid,
        p2Name: profile.displayName,
        p2Site: profile.site,
        p2Elo: profile.elo,
        p2Avatar: profile.avatarId,
        p2Frame: profile.frameId,
        p2Deck: deck,
        status: 'active',
        turnStartedAt: Date.now(),
        updatedAt: serverTimestamp(),
      });
      playSfx('pack');
      onToast(`Duel lancé contre ${b.p1Name} !`);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `battles/${b.id}`);
    }
  };

  const handleCancelOpenBattle = async (b: BattleDoc) => {
    try {
      await updateDoc(doc(db, 'battles', b.id), {
        status: 'cancelled',
        updatedAt: serverTimestamp(),
      });
      onToast('Défi annulé.');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `battles/${b.id}`);
    }
  };

  const handleSubmitMove = async () => {
    if (!activeBattle || !selectedCard || submittingMove) return;
    setSubmittingMove(true);
    const isP1 = activeBattle.p1Id === profile.uid;
    try {
      await updateDoc(doc(db, 'battles', activeBattle.id), {
        [isP1 ? 'p1Move' : 'p2Move']: {
          cardId: selectedCard,
          stance: selectedStance,
        },
        updatedAt: serverTimestamp(),
      });
      playSfx('pack');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `battles/${activeBattle.id}`);
    } finally {
      setSubmittingMove(false);
    }
  };

  const handleForfeit = async () => {
    if (!activeBattle || activeBattle.status !== 'active') return;
    const isP1 = activeBattle.p1Id === profile.uid;
    try {
      await updateDoc(doc(db, 'battles', activeBattle.id), {
        status: 'finished',
        winnerId: isP1 ? activeBattle.p2Id : activeBattle.p1Id,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `battles/${activeBattle.id}`);
    }
  };

  // --- Solo Training Practice (explicitly Solo Bot) ---
  const startBotTraining = () => {
    if (deck.length !== 3) {
      onToast('Sélectionnez 3 cartes pour lancer l’entraînement.');
      return;
    }
    const oppSite: Site = profile.site === 'Labbé' ? 'Marceau' : 'Labbé';
    const pool = CARDS.filter((c) => c.r !== 'EX');
    const bDeck: number[] = [];
    while (bDeck.length < 3) {
      const pick = pool[Math.floor(Math.random() * pool.length)];
      if (!bDeck.includes(pick.id)) bDeck.push(pick.id);
    }
    setBotBattle({
      botName: `Automate ${oppSite}`,
      botSite: oppSite,
      botDeck: bDeck,
      round: 1,
      pScore: 0,
      bScore: 0,
      usedPlayer: [],
      usedBot: [],
      history: [],
      finished: false,
    });
    setSelectedCard(null);
  };

  const playBotRound = async () => {
    if (!botBattle || !selectedCard || botBattle.finished) return;
    const availBot = botBattle.botDeck.filter((id) => !botBattle.usedBot.includes(id));
    const botCardId = availBot[Math.floor(Math.random() * availBot.length)] || botBattle.botDeck[0];
    const stances: Exclude<Stance, 'none'>[] = ['assault', 'defense', 'counter'];
    const botStance = stances[Math.floor(Math.random() * stances.length)];

    const summary = resolveBattleRound(
      botBattle.round,
      { cardId: selectedCard, stance: selectedStance },
      { cardId: botCardId, stance: botStance },
      profile.site,
      botBattle.botSite
    );

    const nextP = botBattle.pScore + (summary.winner === 'p1' ? 1 : 0);
    const nextB = botBattle.bScore + (summary.winner === 'p2' ? 1 : 0);
    const nextHistory = [...botBattle.history, summary];
    const finished = nextP >= 2 || nextB >= 2 || botBattle.round >= 3;

    playSfx('hit');
    setBotBattle({
      ...botBattle,
      round: finished ? botBattle.round : botBattle.round + 1,
      pScore: nextP,
      bScore: nextB,
      usedPlayer: [...botBattle.usedPlayer, selectedCard],
      usedBot: [...botBattle.usedBot, botCardId],
      history: nextHistory,
      finished,
    });
    setSelectedCard(null);

    if (finished && nextP >= nextB) {
      await onUpdateProfile((prev) => ({
        ...prev,
        coins: prev.coins + 15,
      }));
      playSfx('win');
      onToast('Entraînement remporté : +15 ●');
    }
  };

  // --- Render Active PvP Battle View ---
  if (activeBattle && activeBattle.status === 'active') {
    const isP1 = activeBattle.p1Id === profile.uid;
    const myDeckIds = isP1 ? activeBattle.p1Deck : activeBattle.p2Deck;
    const myMove = isP1 ? activeBattle.p1Move : activeBattle.p2Move;
    const oppMove = isP1 ? activeBattle.p2Move : activeBattle.p1Move;
    const myScore = isP1 ? activeBattle.p1Score : activeBattle.p2Score;
    const oppScore = isP1 ? activeBattle.p2Score : activeBattle.p1Score;
    const oppName = isP1 ? activeBattle.p2Name : activeBattle.p1Name;
    const oppSite = isP1 ? activeBattle.p2Site : activeBattle.p1Site;
    const oppElo = isP1 ? activeBattle.p2Elo : activeBattle.p1Elo;

    const usedIds = (activeBattle.roundHistory || []).map((r) =>
      isP1 ? r.p1CardId : r.p2CardId
    );
    const myMoved = myMove.stance !== 'none';

    return (
      <div className="space-y-6">
        <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div>
              <div className="text-xs text-[var(--mut)]">
                Manche {activeBattle.round} / 3 · {activeBattle.mode === 'ranked' ? 'Duel Classé' : 'Duel Amical'}
              </div>
              <div className="font-display text-xl font-bold text-white mt-0.5">
                {profile.displayName}{' '}
                <span className="font-mono-num text-[#e2bb6b] mx-1.5">
                  {myScore} — {oppScore}
                </span>{' '}
                {oppName}
              </div>
              <div className="text-xs text-[var(--mut)] mt-0.5">
                {profile.site} ({profile.elo} ELO) vs {oppSite} ({oppElo} ELO)
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="font-mono-num text-xs font-bold px-3 py-1.5 rounded-lg bg-white/5 text-white">
              {turnRemaining}s
            </span>
            <button
              type="button"
              onClick={handleForfeit}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-500/35 text-rose-400 hover:bg-rose-500/10 text-xs font-semibold"
            >
              <Flag className="w-3.5 h-3.5" />
              Abandonner
            </button>
          </div>
        </div>

        {/* Opponent Status */}
        <div className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-between">
          <div className="text-sm font-medium text-white">
            Adversaire : <span className="font-bold">{oppName}</span> · {oppSite}
          </div>
          <div className="text-xs font-semibold text-[var(--mut)]">
            {oppMove.stance !== 'none'
              ? 'Coup verrouillé — En attente de résolution'
              : 'Réfléchit à sa carte…'}
          </div>
        </div>

        {/* Player Card Selection */}
        <div className="space-y-3">
          <h2 className="font-display text-lg font-bold text-white">
            1. Choisissez votre carte pour la manche {activeBattle.round}
          </h2>
          <div className="grid grid-cols-3 gap-3 sm:gap-4 max-w-xl">
            {myDeckIds.map((cid) => {
              const card = getCardById(cid);
              if (!card) return null;
              const alreadyUsed = usedIds.includes(cid);
              return (
                <div key={cid} className={alreadyUsed ? 'opacity-35 pointer-events-none' : ''}>
                  <CardVisual
                    card={card}
                    showStats
                    selected={selectedCard === cid || myMove.cardId === cid}
                    onClick={myMoved || alreadyUsed ? undefined : () => setSelectedCard(cid)}
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Tactical Stance Selection */}
        <div className="space-y-3">
          <h2 className="font-display text-lg font-bold text-white">
            2. Posture tactique
          </h2>
          <div className="grid grid-cols-3 gap-3 max-w-xl">
            {(['assault', 'defense', 'counter'] as const).map((st) => (
              <button
                key={st}
                type="button"
                disabled={myMoved}
                onClick={() => setSelectedStance(st)}
                className={`p-3 rounded-xl border text-left transition-all ${
                  (myMoved ? myMove.stance : selectedStance) === st
                    ? 'bg-[#e2bb6b]/15 border-[#e2bb6b] text-white'
                    : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)] hover:text-white'
                }`}
              >
                <div className="text-sm font-bold text-white">{STANCE_LABELS[st].label}</div>
                <div className="text-[11px] mt-0.5">
                  {STANCE_LABELS[st].boost} · {STANCE_LABELS[st].beats}
                </div>
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          disabled={myMoved || !selectedCard || submittingMove}
          onClick={handleSubmitMove}
          className="px-6 py-3.5 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] disabled:opacity-40 disabled:pointer-events-none"
        >
          {myMoved
            ? 'Coup envoyé — En attente de l’adversaire…'
            : submittingMove
            ? 'Envoi…'
            : 'Valider le coup'}
        </button>

        {/* Round History */}
        {(activeBattle.roundHistory || []).length > 0 && (
          <div className="space-y-2 pt-4 border-t border-[var(--line)]">
            <h3 className="text-sm font-bold text-white">Historique des manches</h3>
            <div className="space-y-2">
              {activeBattle.roundHistory.map((r) => {
                const myC = getCardById(isP1 ? r.p1CardId : r.p2CardId);
                const opC = getCardById(isP1 ? r.p2CardId : r.p1CardId);
                const myP = isP1 ? r.p1Power : r.p2Power;
                const opP = isP1 ? r.p2Power : r.p1Power;
                const wonRound =
                  (isP1 && r.winner === 'p1') || (!isP1 && r.winner === 'p2');
                return (
                  <div
                    key={r.round}
                    className="p-3 rounded-xl bg-[var(--surface)] border border-[var(--line)] flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <span className="font-mono-num font-bold text-white">
                      Manche {r.round} : {myC?.name} ({myP}) vs {opC?.name} ({opP})
                    </span>
                    <span
                      className={`font-bold ${
                        r.winner === 'draw'
                          ? 'text-[var(--mut)]'
                          : wonRound
                          ? 'text-emerald-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {r.winner === 'draw' ? 'Égalité' : wonRound ? 'Gagnée' : 'Perdue'} · {r.note}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  }

  // --- Render Solo Training Practice View ---
  if (botBattle) {
    return (
      <div className="space-y-6">
        <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-between gap-4">
          <div>
            <div className="text-xs text-[var(--mut)]">
              Entraînement Solo · Sans impact ELO
            </div>
            <div className="font-display text-xl font-bold text-white mt-0.5">
              {profile.displayName}{' '}
              <span className="font-mono-num text-[#e2bb6b] mx-1.5">
                {botBattle.pScore} — {botBattle.bScore}
              </span>{' '}
              {botBattle.botName}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setBotBattle(null)}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white"
          >
            Quitter l’entraînement
          </button>
        </div>

        {!botBattle.finished ? (
          <>
            <div className="space-y-3">
              <h2 className="font-display text-lg font-bold text-white">
                Manche {botBattle.round} / 3 — Choisissez une carte
              </h2>
              <div className="grid grid-cols-3 gap-3 max-w-xl">
                {deck.map((cid) => {
                  const card = getCardById(cid);
                  if (!card) return null;
                  const used = botBattle.usedPlayer.includes(cid);
                  return (
                    <div key={cid} className={used ? 'opacity-35 pointer-events-none' : ''}>
                      <CardVisual
                        card={card}
                        showStats
                        selected={selectedCard === cid}
                        onClick={used ? undefined : () => setSelectedCard(cid)}
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 max-w-xl">
              {(['assault', 'defense', 'counter'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setSelectedStance(st)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedStance === st
                      ? 'bg-[#e2bb6b]/15 border-[#e2bb6b] text-white'
                      : 'bg-[var(--surface)] border-[var(--line)] text-[var(--mut)]'
                  }`}
                >
                  <div className="text-sm font-bold text-white">{STANCE_LABELS[st].label}</div>
                  <div className="text-[11px] mt-0.5">
                    {STANCE_LABELS[st].boost} · {STANCE_LABELS[st].beats}
                  </div>
                </button>
              ))}
            </div>

            <button
              type="button"
              disabled={!selectedCard}
              onClick={playBotRound}
              className="px-6 py-3.5 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] disabled:opacity-40"
            >
              Lancer l’assaut
            </button>
          </>
        ) : (
          <div className="p-6 rounded-2xl bg-[var(--surface)] border border-[var(--line)] text-center space-y-4">
            <h2 className="font-display text-2xl font-bold text-white">
              {botBattle.pScore >= botBattle.bScore
                ? 'Entraînement remporté ! (+15 ●)'
                : 'Entraînement terminé'}
            </h2>
            <p className="text-sm text-[var(--mut)]">
              Score final : {botBattle.pScore} — {botBattle.bScore}
            </p>
            <div className="flex justify-center gap-3">
              <button
                type="button"
                onClick={startBotTraining}
                className="px-5 py-2.5 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f]"
              >
                Rejouer
              </button>
              <button
                type="button"
                onClick={() => setBotBattle(null)}
                className="px-5 py-2.5 rounded-xl bg-white/10 text-sm font-bold text-white"
              >
                Retour au salon
              </button>
            </div>
          </div>
        )}

        {botBattle.history.length > 0 && (
          <div className="space-y-2">
            {botBattle.history.map((r) => (
              <div
                key={r.round}
                className="p-3 rounded-xl bg-[var(--surface)] border border-[var(--line)] flex justify-between text-xs"
              >
                <span className="font-mono-num text-white">
                  M{r.round} : {getCardById(r.p1CardId)?.name} ({r.p1Power}) vs{' '}
                  {getCardById(r.p2CardId)?.name} ({r.p2Power})
                </span>
                <span className={r.winner === 'p1' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {r.winner === 'p1' ? 'Gagnée' : r.winner === 'p2' ? 'Perdue' : 'Égalité'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // --- Main Arena Lobby & Deck Builder ---
  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
            Arène Multijoueur Compétitive
          </h1>
          <p className="text-sm text-[var(--mut)] mt-1">
            Affrontez les élèves des sites Labbé et Marceau en temps réel · Bonus +10% sur les cartes de votre campus
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono-num">
          <span className="text-white font-bold">{profile.elo} ELO</span>
          <span className="text-[var(--mut)]">·</span>
          <span className="text-emerald-400 font-bold">{profile.wins}V</span>
          <span className="text-rose-400 font-bold">{profile.losses}D</span>
        </div>
      </div>

      {/* Matchmaking & Challenge Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 p-6 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-white">
              Votre Deck de Duel ({deck.length} / 3)
            </h2>
            <button
              type="button"
              onClick={() => setDeck(ownedCards.slice(0, 3).map((c) => c.id))}
              className="text-xs font-semibold text-[#e2bb6b] hover:underline"
            >
              Meilleur deck auto
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {deck.map((cid) => {
              const card = getCardById(cid);
              if (!card) return null;
              return (
                <CardVisual
                  key={cid}
                  card={card}
                  showStats
                  selected
                  onClick={() => toggleDeckCard(cid)}
                />
              );
            })}
          </div>

          <div className="pt-3 border-t border-[var(--line)] space-y-3">
            <p className="text-xs text-[var(--mut)]">
              Cliquez sur vos cartes ci-dessous pour composer votre trio (Règles : Assaut bat Contre · Défense bat Assaut · Contre bat Défense) :
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2.5 max-h-64 overflow-y-auto pr-1">
              {ownedCards.map((c) => (
                <CardVisual
                  key={c.id}
                  card={c}
                  compact
                  selected={deck.includes(c.id)}
                  onClick={() => toggleDeckCard(c.id)}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4">
          {/* Quick Matchmaking */}
          <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
                <Swords className="w-5 h-5 text-[#e2bb6b]" />
                Matchmaking Classé
              </h3>
              <span className="text-xs font-mono-num text-[var(--mut)]">
                {waitingQueue.length} en attente
              </span>
            </div>
            <p className="text-xs text-[var(--mut)]">
              Trouvez automatiquement un adversaire connecté en temps réel. Victoire : +65 ● et points ELO.
            </p>
            {queueEntry?.status === 'waiting' ? (
              <div className="flex items-center justify-between gap-3 p-3 rounded-xl bg-[#e2bb6b]/10 border border-[#e2bb6b]/30">
                <span className="inline-flex items-center gap-2 text-xs font-bold text-[#e2bb6b]">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Recherche d’un joueur en cours…
                </span>
                <button
                  type="button"
                  onClick={handleLeaveQueue}
                  className="px-3 py-1.5 rounded-lg bg-white/10 text-xs font-bold text-white"
                >
                  Annuler
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleFindRankedMatch}
                disabled={deck.length !== 3 || Boolean(activeBattle)}
                className="w-full py-3 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] hover:brightness-110 disabled:opacity-40 transition-all"
              >
                Trouver un adversaire PvP
              </button>
            )}
          </div>

          {/* Open Lobby / Direct Challenges */}
          <div className="p-5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-sky-400" />
                Salons Ouverts ({openBattles.length})
              </h3>
              <button
                type="button"
                disabled={deck.length !== 3 || Boolean(activeBattle)}
                onClick={() => handleCreateOpenChallenge('ranked')}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-bold text-white disabled:opacity-40"
              >
                <Plus className="w-3.5 h-3.5" />
                Créer un défi
              </button>
            </div>

            {openBattles.length === 0 ? (
              <p className="text-xs text-[var(--mut)] py-4 text-center border border-dashed border-[var(--line)] rounded-xl">
                Aucun salon ouvert. Créez un défi pour inviter un camarade de Labbé ou Marceau !
              </p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto">
                {openBattles.map((b) => {
                  const isMine = b.p1Id === profile.uid;
                  const av = getCosmetic(b.p1Avatar);
                  return (
                    <div
                      key={b.id}
                      className="p-3 rounded-xl bg-[var(--surface-2)] border border-[var(--line)] flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white truncate">
                          {av?.symbol || '◆'} {b.p1Name}
                        </div>
                        <div className="text-xs text-[var(--mut)] font-mono-num">
                          {b.p1Site} · {b.p1Elo} ELO · {b.mode === 'ranked' ? 'Classé' : 'Amical'}
                        </div>
                      </div>
                      {isMine ? (
                        <button
                          type="button"
                          onClick={() => handleCancelOpenBattle(b)}
                          className="px-3 py-1.5 rounded-lg border border-rose-500/35 text-rose-400 text-xs font-bold shrink-0"
                        >
                          Annuler
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleJoinOpenBattle(b)}
                          className="px-3 py-1.5 rounded-lg bg-[#e2bb6b] text-[#1d1405] text-xs font-bold shrink-0"
                        >
                          Rejoindre
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Solo Training Bot */}
          <div className="p-4 rounded-2xl bg-[var(--surface)] border border-[var(--line)] flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-sm font-bold text-white flex items-center gap-1.5">
                <Bot className="w-4 h-4 text-emerald-400" />
                Entraînement Solo
              </div>
              <p className="text-xs text-[var(--mut)]">
                Tester votre deck contre l’automate du campus (+15 ●)
              </p>
            </div>
            <button
              type="button"
              onClick={startBotTraining}
              disabled={deck.length !== 3}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-bold text-white shrink-0"
            >
              S’entraîner
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
