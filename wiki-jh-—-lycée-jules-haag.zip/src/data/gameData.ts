import type {
  AchievementDef,
  BattleMove,
  CardDef,
  CosmeticItem,
  PlayerProfile,
  Rarity,
  RoundSummary,
  Site,
  Stance,
} from '../types/game';

export const LABBE_IMG = '/assets/aistudio/labbe_d17a5889.jpg';
export const MARCEAU_IMG = '/assets/aistudio/marceau_9d47ae5e.jpg';
export const LABBE_COUR_IMG = '/assets/aistudio/images_28d4c789.jpeg';
export const LABBE_HORLOGE_IMG = '/assets/aistudio/images-3_79d7815b.jpeg';
export const LABBE_ESCALIER_IMG = '/assets/aistudio/images-2_948d2426.jpeg';
export const LABBE_AMPHI_IMG = '/assets/aistudio/images-1_7f26794d.jpeg';
export const MARCEAU_COUR_IMG = '/assets/aistudio/images-4_d3acd662.jpeg';
export const MARCEAU_ATELIER_IMG = '/assets/aistudio/images-5_536a8b68.jpeg';

export const MAX_PACKS = 10;
export const CARDS_PER_PACK = 5;
export const PACK_INTERVAL_MS = 10 * 60 * 1000;
export const MAX_MARKET_SLOTS = 5;
export const EXTRA_PACK_COST = 120;
export const DAILY_COINS = 75;
export const DAILY_COOLDOWN_MS = 24 * 60 * 60 * 1000;
export const DISCARD_COINS = 1;

export interface FiliereGroup {
  site: Site;
  trackLabel: string;
  classes: string[];
}

export const CAMPUS_FILIERES: FiliereGroup[] = [
  {
    site: 'Labbé',
    trackLabel: 'Voie Générale (Site Labbé)',
    classes: [
      '2nde Générale & Techno',
      '1ère Générale',
      'Terminale Générale',
    ],
  },
  {
    site: 'Labbé',
    trackLabel: 'Voie Technologique STI2D (Site Labbé)',
    classes: [
      '1ère STI2D',
      'Terminale STI2D',
    ],
  },
  {
    site: 'Labbé',
    trackLabel: 'BTS & CPGE (Site Labbé)',
    classes: [
      'BTS CIEL / Informatique',
      'BTS Microtechniques (CIM)',
      'BTS Électrotechnique',
      'BTS Opticien-Lunetier',
      'BTS CPRP',
      'CPGE TSI',
    ],
  },
  {
    site: 'Marceau',
    trackLabel: 'CAP Professionnels (Site Marceau)',
    classes: [
      'CAP Horlogerie',
      'CAP Bijouterie',
      'CAP Électricien',
    ],
  },
  {
    site: 'Marceau',
    trackLabel: 'Baccalauréats Pro & BMA (Site Marceau)',
    classes: [
      '2nde Pro PMIA',
      '2nde Pro TNE',
      '1ère Pro Microtechniques',
      'Term. Pro Microtechniques',
      '1ère Pro MELEC',
      'Term. Pro MELEC',
      '1ère Pro CIEL',
      'Term. Pro CIEL',
      '1ère Pro TRPM',
      'Term. Pro TRPM',
      '1ère Pro MSPC',
      'Term. Pro MSPC',
      'BMA Horlogerie / Bijou',
    ],
  },
  {
    site: 'Labbé',
    trackLabel: 'Équipe Éducative & Autres',
    classes: [
      'Autre / Équipe JH',
    ],
  },
];

export const RARITY_ORDER: Rarity[] = ['EX', 'L', 'UR', 'SR', 'R', 'PC', 'C'];

export const RARITY_META: Record<
  Rarity,
  { label: string; color: string; scoreWeight: number }
> = {
  C: { label: 'Commune', color: '#64748b', scoreWeight: 10 },
  PC: { label: 'Peu commune', color: '#2563eb', scoreWeight: 25 },
  R: { label: 'Rare', color: '#7c3aed', scoreWeight: 55 },
  SR: { label: 'Super rare', color: '#db2777', scoreWeight: 110 },
  UR: { label: 'Ultra rare', color: '#ea580c', scoreWeight: 220 },
  L: { label: 'Légendaire', color: '#ca8a04', scoreWeight: 480 },
  EX: { label: 'Exotique', color: '#0d9488', scoreWeight: 1200 },
};

export const CARDS: CardDef[] = [
  {
    id: 1,
    r: 'C',
    name: 'Site Labbé',
    sub: 'Commune',
    icon: '◆',
    img: LABBE_IMG,
    campus: 'Labbé',
    weight: 42.0,
    atk: 36,
    def: 42,
    spd: 32,
    recycleCoins: 8,
    suggestedPrice: 20,
    lore: 'Façade Art Déco historique de la rue Labbé, pôle général et technologique de Besançon.',
  },
  {
    id: 2,
    r: 'PC',
    name: 'Site Marceau',
    sub: 'Peu commune',
    icon: '✦',
    img: MARCEAU_IMG,
    campus: 'Marceau',
    weight: 14.5,
    atk: 46,
    def: 44,
    spd: 44,
    recycleCoins: 18,
    suggestedPrice: 45,
    lore: 'Entrée moderne vitrée du site Marceau, pôle du Lycée Professionnel.',
  },
  {
    id: 3,
    r: 'R',
    name: 'Cour Intérieure Labbé',
    sub: 'Rare',
    icon: '❖',
    img: LABBE_COUR_IMG,
    campus: 'Labbé',
    weight: 5.5,
    atk: 58,
    def: 64,
    spd: 48,
    recycleCoins: 35,
    suggestedPrice: 90,
    lore: 'Grande cour bordée par les ailes historiques du bâtiment Labbé.',
  },
  {
    id: 4,
    r: 'SR',
    name: 'Atelier Pro Marceau',
    sub: 'Super rare',
    icon: '⚙',
    img: MARCEAU_ATELIER_IMG,
    campus: 'Marceau',
    weight: 2.35,
    atk: 71,
    def: 66,
    spd: 62,
    recycleCoins: 75,
    suggestedPrice: 190,
    lore: 'Plateau technique industriel et centres d’usinage du Lycée Professionnel Marceau.',
  },
  {
    id: 5,
    r: 'UR',
    name: 'Lycée Jules Haag',
    sub: 'Ultra rare',
    icon: '✹',
    img: LABBE_IMG,
    campus: 'Jules Haag',
    weight: 0.55,
    atk: 84,
    def: 82,
    spd: 76,
    recycleCoins: 160,
    suggestedPrice: 420,
    lore: 'L’alliance des deux sites bisontins réunis sous l’héritage du mathématicien Jules Haag.',
  },
  {
    id: 6,
    r: 'L',
    name: 'Jules Haag Légende',
    sub: 'Légendaire',
    icon: '♛',
    img: MARCEAU_IMG,
    campus: 'Jules Haag',
    weight: 0.14,
    atk: 94,
    def: 91,
    spd: 89,
    recycleCoins: 350,
    suggestedPrice: 950,
    lore: 'Symbole d’excellence technique et générale transmis de promotion en promotion.',
  },
  {
    id: 7,
    r: 'EX',
    name: 'JH Exotique',
    sub: 'Exotique',
    icon: '❂',
    img: LABBE_ESCALIER_IMG,
    campus: 'Jules Haag',
    weight: 0.03,
    atk: 106,
    def: 100,
    spd: 102,
    recycleCoins: 800,
    suggestedPrice: 2500,
    lore: 'Édition prismatique rarissime célébrant l’esprit Jules Haag.',
  },
  {
    id: 8,
    r: 'C',
    name: 'Cour de Marceau',
    sub: 'Commune',
    icon: '◈',
    img: MARCEAU_COUR_IMG,
    campus: 'Marceau',
    weight: 18.0,
    atk: 38,
    def: 36,
    spd: 42,
    recycleCoins: 8,
    suggestedPrice: 22,
    lore: 'Cour et terrain de basket du site Marceau entre deux cours.',
  },
  {
    id: 9,
    r: 'PC',
    name: 'Horloge de Labbé',
    sub: 'Peu commune',
    icon: '◷',
    img: LABBE_HORLOGE_IMG,
    campus: 'Labbé',
    weight: 9.0,
    atk: 43,
    def: 52,
    spd: 40,
    recycleCoins: 18,
    suggestedPrice: 48,
    lore: 'Le cadran monumental qui rythme les journées au sommet du fronton Labbé.',
  },
  {
    id: 10,
    r: 'R',
    name: 'Verrière Marceau',
    sub: 'Rare',
    icon: '◇',
    img: MARCEAU_IMG,
    campus: 'Marceau',
    weight: 4.5,
    atk: 61,
    def: 54,
    spd: 66,
    recycleCoins: 35,
    suggestedPrice: 95,
    lore: 'Façade vitrée quadrillée baignant les couloirs de lumière.',
  },
  {
    id: 11,
    r: 'SR',
    name: 'Escalier Art Déco',
    sub: 'Super rare',
    icon: '🌀',
    img: LABBE_ESCALIER_IMG,
    campus: 'Labbé',
    weight: 1.85,
    atk: 74,
    def: 68,
    spd: 58,
    recycleCoins: 75,
    suggestedPrice: 210,
    lore: 'La cage d’escalier hélicoïdale turquoise et ferronnerie d’époque du site Labbé.',
  },
  {
    id: 12,
    r: 'UR',
    name: 'Beffroi Art Déco',
    sub: 'Ultra rare',
    icon: '♜',
    img: LABBE_HORLOGE_IMG,
    campus: 'Labbé',
    weight: 0.48,
    atk: 86,
    def: 85,
    spd: 72,
    recycleCoins: 160,
    suggestedPrice: 440,
    lore: 'Tour centrale sculptée veillant sur le campus Labbé depuis 1932.',
  },
  {
    id: 13,
    r: 'UR',
    name: 'Agora Stendhal-Marceau',
    sub: 'Ultra rare',
    icon: '✧',
    img: MARCEAU_COUR_IMG,
    campus: 'Marceau',
    weight: 0.4,
    atk: 82,
    def: 80,
    spd: 86,
    recycleCoins: 160,
    suggestedPrice: 440,
    lore: 'Carrefour scolaire unissant les filières professionnelles du pôle Marceau.',
  },
  {
    id: 14,
    r: 'L',
    name: 'Couronne Jules Haag',
    sub: 'Légendaire',
    icon: '✪',
    img: LABBE_IMG,
    campus: 'Jules Haag',
    weight: 0.1,
    atk: 92,
    def: 95,
    spd: 88,
    recycleCoins: 350,
    suggestedPrice: 980,
    lore: 'Relique prestigieuse remise aux champions de la Coupe Inter-Sites.',
  },
  {
    id: 15,
    r: 'R',
    name: 'Amphithéâtre Labbé',
    sub: 'Rare',
    icon: '◈',
    img: LABBE_AMPHI_IMG,
    campus: 'Labbé',
    weight: 4.0,
    atk: 56,
    def: 60,
    spd: 55,
    recycleCoins: 35,
    suggestedPrice: 95,
    lore: 'Grande salle de conférences et de réunions baignée par les hautes verrières de Labbé.',
  },
];

export const getCardById = (id: number): CardDef | undefined =>
  CARDS.find((c) => c.id === id);

export function drawRandomCard(): CardDef {
  const total = CARDS.reduce((sum, c) => sum + c.weight, 0);
  let roll = Math.random() * total;
  for (const card of CARDS) {
    roll -= card.weight;
    if (roll <= 0) return card;
  }
  return CARDS[0];
}

export function drawBoosterPack(count = CARDS_PER_PACK): CardDef[] {
  const drawn = Array.from({ length: count }, drawRandomCard);
  return drawn.sort(
    (a, b) => RARITY_ORDER.indexOf(b.r) - RARITY_ORDER.indexOf(a.r)
  );
}

export const COSMETICS: CosmeticItem[] = [
  // Avatars
  { id: 'av_horloge', type: 'avatar', name: 'Horloger', description: 'Emblème mécanique de précision', price: 0, symbol: '◷' },
  { id: 'av_eclaireur', type: 'avatar', name: 'Éclaireur', description: 'Avant-garde du campus', price: 0, symbol: '◆' },
  { id: 'av_stratege', type: 'avatar', name: 'Stratège', description: 'Maître des duels tactiques', price: 120, symbol: '♛' },
  { id: 'av_alchimiste', type: 'avatar', name: 'Ingénieur', description: 'Esprit créatif de Jules Haag', price: 160, symbol: '⚙' },
  { id: 'av_phoenix', type: 'avatar', name: 'Comète JH', description: 'Édition prestigieuse du lycée', price: 320, symbol: '❂' },

  // Frames
  { id: 'fr_classic', type: 'frame', name: 'Acier Sobre', description: 'Bordure classique du lycée', price: 0, previewClass: 'ring-1 ring-slate-300' },
  { id: 'fr_labbe', type: 'frame', name: 'Cobalt Labbé', description: 'Liseré bleu royal du site Labbé', price: 140, previewClass: 'ring-2 ring-blue-500 shadow-[0_0_16px_rgba(37,99,235,0.3)]' },
  { id: 'fr_marceau', type: 'frame', name: 'Émeraude Marceau', description: 'Liseré émeraude du site Marceau', price: 140, previewClass: 'ring-2 ring-emerald-500 shadow-[0_0_16px_rgba(16,185,129,0.3)]' },
  { id: 'fr_gold', type: 'frame', name: 'Or Jules Haag', description: 'Cadre doré prestige', price: 300, previewClass: 'ring-2 ring-amber-500 shadow-[0_0_18px_rgba(217,119,6,0.35)]' },
  { id: 'fr_exotic', type: 'frame', name: 'Prisme Exotique', description: 'Halo cyan rareté Exotique', price: 650, previewClass: 'ring-2 ring-teal-400 shadow-[0_0_20px_rgba(20,184,166,0.4)]', unlockHint: 'Boutique ou Succès Exotique' },

  // Banners
  { id: 'bn_obsidian', type: 'banner', name: 'Ardoise Classique', description: 'Bannière sobre bleu-nuit du lycée', price: 0, previewClass: 'from-slate-800 to-slate-900' },
  { id: 'bn_labbe', type: 'banner', name: 'Façade Labbé', description: 'Dégradé architectural cobalt & pierre', price: 180, previewClass: 'from-blue-800 via-indigo-900 to-slate-900' },
  { id: 'bn_marceau', type: 'banner', name: 'Verrière Marceau', description: 'Reflets émeraude et ambre', price: 180, previewClass: 'from-emerald-800 via-teal-900 to-slate-900' },
  { id: 'bn_royal', type: 'banner', name: 'Blason d’Or', description: 'Édition Champion du Lycée', price: 420, previewClass: 'from-amber-700 via-amber-900 to-slate-900' },

  // Titles
  { id: 'ti_eleve', type: 'title', name: 'Élève de Jules Haag', description: 'Titre de départ', price: 0 },
  { id: 'ti_duelliste', type: 'title', name: 'Duelliste Classé', description: 'Combattant régulier de l’Arène', price: 100 },
  { id: 'ti_courtier', type: 'title', name: 'Courtier des Sites', description: 'Fin négociateur du Marché', price: 150 },
  { id: 'ti_champion_labbe', type: 'title', name: 'Héros de Labbé', description: 'Défenseur du site Labbé', price: 240 },
  { id: 'ti_champion_marceau', type: 'title', name: 'Héros de Marceau', description: 'Défenseur du site Marceau', price: 240 },
  { id: 'ti_legende', type: 'title', name: 'Légende Jules Haag', description: 'Titre suprême de prestige', price: 500 },
];

export const DEFAULT_UNLOCKED_COSMETICS = [
  'av_horloge',
  'av_eclaireur',
  'fr_classic',
  'bn_obsidian',
  'ti_eleve',
];

export const getCosmetic = (id: string): CosmeticItem | undefined =>
  COSMETICS.find((c) => c.id === id);

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'ach_first_pack',
    title: 'Premier Booster',
    description: 'Ouvrir votre tout premier paquet Wiki JH.',
    category: 'Collection',
    rewardCoins: 40,
    target: 1,
    progress: (p) => p.opened,
  },
  {
    id: 'ach_ten_packs',
    title: 'Chasseur de Boosters',
    description: 'Ouvrir 10 paquets de cartes.',
    category: 'Collection',
    rewardCoins: 90,
    target: 10,
    progress: (p) => p.opened,
  },
  {
    id: 'ach_collector_7',
    title: 'Explorateur des 2 Sites',
    description: 'Découvrir 7 cartes uniques dans votre collection.',
    category: 'Collection',
    rewardCoins: 110,
    target: 7,
    progress: (p) => Object.values(p.inv || {}).filter((n) => n > 0).length,
  },
  {
    id: 'ach_collector_all',
    title: 'Wiki Master Jules Haag',
    description: 'Compléter l’intégralité des 15 cartes du jeu.',
    category: 'Collection',
    rewardCoins: 450,
    rewardCosmeticId: 'ti_legende',
    target: CARDS.length,
    progress: (p) => Object.values(p.inv || {}).filter((n) => n > 0).length,
  },
  {
    id: 'ach_exotic_pull',
    title: 'Éclat Exotique',
    description: 'Posséder une carte Légendaire ou Exotique.',
    category: 'Collection',
    rewardCoins: 200,
    rewardCosmeticId: 'fr_exotic',
    target: 1,
    progress: (p) => ((p.inv['6'] || 0) + (p.inv['7'] || 0) + (p.inv['14'] || 0) > 0 ? 1 : 0),
  },
  {
    id: 'ach_first_win',
    title: 'Baptême de l’Arène',
    description: 'Remporter votre première bataille multijoueur.',
    category: 'Arène',
    rewardCoins: 65,
    target: 1,
    progress: (p) => p.wins,
  },
  {
    id: 'ach_five_wins',
    title: 'Combattant Aguerri',
    description: 'Cumuler 5 victoires dans l’Arène.',
    category: 'Arène',
    rewardCoins: 140,
    rewardCosmeticId: 'ti_duelliste',
    target: 5,
    progress: (p) => p.wins,
  },
  {
    id: 'ach_streak_3',
    title: 'Série Implacable',
    description: 'Enchaîner 3 victoires consécutives.',
    category: 'Arène',
    rewardCoins: 150,
    target: 3,
    progress: (p) => p.bestStreak,
  },
  {
    id: 'ach_elo_1150',
    title: 'Élite du Lycée',
    description: 'Atteindre 1150 points ELO au classement.',
    category: 'Campus',
    rewardCoins: 220,
    rewardCosmeticId: 'fr_gold',
    target: 1150,
    progress: (p) => p.elo,
  },
  {
    id: 'ach_first_trade',
    title: 'Esprit d’Entraide',
    description: 'Finaliser 1 échange de cartes avec un autre joueur.',
    category: 'Commerce',
    rewardCoins: 75,
    target: 1,
    progress: (p) => p.tradesCompleted,
  },
  {
    id: 'ach_first_sale',
    title: 'Négociant du Campus',
    description: 'Vendre 1 carte sur le Marché inter-sites.',
    category: 'Commerce',
    rewardCoins: 80,
    rewardCosmeticId: 'ti_courtier',
    target: 1,
    progress: (p) => p.marketSales,
  },
];

export function computeCollectionScore(inv: Record<string, number>): number {
  return CARDS.reduce((sum, c) => {
    const qty = inv[String(c.id)] || 0;
    if (qty <= 0) return sum;
    return sum + RARITY_META[c.r].scoreWeight + Math.min(qty - 1, 5) * 5;
  }, 0);
}

export function resolveBattleRound(
  round: number,
  p1Move: BattleMove,
  p2Move: BattleMove,
  p1Site: Site,
  p2Site: Site
): RoundSummary {
  const c1 = getCardById(p1Move.cardId) || CARDS[0];
  const c2 = getCardById(p2Move.cardId) || CARDS[0];
  const s1: Stance = p1Move.stance;
  const s2: Stance = p2Move.stance;

  const baseStat = (c: CardDef, stance: Stance) => {
    if (stance === 'assault') return Math.round(c.atk * 1.2 + c.spd * 0.25);
    if (stance === 'defense') return Math.round(c.def * 1.25 + c.atk * 0.2);
    return Math.round(c.spd * 1.2 + c.atk * 0.25);
  };

  let p1Pow = baseStat(c1, s1);
  let p2Pow = baseStat(c2, s2);

  // Campus Synergy (+10% power if card matches player's campus or is Jules Haag)
  if (c1.campus === p1Site || c1.campus === 'Jules Haag') p1Pow = Math.round(p1Pow * 1.1);
  if (c2.campus === p2Site || c2.campus === 'Jules Haag') p2Pow = Math.round(p2Pow * 1.1);

  // Rock-paper-scissors stance advantage (+18% tactical bonus)
  let stanceNote = 'Égalité tactique';
  if (
    (s1 === 'assault' && s2 === 'counter') ||
    (s1 === 'defense' && s2 === 'assault') ||
    (s1 === 'counter' && s2 === 'defense')
  ) {
    p1Pow = Math.round(p1Pow * 1.18);
    stanceNote = 'Avantage tactique J1 (+18%)';
  } else if (
    (s2 === 'assault' && s1 === 'counter') ||
    (s2 === 'defense' && s1 === 'assault') ||
    (s2 === 'counter' && s1 === 'defense')
  ) {
    p2Pow = Math.round(p2Pow * 1.18);
    stanceNote = 'Avantage tactique J2 (+18%)';
  }

  let winner: 'p1' | 'p2' | 'draw' = 'draw';
  if (p1Pow > p2Pow) winner = 'p1';
  else if (p2Pow > p1Pow) winner = 'p2';

  return {
    round,
    p1CardId: c1.id,
    p2CardId: c2.id,
    p1Stance: s1,
    p2Stance: s2,
    p1Power: p1Pow,
    p2Power: p2Pow,
    winner,
    note: stanceNote,
  };
}

export function computeEloDelta(winnerElo: number, loserElo: number): { winDelta: number; lossDelta: number } {
  const expectedWin = 1 / (1 + Math.pow(10, (loserElo - winnerElo) / 400));
  const winDelta = Math.max(12, Math.round(32 * (1 - expectedWin)));
  const lossDelta = Math.max(8, Math.round(24 * expectedWin));
  return { winDelta, lossDelta };
}

export const STANCE_LABELS: Record<Exclude<Stance, 'none'>, { label: string; beats: string; boost: string }> = {
  assault: { label: 'Assaut', beats: 'Bat Contre', boost: '+ATK' },
  defense: { label: 'Défense', beats: 'Bat Assaut', boost: '+DEF' },
  counter: { label: 'Contre', beats: 'Bat Défense', boost: '+SPD' },
};

// Gentle Web Audio synthesized game SFX
let audioCtx: AudioContext | null = null;
let sfxMuted = false;

export function setSfxMuted(m: boolean) {
  sfxMuted = m;
}
export function isSfxMuted(): boolean {
  return sfxMuted;
}

export function playSfx(kind: 'pack' | 'rare' | 'exotic' | 'hit' | 'win' | 'coin') {
  if (sfxMuted || typeof window === 'undefined') return;
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    if (!audioCtx) audioCtx = new Ctx();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    const now = audioCtx.currentTime;
    const tone = (freq: number, dur: number, delay = 0, type: OscillatorType = 'triangle', gainVal = 0.08) => {
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, now + delay);
      gain.gain.setValueAtTime(0.0001, now + delay);
      gain.gain.exponentialRampToValueAtTime(gainVal, now + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + delay + dur);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now + delay);
      osc.stop(now + delay + dur + 0.02);
    };

    if (kind === 'pack') {
      tone(330, 0.12, 0, 'sine', 0.07);
      tone(495, 0.18, 0.08, 'triangle', 0.08);
    } else if (kind === 'rare') {
      tone(523.25, 0.14, 0, 'triangle', 0.08);
      tone(659.25, 0.18, 0.09, 'triangle', 0.08);
      tone(783.99, 0.28, 0.18, 'sine', 0.09);
    } else if (kind === 'exotic') {
      tone(523.25, 0.16, 0, 'sine', 0.09);
      tone(659.25, 0.16, 0.08, 'sine', 0.09);
      tone(783.99, 0.18, 0.16, 'triangle', 0.1);
      tone(1046.5, 0.42, 0.25, 'sine', 0.11);
    } else if (kind === 'hit') {
      tone(190, 0.14, 0, 'sawtooth', 0.06);
      tone(140, 0.16, 0.06, 'triangle', 0.05);
    } else if (kind === 'win') {
      tone(440, 0.14, 0, 'triangle', 0.08);
      tone(554.37, 0.14, 0.1, 'triangle', 0.08);
      tone(659.25, 0.28, 0.2, 'sine', 0.09);
    } else if (kind === 'coin') {
      tone(987.77, 0.09, 0, 'sine', 0.07);
      tone(1318.51, 0.18, 0.07, 'sine', 0.07);
    }
  } catch {
    // Ignore audio errors when blocked by autoplay policy
  }
}
