import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  runTransaction,
  setDoc,
  where,
} from 'firebase/firestore';
import {
  Bell,
  BookOpen,
  ChevronDown,
  Gavel,
  Handshake,
  Medal,
  MoreHorizontal,
  Puzzle,
  Settings,
  ShieldCheck,
  Swords,
  Trophy,
  User as UserIcon,
} from 'lucide-react';
import {
  ACHIEVEMENTS,
  LABBE_IMG,
  MARCEAU_IMG,
  MAX_PACKS,
  PACK_INTERVAL_MS,
} from './data/gameData';
import {
  auth,
  buildFreshPlayer,
  db,
  googleProvider,
  handleFirestoreError,
  isSuperAdminEmail,
  sanitizePlayerUpdate,
  testFirestoreConnection,
} from './firebase/client';
import { OperationType, type NavTab, type PlayerProfile, type Site, type TradeOffer } from './types/game';
import { PackOpeningView } from './components/PackOpeningView';
import { ArenaView } from './components/ArenaView';
import { CollectionView } from './components/CollectionView';
import { MarketView } from './components/MarketView';
import { TradesView } from './components/TradesView';
import { AdminView } from './components/AdminView';
import { LeaderboardView } from './components/LeaderboardView';
import { ProfileView, type AppTheme, type ProfileSubTab } from './components/ProfileView';
import { OnboardingModal } from './components/OnboardingModal';

const THEME_STORAGE_KEY = 'wikijh_theme';

export default function App() {
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [allPlayers, setAllPlayers] = useState<PlayerProfile[]>([]);
  const [pendingTrades, setPendingTrades] = useState<TradeOffer[]>([]);
  const [activeTab, setActiveTab] = useState<NavTab>('packs');
  const [profileSubTab, setProfileSubTab] = useState<ProfileSubTab>('customize');
  const [profileTabSignal, setProfileTabSignal] = useState(0);
  const [isPromotedAdmin, setIsPromotedAdmin] = useState(false);
  const [plusOpen, setPlusOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [authError, setAuthError] = useState('');
  const [toastMsg, setToastMsg] = useState('');
  const [theme, setTheme] = useState<AppTheme>(() =>
    typeof window !== 'undefined' && window.localStorage.getItem(THEME_STORAGE_KEY) === 'dark'
      ? 'dark'
      : 'light'
  );

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    window.localStorage.setItem(THEME_STORAGE_KEY, theme);
  }, [theme]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(''), 2800);
    return () => clearTimeout(t);
  }, [toastMsg]);

  useEffect(() => {
    testFirestoreConnection();
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthReady(true);
      if (!u) {
        setProfile(null);
        setNeedsOnboarding(false);
        return;
      }
      try {
        const snap = await getDoc(doc(db, 'players', u.uid));
        if (!snap.exists()) {
          setNeedsOnboarding(true);
        } else {
          setNeedsOnboarding(false);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `players/${u.uid}`);
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to own profile, public leaderboard & pending incoming trades
  useEffect(() => {
    if (!user || needsOnboarding) return;

    const unsubMe = onSnapshot(
      doc(db, 'players', user.uid),
      (snap) => {
        if (snap.exists()) {
          setProfile(snap.data() as PlayerProfile);
        } else {
          setProfile(null);
          setNeedsOnboarding(true);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `players/${user.uid}`)
    );

    const unsubAdmin = onSnapshot(
      doc(db, 'admins', user.uid),
      (snap) => {
        setIsPromotedAdmin(snap.exists());
      },
      () => {
        setIsPromotedAdmin(false);
      }
    );

    const qPlayers = query(
      collection(db, 'players'),
      where('visibility', '==', 'public')
    );
    const unsubAll = onSnapshot(
      qPlayers,
      (snap) => {
        setAllPlayers(snap.docs.map((d) => d.data() as PlayerProfile));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'players')
    );

    const qTrades = query(
      collection(db, 'trades'),
      where('toId', '==', user.uid)
    );
    const unsubTrades = onSnapshot(
      qTrades,
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<TradeOffer, 'id'>) }));
        setPendingTrades(list.filter((t) => t.status === 'pending'));
      },
      () => {}
    );

    return () => {
      unsubMe();
      unsubAdmin();
      unsubAll();
      unsubTrades();
    };
  }, [user, needsOnboarding]);

  const updateProfile = useCallback(
    async (updater: (prev: PlayerProfile) => PlayerProfile) => {
      if (!user) return;
      const pRef = doc(db, 'players', user.uid);
      try {
        await runTransaction(db, async (tx) => {
          const snap = await tx.get(pRef);
          if (!snap.exists()) return;
          const current = snap.data() as PlayerProfile;
          const next = updater(current);
          tx.update(pRef, sanitizePlayerUpdate(next));
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
      }
    },
    [user]
  );

  // Periodic booster pack regeneration check
  useEffect(() => {
    if (!profile || profile.packs >= MAX_PACKS) return;
    const checkRegen = () => {
      const now = Date.now();
      const gain = Math.floor((now - (profile.lastPackAt || now)) / PACK_INTERVAL_MS);
      if (gain > 0) {
        updateProfile((prev) => {
          const nextPacks = Math.min(MAX_PACKS, prev.packs + gain);
          const nextLast =
            nextPacks >= MAX_PACKS
              ? now
              : (prev.lastPackAt || now) + gain * PACK_INTERVAL_MS;
          return { ...prev, packs: nextPacks, lastPackAt: nextLast };
        });
      }
    };
    checkRegen();
    const id = setInterval(checkRegen, 15000);
    return () => clearInterval(id);
  }, [profile, updateProfile]);

  const handleGoogleSignIn = async () => {
    setAuthError('');
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Échec de connexion Google');
    }
  };

  const handleOnboardingComplete = async (data: {
    displayName: string;
    site: Site;
    classe: string;
  }) => {
    if (!user) return;
    const fresh = buildFreshPlayer(user.uid, data.displayName, data.site);
    fresh.classe = data.classe;
    fresh.bio = `Élève de ${data.classe || 'Jules Haag'} · Site ${data.site}`;
    try {
      await setDoc(doc(db, 'players', user.uid), sanitizePlayerUpdate(fresh));
      setNeedsOnboarding(false);
      setProfile(fresh);
      showToast('Profil créé ! Bon jeu sur Wiki JH.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `players/${user.uid}`);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
  };

  const notifications = useMemo(() => {
    if (!profile) return [];
    const items: { id: string; title: string; subtitle: string; action: () => void }[] = [];
    if (pendingTrades.length > 0) {
      items.push({
        id: 'trades',
        title: `${pendingTrades.length} échange${pendingTrades.length > 1 ? 's' : ''} en attente`,
        subtitle: 'Répondre sur la page Échanges',
        action: () => setActiveTab('trades'),
      });
    }
    const claimed = profile.claimedAchievements || [];
    const claimableAch = ACHIEVEMENTS.filter(
      (a) => !claimed.includes(a.id) && a.progress(profile) >= a.target
    ).length;
    if (claimableAch > 0) {
      items.push({
        id: 'ach',
        title: `${claimableAch} succès à réclamer`,
        subtitle: 'Récupérez vos récompenses ●',
        action: () => {
          setProfileSubTab('achievements');
          setProfileTabSignal((n) => n + 1);
          setActiveTab('profile');
        },
      });
    }
    return items;
  }, [profile, pendingTrades]);

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg)] text-sm text-[var(--mut)]">
        Chargement de Wiki JH…
      </div>
    );
  }

  // Auth Landing Screen
  if (!user) {
    return (
      <div className="min-h-screen bg-[var(--bg)] text-[var(--txt)] flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 rounded-3xl overflow-hidden bg-[var(--surface)] border border-[var(--line)] shadow-xl">
          <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between gap-8">
            <div className="space-y-4">
              <div className="font-display text-3xl font-bold text-[var(--txt)] tracking-tight">
                <span className="text-[var(--acc)]">◆</span> Wiki JH
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-[var(--txt)] leading-tight [text-wrap:balance]">
                L’arène des cartes du Lycée Jules Haag
              </h1>
              <p className="text-sm text-[var(--mut)] leading-relaxed">
                Collectionnez les éditions des sites Labbé et Marceau, affrontez vos camarades en duel classé ELO, enchérissez et échangez sur le marché inter-sites et hissez votre campus en tête du classement.
              </p>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                className="w-full py-3.5 px-6 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 transition-all shadow-sm"
              >
                Se connecter avec Google
              </button>
              <p className="text-xs text-[var(--mut)] text-center">
                Monnaie 100 % virtuelle · Sans aucun achat en argent réel
              </p>
              {authError && (
                <p className="text-xs text-rose-600 dark:text-rose-400 text-center">{authError}</p>
              )}
            </div>
          </div>

          <div className="lg:col-span-6 grid grid-rows-2 min-h-[280px] border-t lg:border-t-0 lg:border-l border-[var(--line)]">
            <div className="relative overflow-hidden">
              <img
                src={LABBE_IMG}
                alt="Lycée Jules Haag — Site Labbé"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-3 left-4">
                <div className="font-display text-lg font-bold text-white">Site Labbé</div>
                <div className="text-xs text-white/85">Besançon · Lycée Général & Technologique</div>
              </div>
            </div>
            <div className="relative overflow-hidden border-t border-[var(--line)]">
              <img
                src={MARCEAU_IMG}
                alt="Lycée Jules Haag — Site Marceau"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-3 left-4">
                <div className="font-display text-lg font-bold text-white">Site Marceau</div>
                <div className="text-xs text-white/85">Besançon · Lycée Professionnel</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (needsOnboarding) {
    const email = user.email || '';
    const guessedSite: Site = email.toLowerCase().includes('marceau') ? 'Marceau' : 'Labbé';
    const guessedName = user.displayName || email.split('@')[0] || 'Élève JH';
    return (
      <OnboardingModal
        defaultName={guessedName}
        defaultSite={guessedSite}
        onComplete={handleOnboardingComplete}
      />
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg)] text-sm text-[var(--mut)]">
        Synchronisation de votre profil…
      </div>
    );
  }

  const goTab = (tab: NavTab) => {
    setPlusOpen(false);
    setNotifOpen(false);
    setActiveTab(tab);
  };

  const openProfileSub = (sub: ProfileSubTab) => {
    setProfileSubTab(sub);
    setProfileTabSignal((n) => n + 1);
    goTab('profile');
  };

  const primaryTabs: { id: 'packs' | 'collection' | 'trades' | 'market'; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'packs', label: 'Paquets', icon: <Puzzle className="w-5 h-5" /> },
    { id: 'collection', label: 'Collection', icon: <BookOpen className="w-5 h-5" /> },
    {
      id: 'trades',
      label: 'Échanges',
      icon: <Handshake className="w-5 h-5" />,
      badge: pendingTrades.length > 0 ? pendingTrades.length : undefined,
    },
    { id: 'market', label: 'Marché', icon: <Gavel className="w-5 h-5" /> },
  ];

  const isAdmin = Boolean(
    user.emailVerified && (isSuperAdminEmail(user.email) || isPromotedAdmin)
  );

  const isPlusTabActive =
    activeTab === 'profile' ||
    activeTab === 'arena' ||
    activeTab === 'leaderboard' ||
    activeTab === 'admin';

  const plusMenuItems: { label: string; icon: React.ReactNode; onClick: () => void; active: boolean }[] = [
    {
      label: 'Profil',
      icon: <UserIcon className="w-4 h-4" />,
      onClick: () => openProfileSub('customize'),
      active: activeTab === 'profile' && profileSubTab === 'customize',
    },
    ...(isAdmin
      ? [
          {
            label: 'Admin',
            icon: <ShieldCheck className="w-4 h-4" />,
            onClick: () => goTab('admin'),
            active: activeTab === 'admin',
          },
        ]
      : []),
    {
      label: 'Bataille',
      icon: <Swords className="w-4 h-4" />,
      onClick: () => goTab('arena'),
      active: activeTab === 'arena',
    },
    {
      label: 'Succès',
      icon: <Trophy className="w-4 h-4" />,
      onClick: () => openProfileSub('achievements'),
      active: activeTab === 'profile' && profileSubTab === 'achievements',
    },
    {
      label: 'Classement',
      icon: <Medal className="w-4 h-4" />,
      onClick: () => goTab('leaderboard'),
      active: activeTab === 'leaderboard',
    },
    {
      label: 'Paramètres',
      icon: <Settings className="w-4 h-4" />,
      onClick: () => openProfileSub('settings'),
      active: activeTab === 'profile' && profileSubTab === 'settings',
    },
  ];

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--txt)] pb-24 md:pb-14">
      {/* Top Bar (Wiki Masters style: brand, desktop nav, emerald coin pill + notification bell) */}
      <header className="sticky top-0 z-30 bg-[var(--bg)]/90 backdrop-blur-xl border-b border-[var(--line)]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => goTab('packs')}
            className="font-display text-lg font-bold tracking-tight text-[var(--txt)] whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <span className="text-emerald-500">◆</span> Wiki JH
          </button>

          {/* Desktop Center Nav */}
          <nav className="hidden md:flex items-center gap-5 text-sm font-semibold">
            {primaryTabs.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => goTab(item.id)}
                className={`whitespace-nowrap shrink-0 pb-1 border-b-2 transition-colors flex items-center gap-1.5 ${
                  activeTab === item.id
                    ? 'text-emerald-600 dark:text-emerald-400 border-emerald-500 font-bold'
                    : 'text-[var(--mut)] border-transparent hover:text-[var(--txt)]'
                }`}
              >
                {item.label}
                {item.badge && (
                  <span className="px-1.5 py-0.2 rounded-full bg-emerald-500 text-white text-[10px] font-mono-num">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                setNotifOpen(false);
                setPlusOpen((v) => !v);
              }}
              className={`whitespace-nowrap shrink-0 pb-1 border-b-2 transition-colors inline-flex items-center gap-1 ${
                isPlusTabActive || plusOpen
                  ? 'text-emerald-600 dark:text-emerald-400 border-emerald-500 font-bold'
                  : 'text-[var(--mut)] border-transparent hover:text-[var(--txt)]'
              }`}
            >
              Plus
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </nav>

          {/* Top-Right Emerald Coin Pill + Bell (matching Wiki Masters screenshot) */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => openProfileSub('shop')}
              title="Boutique & Pièces"
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 dark:bg-emerald-500/20 border border-emerald-500/35 text-xs font-extrabold text-emerald-700 dark:text-emerald-400 font-mono-num whitespace-nowrap hover:bg-emerald-500/25 transition-colors"
            >
              <span className="w-4 h-4 rounded-full border border-emerald-500 flex items-center justify-center text-[9px] font-bold">
                W
              </span>
              <span>{profile.coins.toLocaleString('fr-FR')}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setPlusOpen(false);
                setNotifOpen((v) => !v);
              }}
              aria-label="Notifications"
              className="relative p-1.5 rounded-full text-[var(--mut)] hover:text-[var(--txt)] hover:bg-[var(--surface-2)] transition-colors"
            >
              <Bell className="w-5 h-5" />
              {notifications.length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'packs' && (
          <PackOpeningView
            profile={profile}
            onUpdateProfile={updateProfile}
            onToast={showToast}
          />
        )}
        {activeTab === 'collection' && (
          <CollectionView
            profile={profile}
            onUpdateProfile={updateProfile}
            onToast={showToast}
          />
        )}
        {activeTab === 'trades' && (
          <TradesView
            profile={profile}
            allPlayers={allPlayers}
            onToast={showToast}
          />
        )}
        {activeTab === 'market' && (
          <MarketView
            profile={profile}
            onToast={showToast}
          />
        )}
        {activeTab === 'arena' && (
          <ArenaView
            profile={profile}
            onUpdateProfile={updateProfile}
            onToast={showToast}
          />
        )}
        {activeTab === 'leaderboard' && (
          <LeaderboardView profile={profile} allPlayers={allPlayers} />
        )}
        {activeTab === 'profile' && (
          <ProfileView
            profile={profile}
            theme={theme}
            initialSubTab={profileSubTab}
            subTabSignal={profileTabSignal}
            onChangeTheme={setTheme}
            onUpdateProfile={updateProfile}
            onSignOut={handleSignOut}
            onToast={showToast}
          />
        )}
        {activeTab === 'admin' && isAdmin && (
          <AdminView
            profile={profile}
            allPlayers={allPlayers}
            onToast={showToast}
          />
        )}
      </main>

      {/* Backdrop for closing floating Plus / Notifications menus */}
      {(plusOpen || notifOpen) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setPlusOpen(false);
            setNotifOpen(false);
          }}
        />
      )}

      {/* Notifications Popover */}
      {notifOpen && (
        <div className="fixed top-14 right-3 sm:right-6 z-50 w-72 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl p-3 space-y-2">
          <div className="text-xs font-bold text-[var(--txt)] px-2 pt-1">Notifications</div>
          {notifications.length === 0 ? (
            <div className="text-xs text-[var(--mut)] px-2 py-4 text-center">
              Aucune notification pour le moment.
            </div>
          ) : (
            <div className="space-y-1">
              {notifications.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => {
                    setNotifOpen(false);
                    n.action();
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-[var(--surface-2)] transition-colors"
                >
                  <div className="text-xs font-bold text-[var(--txt)]">{n.title}</div>
                  <div className="text-[11px] text-[var(--mut)] mt-0.5">{n.subtitle}</div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Floating "Plus" Menu Popover (Wiki Masters exact vertical rounded card) */}
      {plusOpen && (
        <div className="fixed bottom-20 right-3 md:bottom-auto md:top-14 md:right-6 z-50 w-56 rounded-2xl bg-[var(--surface)] border border-[var(--line)] shadow-2xl py-2 overflow-hidden">
          {plusMenuItems.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={item.onClick}
              className={`w-full px-4 py-3 flex items-center gap-3.5 text-sm font-medium transition-colors text-left ${
                item.active
                  ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 font-bold'
                  : 'text-[var(--txt)] hover:bg-[var(--surface-2)]'
              }`}
            >
              <span className={item.active ? 'text-emerald-500' : 'text-[var(--mut)]'}>
                {item.icon}
              </span>
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      )}

      {/* Bottom Nav Bar (Exact 5 Wiki Masters buttons: Paquets, Collection, Échanges, Marché, Plus) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-16 bg-[var(--surface)]/95 backdrop-blur-xl border-t border-[var(--line)] flex items-center justify-around px-1">
        {primaryTabs.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => goTab(item.id)}
              className={`relative flex flex-col items-center justify-center gap-1 flex-1 min-w-0 py-1.5 text-[11px] font-medium transition-colors ${
                isActive ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-[var(--mut)]'
              }`}
            >
              {item.icon}
              <span className="truncate max-w-full px-0.5">{item.label}</span>
              {item.badge && (
                <span className="absolute top-1 right-4 px-1 rounded-full bg-emerald-500 text-white text-[9px] font-mono-num">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        <button
          type="button"
          onClick={() => {
            setNotifOpen(false);
            setPlusOpen((v) => !v);
          }}
          className={`flex flex-col items-center justify-center gap-1 flex-1 min-w-0 py-1.5 text-[11px] font-medium transition-colors ${
            plusOpen || isPlusTabActive
              ? 'text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-[var(--mut)]'
          }`}
        >
          <MoreHorizontal className="w-5 h-5" />
          <span>Plus</span>
        </button>
      </nav>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed left-1/2 bottom-20 md:bottom-6 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 border border-slate-700 text-xs sm:text-sm font-semibold text-white shadow-xl whitespace-nowrap">
          {toastMsg}
        </div>
      )}
    </div>
  );
}
