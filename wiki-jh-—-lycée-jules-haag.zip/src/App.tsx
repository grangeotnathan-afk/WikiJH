import React, { useCallback, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  runTransaction,
  setDoc,
  where,
} from 'firebase/firestore';
import {
  ArrowLeftRight,
  Layers,
  Package,
  Swords,
  Trophy,
  User as UserIcon,
} from 'lucide-react';
import {
  LABBE_IMG,
  MARCEAU_IMG,
  MAX_PACKS,
  PACK_INTERVAL_MS,
  getCosmetic,
} from './data/gameData';
import {
  auth,
  buildFreshPlayer,
  db,
  googleProvider,
  handleFirestoreError,
  sanitizePlayerUpdate,
  testFirestoreConnection,
} from './firebase/client';
import { OperationType, type NavTab, type PlayerProfile, type Site } from './types/game';
import { PackOpeningView } from './components/PackOpeningView';
import { ArenaView } from './components/ArenaView';
import { CollectionView } from './components/CollectionView';
import { CommerceView } from './components/CommerceView';
import { LeaderboardView } from './components/LeaderboardView';
import { ProfileView } from './components/ProfileView';
import { OnboardingModal } from './components/OnboardingModal';

export default function App() {
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<PlayerProfile | null>(null);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [allPlayers, setAllPlayers] = useState<PlayerProfile[]>([]);
  const [activeTab, setActiveTab] = useState<NavTab>('packs');
  const [authError, setAuthError] = useState('');
  const [toastMsg, setToastMsg] = useState('');

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(''), 2600);
    return () => clearTimeout(t);
  }, [toastMsg]);

  useEffect(() => {
    testFirestoreConnection();
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthReady(true);
      if (!u) {
        setProfile(null);
        setNeedsOnboarding(false);
        return;
      }
      try {
        const snap = await getDoc(doc(db, 'players', u.uid));
        if (!snap.exists()) {
          setNeedsOnboarding(true);
        } else {
          setNeedsOnboarding(false);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `players/${u.uid}`);
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to own profile & public leaderboard once authenticated and onboarded
  useEffect(() => {
    if (!user || needsOnboarding) return;

    const unsubMe = onSnapshot(
      doc(db, 'players', user.uid),
      (snap) => {
        if (snap.exists()) {
          setProfile(snap.data() as PlayerProfile);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `players/${user.uid}`)
    );

    const qPlayers = query(
      collection(db, 'players'),
      where('visibility', '==', 'public')
    );
    const unsubAll = onSnapshot(
      qPlayers,
      (snap) => {
        setAllPlayers(snap.docs.map((d) => d.data() as PlayerProfile));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'players')
    );

    return () => {
      unsubMe();
      unsubAll();
    };
  }, [user, needsOnboarding]);

  const updateProfile = useCallback(
    async (updater: (prev: PlayerProfile) => PlayerProfile) => {
      if (!user) return;
      const pRef = doc(db, 'players', user.uid);
      try {
        await runTransaction(db, async (tx) => {
          const snap = await tx.get(pRef);
          if (!snap.exists()) return;
          const current = snap.data() as PlayerProfile;
          const next = updater(current);
          tx.update(pRef, sanitizePlayerUpdate(next));
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `players/${user.uid}`);
      }
    },
    [user]
  );

  // Periodic booster pack regeneration check
  useEffect(() => {
    if (!profile || profile.packs >= MAX_PACKS) return;
    const checkRegen = () => {
      const now = Date.now();
      const gain = Math.floor((now - (profile.lastPackAt || now)) / PACK_INTERVAL_MS);
      if (gain > 0) {
        updateProfile((prev) => {
          const nextPacks = Math.min(MAX_PACKS, prev.packs + gain);
          const nextLast =
            nextPacks >= MAX_PACKS
              ? now
              : (prev.lastPackAt || now) + gain * PACK_INTERVAL_MS;
          return { ...prev, packs: nextPacks, lastPackAt: nextLast };
        });
      }
    };
    checkRegen();
    const id = setInterval(checkRegen, 15000);
    return () => clearInterval(id);
  }, [profile, updateProfile]);

  const handleGoogleSignIn = async () => {
    setAuthError('');
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Échec de connexion Google');
    }
  };

  const handleOnboardingComplete = async (data: {
    displayName: string;
    site: Site;
    classe: string;
  }) => {
    if (!user) return;
    const fresh = buildFreshPlayer(user.uid, data.displayName, data.site);
    fresh.classe = data.classe;
    fresh.bio = `Élève de ${data.classe || 'Jules Haag'} · Site ${data.site}`;
    try {
      await setDoc(doc(db, 'players', user.uid), sanitizePlayerUpdate(fresh));
      setNeedsOnboarding(false);
      setProfile(fresh);
      showToast('Profil créé ! Bon jeu sur Wiki JH.');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `players/${user.uid}`);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
  };

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg)] text-sm text-[var(--mut)]">
        Chargement de Wiki JH…
      </div>
    );
  }

  // Auth Landing Screen
  if (!user) {
    return (
      <div className="min-h-screen bg-[var(--bg)] text-[var(--txt)] flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 rounded-3xl overflow-hidden bg-[var(--surface)] border border-[var(--line)] shadow-2xl">
          <div className="lg:col-span-6 p-8 sm:p-10 flex flex-col justify-between gap-8">
            <div className="space-y-4">
              <div className="font-display text-3xl font-bold text-white tracking-tight">
                <span className="text-[#e2bb6b]">◆</span> Wiki JH
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-white leading-tight [text-wrap:balance]">
                L’arène des cartes du Lycée Jules Haag
              </h1>
              <p className="text-sm text-[var(--mut)] leading-relaxed">
                Collectionnez les éditions des sites Labbé et Marceau, affrontez vos camarades en duel classé ELO, échangez sur le marché inter-sites et hissez votre campus en tête du classement.
              </p>
            </div>

            <div className="space-y-3">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                className="w-full py-3.5 px-6 rounded-xl font-bold text-sm text-[#1d1405] bg-gradient-to-r from-[#c8952d] to-[#f2d58f] hover:brightness-110 transition-all"
              >
                Se connecter avec Google
              </button>
              <p className="text-xs text-[var(--mut)] text-center">
                Monnaie 100 % virtuelle · Sans aucun achat en argent réel
              </p>
              {authError && (
                <p className="text-xs text-rose-400 text-center">{authError}</p>
              )}
            </div>
          </div>

          <div className="lg:col-span-6 grid grid-rows-2 min-h-[280px] border-t lg:border-t-0 lg:border-l border-[var(--line)]">
            <div className="relative overflow-hidden">
              <img
                src={LABBE_IMG}
                alt="Lycée Jules Haag — Site Labbé"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-3 left-4">
                <div className="font-display text-lg font-bold text-white">Site Labbé</div>
                <div className="text-xs text-white/80">Besançon · Lycée Général & Technologique</div>
              </div>
            </div>
            <div className="relative overflow-hidden border-t border-[var(--line)]">
              <img
                src={MARCEAU_IMG}
                alt="Lycée Jules Haag — Site Marceau"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute bottom-3 left-4">
                <div className="font-display text-lg font-bold text-white">Site Marceau</div>
                <div className="text-xs text-white/80">Besançon · Lycée Professionnel</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (needsOnboarding) {
    const email = user.email || '';
    const guessedSite: Site = email.toLowerCase().includes('marceau') ? 'Marceau' : 'Labbé';
    const guessedName = user.displayName || email.split('@')[0] || 'Élève JH';
    return (
      <OnboardingModal
        defaultName={guessedName}
        defaultSite={guessedSite}
        onComplete={handleOnboardingComplete}
      />
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg)] text-sm text-[var(--mut)]">
        Synchronisation de votre profil…
      </div>
    );
  }

  const navItems: { id: NavTab; label: string; icon: React.ReactNode }[] = [
    { id: 'packs', label: 'Paquets', icon: <Package className="w-4 h-4" /> },
    { id: 'arena', label: 'Arène', icon: <Swords className="w-4 h-4" /> },
    { id: 'collection', label: 'Collection', icon: <Layers className="w-4 h-4" /> },
    { id: 'commerce', label: 'Commerce', icon: <ArrowLeftRight className="w-4 h-4" /> },
    { id: 'leaderboard', label: 'Classement', icon: <Trophy className="w-4 h-4" /> },
  ];

  const av = getCosmetic(profile.avatarId);

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--txt)] pb-20 md:pb-12">
      {/* 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[var(--bg)]/85 backdrop-blur-xl border-b border-[var(--line)]">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('packs')}
            className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            <span className="text-[#e2bb6b]">◆</span> Wiki JH
          </button>

          {/* Zone 2: 5 Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`whitespace-nowrap shrink-0 pb-1 border-b-2 transition-colors ${
                  activeTab === item.id
                    ? 'text-[#e2bb6b] border-[#e2bb6b]'
                    : 'text-[var(--mut)] border-transparent hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1 Primary Action (Coins + Profile Hub) */}
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`inline-flex items-center gap-2.5 px-4 py-2 rounded-xl border text-xs font-bold transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'profile'
                ? 'bg-[#e2bb6b] border-[#e2bb6b] text-[#1d1405]'
                : 'bg-[var(--surface)] border-[var(--line)] text-white hover:border-white/25'
            }`}
          >
            <span className="font-mono-num">
              {profile.coins.toLocaleString('fr-FR')} ●
            </span>
            <span aria-hidden="true" className="opacity-40">·</span>
            <span className="inline-flex items-center gap-1">
              <span>{av?.symbol || <UserIcon className="w-3.5 h-3.5" />}</span>
              <span>Profil</span>
            </span>
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'packs' && (
          <PackOpeningView
            profile={profile}
            onUpdateProfile={updateProfile}
            onNavigate={setActiveTab}
            onToast={showToast}
          />
        )}
        {activeTab === 'arena' && (
          <ArenaView
            profile={profile}
            onUpdateProfile={updateProfile}
            onToast={showToast}
          />
        )}
        {activeTab === 'collection' && (
          <CollectionView
            profile={profile}
            onUpdateProfile={updateProfile}
            onToast={showToast}
          />
        )}
        {activeTab === 'commerce' && (
          <CommerceView
            profile={profile}
            allPlayers={allPlayers}
            onToast={showToast}
          />
        )}
        {activeTab === 'leaderboard' && (
          <LeaderboardView profile={profile} allPlayers={allPlayers} />
        )}
        {activeTab === 'profile' && (
          <ProfileView
            profile={profile}
            onUpdateProfile={updateProfile}
            onSignOut={handleSignOut}
            onToast={showToast}
          />
        )}
      </main>

      {/* Mobile Bottom Nav (<= 15% height cap) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-16 bg-[var(--bg)]/95 backdrop-blur-xl border-t border-[var(--line)] flex items-center justify-around px-1">
        {navItems.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center justify-center gap-1 flex-1 py-1.5 text-[11px] font-semibold ${
              activeTab === item.id ? 'text-[#e2bb6b]' : 'text-[var(--mut)]'
            }`}
          >
            {item.icon}
            <span className="truncate">{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed left-1/2 bottom-20 md:bottom-6 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-[#1b2230] border border-white/15 text-xs sm:text-sm font-semibold text-white shadow-xl whitespace-nowrap">
          {toastMsg}
        </div>
      )}
    </div>
  );
}
