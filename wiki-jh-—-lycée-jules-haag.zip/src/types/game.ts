export type Rarity = 'C' | 'PC' | 'R' | 'SR' | 'UR' | 'L' | 'EX';

export type Site = 'Labbé' | 'Marceau';

export type CardCampus = 'Labbé' | 'Marceau' | 'Jules Haag';

export type Stance = 'none' | 'assault' | 'defense' | 'counter';

export type NavTab = 'packs' | 'arena' | 'collection' | 'commerce' | 'leaderboard' | 'profile';

export interface CardDef {
  id: number;
  r: Rarity;
  name: string;
  sub: string;
  icon: string;
  img: string;
  campus: CardCampus;
  weight: number;
  atk: number;
  def: number;
  spd: number;
  recycleCoins: number;
  suggestedPrice: number;
  lore: string;
}

export interface PlayerProfile {
  uid: string;
  visibility: 'public';
  displayName: string;
  site: Site;
  classe: string;
  avatarId: string;
  frameId: string;
  bannerId: string;
  titleId: string;
  bio: string;
  showcaseCardId: number;
  coins: number;
  packs: number;
  lastPackAt: number;
  inv: Record<string, number>;
  opened: number;
  elo: number;
  wins: number;
  losses: number;
  streak: number;
  bestStreak: number;
  tradesCompleted: number;
  marketSales: number;
  unlockedCosmetics: string[];
  claimedAchievements: string[];
  lastDailyAt: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface MarketListing {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerSite: Site;
  cardId: number;
  price: number;
  endsAt: number;
  status: 'active' | 'sold' | 'cancelled';
  buyerId: string;
  buyerName: string;
  sellerClaimed: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface TradeOffer {
  id: string;
  fromId: string;
  fromName: string;
  fromSite: Site;
  toId: string;
  toName: string;
  toSite: Site;
  give: number[];
  get: number[];
  status: 'pending' | 'accepted' | 'declined' | 'cancelled';
  fromClaimed: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface BattleQueueEntry {
  uid: string;
  displayName: string;
  site: Site;
  elo: number;
  avatarId: string;
  frameId: string;
  deck: number[];
  status: 'waiting' | 'matched';
  battleId: string;
  matchedWith: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface BattleMove {
  cardId: number;
  stance: Stance;
}

export interface RoundSummary {
  round: number;
  p1CardId: number;
  p2CardId: number;
  p1Stance: Stance;
  p2Stance: Stance;
  p1Power: number;
  p2Power: number;
  winner: 'p1' | 'p2' | 'draw';
  note: string;
}

export interface BattleDoc {
  id: string;
  p1Id: string;
  p1Name: string;
  p1Site: Site;
  p1Elo: number;
  p1Avatar: string;
  p1Frame: string;
  p1Deck: number[];
  p2Id: string;
  p2Name: string;
  p2Site: Site | '';
  p2Elo: number;
  p2Avatar: string;
  p2Frame: string;
  p2Deck: number[];
  mode: 'ranked' | 'friendly';
  status: 'open' | 'active' | 'finished' | 'cancelled';
  round: number;
  p1Score: number;
  p2Score: number;
  p1Move: BattleMove;
  p2Move: BattleMove;
  roundHistory: RoundSummary[];
  winnerId: string;
  p1Claimed: boolean;
  p2Claimed: boolean;
  turnStartedAt: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface CosmeticItem {
  id: string;
  type: 'avatar' | 'frame' | 'banner' | 'title';
  name: string;
  description: string;
  price: number;
  previewClass?: string;
  symbol?: string;
  unlockHint?: string;
}

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  category: 'Collection' | 'Arène' | 'Commerce' | 'Campus';
  rewardCoins: number;
  rewardCosmeticId?: string;
  target: number;
  progress: (p: PlayerProfile) => number;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}
